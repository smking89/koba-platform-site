-- KOBA Pulse catalog. Fictional handles and server listings, not personal data.
-- Players, per-game KOBA scores, server telemetry, discovery items, and the boost ledger.

create table if not exists players (
  id text primary key,
  handle text not null,
  display_name text not null,
  region text not null,
  clan_id text,
  friends jsonb not null default '[]'::jsonb,
  rivals jsonb not null default '[]'::jsonb,
  plays jsonb not null default '[]'::jsonb,
  games jsonb not null default '{}'::jsonb,
  vector double precision[] not null,
  score double precision not null,
  astro boolean not null default false,
  line text not null default '',
  activity_index double precision not null default 40,
  boost_credits integer not null default 1,
  account_links jsonb not null default '{}'::jsonb,
  ordinal integer not null default 0
);

create table if not exists koba_scores (
  player_id text not null references players (id),
  game_id text not null,
  normalized_score double precision not null,
  confidence_low double precision not null,
  confidence_high double precision not null,
  activity_index double precision not null,
  primary key (player_id, game_id)
);

create table if not exists servers (
  id text primary key,
  title text not null,
  detail text not null,
  meta text not null,
  game_id text,
  region text,
  anchors jsonb not null default '[]'::jsonb,
  clan_id text,
  vector double precision[] not null,
  freshness_min double precision not null,
  heat double precision not null,
  skill_center double precision,
  verified boolean not null,
  boost_eligible boolean not null,
  compliance text not null,
  compliance_note text not null,
  fraud_probability double precision not null,
  concurrent_players integer not null default 0,
  peak_players integer not null default 0,
  peak_tracking boolean not null default false,
  sample_count integer not null default 48,
  ordinal integer not null default 0
);

create table if not exists discovery_items (
  id text primary key,
  kind text not null,
  title text not null,
  detail text not null,
  meta text not null,
  game_id text,
  region text,
  anchors jsonb not null default '[]'::jsonb,
  clan_id text,
  vector double precision[] not null,
  freshness_min double precision not null,
  heat double precision not null,
  skill_center double precision,
  verified boolean not null,
  boost_eligible boolean not null,
  compliance text not null,
  compliance_note text not null,
  fraud_probability double precision not null,
  sponsor jsonb,
  ordinal integer not null default 0
);

create table if not exists boost_ledger (
  id text primary key,
  item_id text not null,
  actor_id text not null,
  portal text not null,
  started_at timestamptz not null,
  ends_at timestamptz not null,
  multiplier double precision not null default 3,
  credits_remaining integer not null,
  wallet_owner_id text not null,
  campaign_id text,
  status text not null default 'active'
);

create index if not exists boost_ledger_active_idx on boost_ledger (item_id, status, ends_at);
create index if not exists boost_ledger_actor_idx on boost_ledger (actor_id, status);

create table if not exists ranker_config (
  id text primary key,
  weights jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by text
);

insert into players (
  id, handle, display_name, region, clan_id, friends, rivals, plays, games, vector,
  score, astro, line, activity_index, boost_credits, account_links, ordinal
) values
('mara', 'mara', 'Mara Vale', 'EU', 'ironwake', '["harrow","dex","sao"]'::jsonb, '["dex","ysolde"]'::jsonb, '["srv-iron-rust","srv-dayz-eu"]'::jsonb, '{"rust":0.92,"dayz":0.74,"squad":0.28}'::jsonb, ARRAY[0.9,0.36,0.72,0.84,0.58,0.66]::double precision[], 1840, true, 'EU survival. Tracks Dex on the rig and NORTHLINE across the weekend.', 40, 4, '{"rust":"rust:mara","dayz":"dayz:mara","squad":"squad:mara"}'::jsonb, 0),
('harrow', 'harrow', 'Harrow Quinn', 'EU', 'ironwake', '["mara","dex"]'::jsonb, '["ysolde"]'::jsonb, '["srv-iron-rust","srv-dayz-eu"]'::jsonb, '{"rust":0.95,"dayz":0.4}'::jsonb, ARRAY[0.94,0.3,0.8,0.9,0.62,0.48]::double precision[], 1764, true, 'IRONWAKE lead. Runs Harbor wipes and the clan wallet.', 40, 4, '{"rust":"rust:harrow","dayz":"dayz:harrow"}'::jsonb, 1),
('dex', 'dex', 'Dex Hollow', 'EU', 'ironwake', '["mara","harrow"]'::jsonb, '["mara"]'::jsonb, '["srv-iron-rust"]'::jsonb, '{"rust":0.9,"dayz":0.22}'::jsonb, ARRAY[0.88,0.38,0.66,0.78,0.74,0.46]::double precision[], 1896, false, 'Clanmate and rival. Fifty-six points above Mara this season.', 40, 1, '{"rust":"rust:dex","dayz":"dayz:dex"}'::jsonb, 2),
('sao', 'sao', 'Sao Ridge', 'EU', NULL, '["mara"]'::jsonb, '[]'::jsonb, '["srv-north-squad"]'::jsonb, '{"squad":0.82,"cs2":0.48}'::jsonb, ARRAY[0.24,0.78,0.55,0.4,0.52,0.3]::double precision[], 1660, false, 'Friend of Mara. Lives in Squad armor squads, not on the rig.', 40, 1, '{"squad":"squad:sao","cs2":"cs2:sao"}'::jsonb, 3),
('ysolde', 'ysolde', 'Ysolde Voss', 'EU', 'northline', '["kael"]'::jsonb, '["mara","harrow"]'::jsonb, '["srv-north-squad","srv-hll-eu"]'::jsonb, '{"squad":0.9,"hll":0.7,"r6":0.44}'::jsonb, ARRAY[0.2,0.93,0.76,0.88,0.7,0.22]::double precision[], 1912, true, 'NORTHLINE lead. Clan rival to IRONWAKE.', 40, 4, '{"squad":"squad:ysolde","hll":"hll:ysolde","r6":"r6:ysolde"}'::jsonb, 4),
('kael', 'kael', 'Kael Ibarra', 'EU', 'northline', '["ysolde"]'::jsonb, '[]'::jsonb, '["srv-north-squad","srv-r6-eu"]'::jsonb, '{"r6":0.86,"squad":0.6}'::jsonb, ARRAY[0.14,0.9,0.68,0.72,0.66,0.2]::double precision[], 1730, false, 'Siege entry. NORTHLINE nights on Clubhouse.', 40, 1, '{"r6":"r6:kael","squad":"squad:kael"}'::jsonb, 5),
('nora', 'nora', 'Nora Keel', 'NA', NULL, '["lark"]'::jsonb, '[]'::jsonb, '["srv-dust-cs2"]'::jsonb, '{"cs2":0.97,"apex":0.3}'::jsonb, ARRAY[0.05,0.72,0.88,0.32,0.92,0.08]::double precision[], 2144, true, 'NA ranked. Dust Circuit is her home lobby.', 40, 4, '{"cs2":"cs2:nora","apex":"apex:nora"}'::jsonb, 6),
('lark', 'lark', 'Lark Nguyen', 'NA', NULL, '["nora"]'::jsonb, '[]'::jsonb, '["srv-tf2-na","srv-dust-cs2"]'::jsonb, '{"tf2":0.8,"cs2":0.42}'::jsonb, ARRAY[0.1,0.38,0.44,0.3,0.52,0.26]::double precision[], 1490, false, 'Plays Badwater with Nora on off-nights.', 40, 1, '{"tf2":"tf2:lark","cs2":"cs2:lark"}'::jsonb, 7),
('pike', 'pike', 'Pike Null', 'NA', NULL, '["moss"]'::jsonb, '[]'::jsonb, '["srv-ark-na","srv-pal-na"]'::jsonb, '{"ark":0.88,"palworld":0.76}'::jsonb, ARRAY[0.56,0.14,0.5,0.6,0.18,0.93]::double precision[], 1288, false, 'NA sandbox. Boss nights, then Palworld co-op.', 40, 1, '{"ark":"ark:pike","palworld":"palworld:pike"}'::jsonb, 8),
('moss', 'moss', 'Moss Adler', 'NA', NULL, '["pike"]'::jsonb, '[]'::jsonb, '["srv-ark-na"]'::jsonb, '{"ark":0.9,"7dtd":0.4}'::jsonb, ARRAY[0.62,0.12,0.48,0.55,0.22,0.88]::double precision[], 1210, false, 'Pike''s breed partner on Rag Shores.', 40, 1, '{"ark":"ark:moss","7dtd":"7dtd:moss"}'::jsonb, 9),
('vex', 'vex', 'Vex Station', 'SEA', NULL, '["imi"]'::jsonb, '[]'::jsonb, '["srv-val-sea"]'::jsonb, '{"valorant":0.95,"apex":0.22}'::jsonb, ARRAY[0.04,0.8,0.9,0.42,0.87,0.1]::double precision[], 2066, true, 'SEA Immortal. Duos with Imi, ignores survival wipes.', 40, 4, '{"valorant":"valorant:vex","apex":"apex:vex"}'::jsonb, 10),
('imi', 'imi', 'Imi Cho', 'SEA', NULL, '["vex"]'::jsonb, '[]'::jsonb, '["srv-val-sea"]'::jsonb, '{"valorant":0.91}'::jsonb, ARRAY[0.04,0.76,0.82,0.38,0.84,0.12]::double precision[], 1994, false, 'Controller duel. Posts the stack when Vex is late.', 40, 1, '{"valorant":"valorant:imi"}'::jsonb, 11),
('june', 'june', 'June Ash', 'EU', NULL, '[]'::jsonb, '[]'::jsonb, '["srv-lol-eu"]'::jsonb, '{"lol":0.93}'::jsonb, ARRAY[0.08,0.6,0.74,0.28,0.78,0.14]::double precision[], 1710, false, 'EU clash nights. No survival overlap.', 40, 1, '{"lol":"lol:june"}'::jsonb, 12),
('brim', 'brim', 'Brim Calder', 'NA', 'salt', '["reno"]'::jsonb, '[]'::jsonb, '["srv-rust-na"]'::jsonb, '{"rust":0.7,"dayz":0.8}'::jsonb, ARRAY[0.82,0.22,0.58,0.42,0.46,0.8]::double precision[], 1544, false, 'SALT CIRCUIT. DayZ-leaning, Rust when the flats wipe.', 40, 1, '{"rust":"rust:brim","dayz":"dayz:brim"}'::jsonb, 13),
('reno', 'reno', 'Reno Stack', 'NA', 'salt', '["brim"]'::jsonb, '[]'::jsonb, '["srv-rust-na"]'::jsonb, '{"rust":0.84,"tf2":0.15}'::jsonb, ARRAY[0.8,0.28,0.64,0.5,0.5,0.58]::double precision[], 1602, true, 'Owns Salt Flats. Pools Astro credits into server visibility.', 40, 4, '{"rust":"rust:reno","tf2":"tf2:reno"}'::jsonb, 14),
('odel', 'odel', 'Odel Mint', 'OCE', NULL, '[]'::jsonb, '[]'::jsonb, '[]'::jsonb, '{"rust":0.55,"conan":0.48}'::jsonb, ARRAY[0.7,0.16,0.3,0.22,0.2,0.84]::double precision[], 1090, false, 'OCE casual. Short sessions, high wander.', 40, 1, '{"rust":"rust:odel","conan":"conan:odel"}'::jsonb, 15),
('sibley', 'sibley', 'Sibley Crowe', 'NA', NULL, '[]'::jsonb, '[]'::jsonb, '["srv-ghost-rust"]'::jsonb, '{"rust":0.4}'::jsonb, ARRAY[0.5,0.4,0.2,0.08,0.9,0.2]::double precision[], 980, false, 'Flagged. Population pings do not match session telemetry.', 40, 1, '{"rust":"rust:sibley"}'::jsonb, 16),
('newt', 'newt', 'Newt Pell', 'NA', NULL, '[]'::jsonb, '[]'::jsonb, '[]'::jsonb, '{"rust":1}'::jsonb, ARRAY[1,0,0,0,0,0]::double precision[], 2400, false, 'New account. No sessions on file, so the prior still owns the vector.', 0, 1, '{"rust":"rust:newt"}'::jsonb, 17)
on conflict (id) do nothing;

insert into koba_scores (
  player_id, game_id, normalized_score, confidence_low, confidence_high, activity_index
) values
('mara', 'rust', 1803, 1768, 1838, 37),
('mara', 'dayz', 1720, 1685, 1755, 30),
('mara', 'squad', 1509, 1474, 1544, 11),
('harrow', 'rust', 1742, 1707, 1777, 38),
('harrow', 'dayz', 1499, 1464, 1534, 16),
('dex', 'rust', 1849, 1814, 1884, 36),
('dex', 'dayz', 1526, 1491, 1561, 9),
('sao', 'squad', 1585, 1550, 1620, 33),
('sao', 'cs2', 1444, 1409, 1479, 19),
('ysolde', 'squad', 1864, 1829, 1899, 36),
('ysolde', 'hll', 1769, 1734, 1804, 28),
('ysolde', 'r6', 1644, 1609, 1679, 18),
('kael', 'r6', 1669, 1634, 1704, 34),
('kael', 'squad', 1557, 1522, 1592, 24),
('nora', 'cs2', 2128, 2093, 2163, 39),
('nora', 'apex', 1769, 1734, 1804, 12),
('lark', 'tf2', 1416, 1381, 1451, 32),
('lark', 'cs2', 1274, 1239, 1309, 17),
('pike', 'ark', 1249, 1214, 1284, 35),
('pike', 'palworld', 1211, 1176, 1246, 30),
('moss', 'ark', 1180, 1145, 1215, 36),
('moss', '7dtd', 1029, 994, 1064, 16),
('vex', 'valorant', 2040, 2005, 2075, 38),
('vex', 'apex', 1663, 1628, 1698, 9),
('imi', 'valorant', 1949, 1914, 1984, 36),
('june', 'lol', 1680, 1645, 1715, 37),
('brim', 'rust', 1428, 1393, 1463, 28),
('brim', 'dayz', 1467, 1432, 1502, 32),
('reno', 'rust', 1538, 1503, 1573, 34),
('reno', 'tf2', 1262, 842, 1682, 6),
('odel', 'rust', 967, 932, 1002, 22),
('odel', 'conan', 948, 913, 983, 19),
('sibley', 'rust', 833, 798, 868, 16),
('newt', 'rust', 2400, 1980, 2820, 0)
on conflict (player_id, game_id) do nothing;

insert into servers (
  id, title, detail, meta, game_id, region, anchors, clan_id, vector, freshness_min, heat,
  skill_center, verified, boost_eligible, compliance, compliance_note, fraud_probability,
  concurrent_players, peak_players, peak_tracking, sample_count, ordinal
) values
('srv-iron-rust', 'IRONWAKE Harbor', 'Vanilla Rust with a short wipe. Clan home for EU evening sessions.', '180/200 · wipe 90m ago · verified', 'rust', 'EU', '["harrow","dex","mara"]'::jsonb, 'ironwake', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 90, 0.86, 1810, true, true, 'allow', 'Verified community. Staff label allow.', 0.04, 180, 200, true, 48, 0),
('srv-dayz-eu', 'Cherno Line', 'First-person DayZ. Low-mod, long survival, EU ping.', '92/120 · avg session 74m', 'dayz', 'EU', '["harrow","mara"]'::jsonb, NULL, ARRAY[0.84,0.2,0.55,0.36,0.4,0.86]::double precision[], 240, 0.62, 1600, true, true, 'allow', 'Verified. No open reports.', 0.06, 92, 120, true, 48, 1),
('srv-north-squad', 'Northline Ops', 'Squad server with seeded armor kits. NORTHLINE hosts Friday ops.', '64/80 · next op 3h', 'squad', 'EU', '["ysolde","kael","sao"]'::jsonb, 'northline', ARRAY[0.18,0.91,0.74,0.84,0.68,0.22]::double precision[], 40, 0.74, 1840, true, true, 'allow', 'Verified clan server.', 0.05, 64, 80, true, 48, 2),
('srv-dust-cs2', 'Dust Circuit', 'NA CS2 community hub. Faceit-linked stacks, not a public deathmatch.', '18 in lobby · rank floor 15k', 'cs2', 'NA', '["nora","lark"]'::jsonb, NULL, ARRAY[0.06,0.74,0.86,0.34,0.9,0.1]::double precision[], 20, 0.8, 2100, true, true, 'allow', 'API adapter healthy.', 0.03, 18, 18, true, 48, 3),
('srv-val-sea', 'SEA Immortal Stack', 'VALORANT party hub. Immortal and up. Duo and five-stack posts land here.', 'SEA · peak 22:00 ICT', 'valorant', 'SEA', '["vex","imi"]'::jsonb, NULL, ARRAY[0.05,0.82,0.9,0.4,0.86,0.12]::double precision[], 15, 0.83, 2030, true, true, 'allow', 'API-driven adapter. Allow.', 0.04, 33, 66, true, 48, 4),
('srv-ark-na', 'Rag Shores', 'ARK cluster, small tribe caps. Boss night is posted, not surprise-wiped.', '40/70 · boss night today', 'ark', 'NA', '["pike","moss"]'::jsonb, NULL, ARRAY[0.58,0.14,0.5,0.58,0.18,0.92]::double precision[], 50, 0.7, 1260, true, true, 'allow', 'Verified. Population curve matches joins.', 0.07, 40, 70, true, 48, 5),
('srv-pal-na', 'Lowland Co-op', 'Palworld co-op with a shared base and no PvP. Quiet NA evenings.', '12/32 · no PvP', 'palworld', 'NA', '["pike"]'::jsonb, NULL, ARRAY[0.58,0.14,0.5,0.58,0.18,0.92]::double precision[], 300, 0.48, 1200, true, true, 'allow', 'Allow.', 0.05, 12, 32, true, 48, 6),
('srv-rust-na', 'Salt Flats', 'NA Rust monthly. SALT CIRCUIT puts Astro credits into discovery, not fake pop.', '140/200 · monthly · verified owner', 'rust', 'NA', '["brim","reno"]'::jsonb, 'salt', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 180, 0.66, 1570, true, true, 'allow', 'Owner wallet verified.', 0.08, 140, 200, true, 48, 7),
('srv-r6-eu', 'Clubhouse Nights', 'Rainbow Six custom lobby. Ranked-adjacent, EU voice.', 'EU · 10-stack open', 'r6', 'EU', '["kael"]'::jsonb, NULL, ARRAY[0.18,0.91,0.74,0.84,0.68,0.22]::double precision[], 80, 0.5, 1740, false, true, 'allow', 'Unverified lobby, no fraud flags.', 0.12, 20, 40, true, 48, 8),
('srv-tf2-na', 'Badwater Sunday', 'TF2 community server. Payload, no random crits, NA.', '24/32 · no crits', 'tf2', 'NA', '["lark"]'::jsonb, NULL, ARRAY[0.1,0.36,0.42,0.28,0.5,0.24]::double precision[], 400, 0.33, 1400, false, true, 'allow', 'Allow.', 0.09, 24, 32, true, 48, 9),
('srv-hll-eu', 'Carentan Line', 'Hell Let Loose, EU, organized armor. NORTHLINE fills one side.', '78/100 · seeding', 'hll', 'EU', '["ysolde"]'::jsonb, 'northline', ARRAY[0.22,0.88,0.7,0.76,0.6,0.28]::double precision[], 110, 0.57, 1780, true, true, 'allow', 'Allow.', 0.05, 78, 100, true, 48, 10),
('srv-conan-eu', 'Exiled Keep', 'Conan Exiles. EU PvE-conflict. No one in Mara''s clan plays it yet.', '36/60 · out of network', 'conan', 'EU', '["odel"]'::jsonb, NULL, ARRAY[0.86,0.26,0.62,0.5,0.42,0.78]::double precision[], 500, 0.36, 1300, true, true, 'allow', 'Allow. Thin social graph — affinity only.', 0.06, 36, 60, true, 48, 11),
('srv-7d-na', 'Navezgane Week', '7 Days to Die, blood-moon weekends, NA.', '16/24 · day 28', '7dtd', 'NA', '["moss"]'::jsonb, NULL, ARRAY[0.58,0.14,0.5,0.58,0.18,0.92]::double precision[], 800, 0.28, 1180, false, true, 'allow', 'Allow.', 0.1, 16, 24, true, 48, 12),
('srv-lol-eu', 'Clash Night EU', 'League clash roster board. Not a dedicated server — an API-linked hub.', 'EU · Saturday clash', 'lol', 'EU', '["june"]'::jsonb, NULL, ARRAY[0.08,0.58,0.74,0.3,0.76,0.16]::double precision[], 200, 0.44, 1700, true, true, 'allow', 'API adapter. Allow.', 0.04, 18, 35, false, 48, 13),
('srv-ghost-rust', 'Ghost Pop 400', 'Rust listing claiming a full server. Joins do not match the player graph.', 'claimed 400 · telemetry mismatch', 'rust', 'NA', '["sibley"]'::jsonb, NULL, ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 6, 0.99, 1500, false, false, 'drop', 'Fraud cluster. Population velocity failed the admin check. Default-deny drop.', 0.94, 400, 400, true, 48, 14),
('srv-cold', 'Unsampled Relay', 'New dedicated listing. Population telemetry has not cleared the prior.', '0 samples · NA', 'rust', 'NA', '[]'::jsonb, NULL, ARRAY[0.5,0.5,0.5,0.5,0.5,0.5]::double precision[], 10, 0.99, NULL, false, false, 'allow', 'Cold start. Heat and fraud stay on the prior until samples arrive.', 0.02, 0, 0, false, 0, 15)
on conflict (id) do nothing;

insert into discovery_items (
  id, kind, title, detail, meta, game_id, region, anchors, clan_id, vector, freshness_min, heat,
  skill_center, verified, boost_eligible, compliance, compliance_note, fraud_probability, sponsor, ordinal
) values
('lfg-harbor', 'lfg', 'Oil run — need 2', 'Harbor wipe day. Harrow is holding a boat. EU voice, Rust only.', 'posted 12m ago · 2 slots', 'rust', 'EU', '["harrow"]'::jsonb, 'ironwake', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 12, 0.77, 1780, true, true, 'allow', 'Allow.', 0.03, NULL, 0),
('lfg-cs2', 'lfg', 'Faceit stack, one slot', 'Nora is one short for a 15k average. NA evening.', 'posted 20m ago · rank floor', 'cs2', 'NA', '["nora"]'::jsonb, NULL, ARRAY[0.06,0.74,0.86,0.34,0.9,0.1]::double precision[], 20, 0.72, 2144, true, true, 'allow', 'Allow.', 0.02, NULL, 1),
('lfg-val', 'lfg', 'Immortal duo queue', 'Imi is live. Looking for a third only if they can entry.', 'SEA · posted 15m ago', 'valorant', 'SEA', '["imi"]'::jsonb, NULL, ARRAY[0.05,0.82,0.9,0.4,0.86,0.12]::double precision[], 15, 0.75, 1994, true, true, 'allow', 'Allow.', 0.03, NULL, 2),
('lfg-ark', 'lfg', 'Boss night, 4 slots', 'Rag Shores, gamma Megapithecus. Pike wants bodies, not a carry.', 'NA · posted 40m ago', 'ark', 'NA', '["moss"]'::jsonb, NULL, ARRAY[0.58,0.14,0.5,0.58,0.18,0.92]::double precision[], 40, 0.6, 1250, true, true, 'allow', 'Allow.', 0.05, NULL, 3),
('lfg-squad', 'lfg', 'Armor squad, Northline', 'Ysolde is short a LAT. EU Squad, this op only.', 'EU · posted 25m ago', 'squad', 'EU', '["ysolde"]'::jsonb, 'northline', ARRAY[0.18,0.91,0.74,0.84,0.68,0.22]::double precision[], 25, 0.64, 1860, true, true, 'allow', 'Allow.', 0.04, NULL, 4),
('lfg-dayz', 'lfg', 'Cherno fresh spawns', 'Quiet coast run. No clan requirement. EU DayZ.', 'EU · posted 18m ago', 'dayz', 'EU', '["harrow"]'::jsonb, NULL, ARRAY[0.84,0.2,0.55,0.36,0.4,0.86]::double precision[], 18, 0.52, 1500, false, true, 'allow', 'Allow.', 0.08, NULL, 5),
('prof-dex', 'profile', 'Dex Hollow', 'Rival inside IRONWAKE. Up 56 KOBA points on Mara. Oil-rig fights decide the gap.', 'EU · Rust · score 1896', 'rust', 'EU', '["dex"]'::jsonb, 'ironwake', ARRAY[0.88,0.38,0.66,0.78,0.74,0.46]::double precision[], 30, 0.58, 1896, true, true, 'allow', 'Allow.', 0.02, NULL, 6),
('prof-ysolde', 'profile', 'Ysolde Voss', 'NORTHLINE lead. Clan-level rival. Squad and Hell Let Loose.', 'EU · score 1912', 'squad', 'EU', '["ysolde"]'::jsonb, 'northline', ARRAY[0.2,0.93,0.76,0.88,0.7,0.22]::double precision[], 70, 0.49, 1912, true, true, 'allow', 'Allow.', 0.03, NULL, 7),
('prof-nora', 'profile', 'Nora Keel', 'NA CS2. Crossed 2100 this week. Not in the survival graph.', 'NA · CS2 · score 2144', 'cs2', 'NA', '["nora"]'::jsonb, NULL, ARRAY[0.05,0.72,0.88,0.32,0.92,0.08]::double precision[], 45, 0.55, 2144, true, true, 'allow', 'Allow.', 0.02, NULL, 8),
('post-wipe', 'post', 'Harbor wipe timeline', 'Harrow posted crate times and the no-raid window. IRONWAKE only.', 'post · 30m ago', 'rust', 'EU', '["harrow"]'::jsonb, 'ironwake', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 30, 0.5, NULL, true, true, 'allow', 'Allow.', 0.02, NULL, 9),
('post-rank', 'post', 'Nora crossed 2100', 'Rank-up note on Dust Circuit. Form is aim, not survival time.', 'post · 50m ago', 'cs2', 'NA', '["nora"]'::jsonb, NULL, ARRAY[0.06,0.74,0.86,0.34,0.9,0.1]::double precision[], 50, 0.46, 2144, true, true, 'allow', 'Allow.', 0.02, NULL, 10),
('ch-rig', 'challenge', 'Rig duels — Mara lane vs Dex', 'First to 50 player kills this wipe. Escrow sits until the adapter confirms the winner.', 'Rust · EU · 200 credits escrowed', 'rust', 'EU', '["dex"]'::jsonb, 'ironwake', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 60, 0.61, 1896, true, true, 'allow', 'Winner path is adapter-backed. Allow.', 0.04, NULL, 11),
('ch-clans', 'challenge', 'IRONWAKE vs NORTHLINE', 'Weekend ops. Squad rounds, automated result from the server adapter.', 'Squad · EU · clan challenge', 'squad', 'EU', '["ysolde","harrow"]'::jsonb, NULL, ARRAY[0.18,0.91,0.74,0.84,0.68,0.22]::double precision[], 100, 0.54, 1850, true, true, 'allow', 'Allow.', 0.05, NULL, 12),
('ch-dust', 'challenge', 'Dust Circuit bounty', 'Ten regulation maps. Highest KOBA combat score takes the purse.', 'CS2 · NA · sponsored purse', 'cs2', 'NA', '["nora"]'::jsonb, NULL, ARRAY[0.06,0.74,0.86,0.34,0.9,0.1]::double precision[], 80, 0.5, 2100, true, true, 'allow', 'Purse cleared staff review.', 0.06, NULL, 13),
('clan-north', 'clan', 'NORTHLINE', 'EU tactical clan. Open recruitment for armor and entry.', 'EU · Squad, HLL, Siege', 'squad', 'EU', '["ysolde","kael"]'::jsonb, 'northline', ARRAY[0.18,0.91,0.74,0.84,0.68,0.22]::double precision[], 240, 0.4, 1820, true, false, 'allow', 'Allow.', 0.04, NULL, 14),
('clan-iron', 'clan', 'IRONWAKE', 'EU survival clan. Harbor is the home server. Recruitment is application-only.', 'EU · Rust, DayZ', 'rust', 'EU', '["harrow","dex","mara"]'::jsonb, 'ironwake', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 300, 0.42, 1830, true, false, 'allow', 'Allow.', 0.03, NULL, 15),
('clan-salt', 'clan', 'SALT CIRCUIT', 'NA Rust and DayZ. Server owners can delegate staff without sharing the wallet.', 'NA · Rust, DayZ', 'rust', 'NA', '["reno","brim"]'::jsonb, 'salt', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 400, 0.35, 1570, true, false, 'allow', 'Allow.', 0.07, NULL, 16),
('list-skin', 'listing', 'Tempered Harbor door skin', 'Marketplace listing tied to the Harbor wipe. Cosmetic, not a combat edge.', 'Rust · listing · 40 credits', 'rust', 'EU', '["harrow"]'::jsonb, NULL, ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 120, 0.3, NULL, true, true, 'allow', 'Asset passed the upload sandbox.', 0.08, NULL, 17),
('camp-glass', 'campaign', 'Aether Glass 240Hz', 'Native placement for high-score FPS players. Labeled. Not mixed into organic rank.', 'CS2, VALORANT · NA, SEA · score 1900+', 'cs2', 'NA', '[]'::jsonb, NULL, ARRAY[0.06,0.74,0.86,0.34,0.9,0.1]::double precision[], 90, 0.4, NULL, true, false, 'allow', 'Creative approved. Escrow holding the flight.', 0.05, '{"brand":"Aether Glass","games":["cs2","valorant"],"regions":["NA","SEA"],"minScore":1900,"premiumLean":true}'::jsonb, 18),
('camp-harbor', 'campaign', 'Harbor Supply bounty', 'Rust EU bounty. Payout releases when the winner engine confirms the objective.', 'Rust · EU · score 1400+', 'rust', 'EU', '["harrow"]'::jsonb, 'ironwake', ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 70, 0.47, 1700, true, false, 'allow', 'Approved. Funds in escrow.', 0.06, '{"brand":"Harbor Supply","games":["rust"],"regions":["EU"],"minScore":1400,"premiumLean":false}'::jsonb, 19),
('camp-night', 'campaign', 'Nightcurrent', 'Energy brand flight. Creative is still in the upload sandbox, so the gate holds it.', 'broad target · sandbox hold', NULL, NULL, '[]'::jsonb, NULL, ARRAY[0.4,0.45,0.5,0.35,0.55,0.3]::double precision[], 12, 0.93, NULL, false, false, 'interstitial', 'Creative has not cleared the sandbox. Interstitial until a second staff key.', 0.22, '{"brand":"Nightcurrent","games":[],"regions":[],"minScore":0,"premiumLean":true}'::jsonb, 20),
('camp-farm', 'campaign', 'Free coin drop', 'Paid clicks with no matching play sessions. Staff already dropped the flight.', 'blocked · click farm', 'rust', 'NA', '["sibley"]'::jsonb, NULL, ARRAY[0.9,0.32,0.7,0.82,0.56,0.6]::double precision[], 8, 0.88, NULL, false, false, 'drop', 'Click-farm pattern against live sessions. Drop. Do not backfill into the feed.', 0.97, '{"brand":"Unverified purse","games":["rust"],"regions":["NA"],"minScore":0,"premiumLean":false}'::jsonb, 21)
on conflict (id) do nothing;

insert into boost_ledger (
  id, item_id, actor_id, portal, started_at, ends_at, multiplier, credits_remaining,
  wallet_owner_id, campaign_id, status
) values (
  'led-reno-salt-closed',
  'srv-rust-na',
  'reno',
  'koba.games',
  now() - interval '2 days',
  now() - interval '2 days' + interval '10 minutes',
  3,
  3,
  'reno',
  null,
  'closed'
)
on conflict (id) do nothing;

insert into ranker_config (id, weights, updated_by) values (
  'global',
  '{"join_server":1.2,"join_lfg":1.15,"open_profile":0.7,"challenge":1,"follow_clan":0.85,"engage_sponsor":0.28}'::jsonb,
  'seed'
)
on conflict (id) do nothing;
