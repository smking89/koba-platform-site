import { create } from "zustand";
import { money } from "@/site/astro";
import {
  ingest,
  nextCapacity,
  routeCommand,
  seedPlatform,
  signPacket,
  UNLINKED_STEAM,
  workloadBudget,
  type Capacity,
  type Embed,
  type FeedRow,
  type GameScope,
  type IngestResult,
  type PlatformData,
  type RawPacket,
  type StaffRole,
} from "./engine.ts";

export type DeskGrant = "player" | "business" | "mod" | "admin" | "super";

const SEED_GRANTS: Record<string, DeskGrant> = {
  koba_mara: "player",
  koba_harrow: "business",
  koba_nora: "mod",
  koba_ysolde: "admin",
  koba_dex: "player",
};

function credentialFor(id: string, stamp: number) {
  return `cred_${id.replace("koba_", "")}_${stamp.toString(36)}`;
}

interface PlatformState extends PlatformData {
  role: StaffRole;
  hq: boolean;
  game: GameScope;
  fps: number;
  capacity: Capacity;
  lastIngest: IngestResult | null;
  lastEmbed: Embed | null;
  activeServerId: string;
  setViewer: (viewerId: string) => void;
  setRole: (role: StaffRole) => void;
  setHq: (hq: boolean) => void;
  setGame: (game: GameScope) => void;
  setServer: (serverId: string) => void;
  setFps: (fps: number) => void;
  run: (line: string) => Embed;
  emitCombat: (steamId?: string) => Promise<void>;
  emitRaid: () => Promise<void>;
  emitForged: () => Promise<void>;
  emitBurst: () => Promise<void>;
  reset: () => void;
  applySale: (sale: { buyerId: string; sellerId: string; price: number; payout: number; title: string; detail: string }) => { ok: true } | { ok: false; reason: string };
  grants: Record<string, DeskGrant>;
  credentials: Record<string, string>;
  assignGrant: (id: string, grant: DeskGrant) => void;
  rotateCredential: (id: string) => void;
  revokeCredential: (id: string) => void;
  rotateServerKey: (serverId: string) => void;
  rotateHostKey: (serverId: string) => void;
  setServerLicense: (serverId: string, license: "active" | "expired") => void;
  addServer: (input: { name: string; game: GameScope }) => void;
  removeServer: (serverId: string) => { ok: true } | { ok: false; reason: string };
  removeIdentity: (id: string) => { ok: true } | { ok: false; reason: string };
}

function budgetLabel(capacity: Capacity): string {
  return `${capacity} · budget ${workloadBudget(capacity).toFixed(2)}`;
}

function pickedServer(state: { servers: PlatformData["servers"]; activeServerId: string }) {
  return state.servers.find((server) => server.id === state.activeServerId) ?? state.servers[0]!;
}

async function signed(
  data: PlatformData,
  body: Omit<RawPacket, "plugin_signature" | "hostKey">,
  hostKey: string,
  pluginKey: string,
  forge = false,
): Promise<RawPacket> {
  const plugin_signature = forge ? "00".repeat(32) : await signPacket(pluginKey, body);
  return { ...body, hostKey, plugin_signature };
}

export const usePlatform = create<PlatformState>((set, get) => ({
  ...seedPlatform(),
  role: "player",
  hq: false,
  game: "RUST_CONSOLE",
  fps: 72,
  capacity: "nominal",
  lastIngest: null,
  lastEmbed: null,
  activeServerId: "srv-iron",
  grants: { ...SEED_GRANTS },
  credentials: Object.fromEntries(Object.keys(SEED_GRANTS).map((id) => [id, credentialFor(id, 1)])),
  setViewer: (viewerId) => set({ viewerId }),
  setRole: (role) => set({ role }),
  setHq: (hq) => set({ hq }),
  setGame: (game) => set({ game }),
  setServer: (activeServerId) => set({ activeServerId }),
  setFps: (fps) => set((state) => ({ fps, capacity: nextCapacity(fps, state.capacity) })),
  run: (line) => {
    const state = get();
    const result = routeCommand(state, line, state.role, state.hq, state.game, Date.now());
    set({ ...result.data, role: state.role, hq: state.hq, game: state.game, fps: state.fps, capacity: state.capacity, lastIngest: state.lastIngest, lastEmbed: result.embed });
    return result.embed;
  },
  emitCombat: async (steamId) => {
    const state = get();
    const server = pickedServer(state);
    const attacker = steamId ?? state.identities.find((identity) => identity.id === state.viewerId)?.steamId ?? UNLINKED_STEAM;
    const attackerName = state.identities.find((identity) => identity.steamId === attacker)?.name ?? "Unlinked rifle";
    const body = {
      serverId: server.id,
      kind: "combat" as const,
      at: Date.now(),
      attackerSteam: attacker,
      attackerName,
      victimSteam: "76561198000002144",
      victimName: "Nora Keel",
      weapon: "rifle.ak",
      distance: 42,
      hitZone: "head",
      pve: false,
    };
    const packet = await signed(state, body, server.hostKey, server.pluginKey);
    const ingested = await ingest(get(), packet, Date.now());
    set({ ...ingested.data, lastIngest: ingested.result });
  },
  emitRaid: async () => {
    const state = get();
    const server = pickedServer(state);
    const body = {
      serverId: server.id,
      kind: "raid" as const,
      at: Date.now(),
      attackerSteam: state.identities.find((identity) => identity.id === "koba_ysolde")!.steamId!,
      attackerName: "Ysolde Voss",
      entity: "cupboard.tool",
      damage: 86,
      ownerSteam: "76561198000001840",
      weapon: "explosive.timed",
    };
    const packet = await signed(state, body, server.hostKey, server.pluginKey);
    const ingested = await ingest(get(), packet, Date.now());
    set({ ...ingested.data, lastIngest: ingested.result });
  },
  emitForged: async () => {
    const state = get();
    const server = pickedServer(state);
    const body = {
      serverId: server.id,
      kind: "combat" as const,
      at: Date.now(),
      attackerSteam: "76561198000001840",
      attackerName: "Mara Vale",
      victimSteam: "76561198000002144",
      victimName: "Nora Keel",
      weapon: "rifle.ak",
      distance: 10,
      hitZone: "chest",
      pve: false,
    };
    const packet = await signed(state, body, server.hostKey, server.pluginKey, true);
    const ingested = await ingest(get(), packet, Date.now());
    set({ ...ingested.data, lastIngest: ingested.result });
  },
  emitBurst: async () => {
    const server = pickedServer(get());
    let data: PlatformData = get();
    let last: IngestResult | null = null;
    const start = Date.now();
    for (let i = 0; i < 9; i++) {
      const body = {
        serverId: server.id,
        kind: "combat" as const,
        at: start,
        attackerSteam: "76561198000001840",
        attackerName: "Mara Vale",
        victimSteam: "76561198000002144",
        victimName: "Nora Keel",
        weapon: "rifle.ak",
        distance: 18 + i,
        hitZone: "chest",
        pve: false,
      };
      const packet = await signed(data, body, server.hostKey, server.pluginKey);
      const ingested = await ingest(data, packet, start);
      data = ingested.data;
      last = ingested.result;
    }
    set({
      identities: data.identities,
      clans: data.clans,
      servers: data.servers,
      events: data.events,
      provisional: data.provisional,
      attempts: data.attempts,
      feed: data.feed,
      audit: data.audit,
      viewerId: data.viewerId,
      seq: data.seq,
      lastIngest: last,
    });
  },
  reset: () =>
    set({
      ...seedPlatform(),
      role: "player",
      hq: false,
      game: "RUST_CONSOLE",
      fps: 72,
      capacity: "nominal",
      lastIngest: null,
      lastEmbed: null,
      activeServerId: "srv-iron",
      grants: { ...SEED_GRANTS },
      credentials: Object.fromEntries(Object.keys(SEED_GRANTS).map((id) => [id, credentialFor(id, 1)])),
    }),
  applySale: (sale) => {
    const state = get();
    const buyer = state.identities.find((identity) => identity.id === sale.buyerId);
    const seller = state.identities.find((identity) => identity.id === sale.sellerId);
    if (!buyer || !seller) return { ok: false, reason: "That identity is not on the network." };
    if (buyer.id === seller.id) return { ok: false, reason: "You cannot buy your own listing." };
    if (buyer.coins < sale.price) return { ok: false, reason: "Not enough coins." };
    const identities = state.identities.map((identity) => {
      if (identity.id === buyer.id) return { ...identity, coins: money(identity.coins - sale.price) };
      if (identity.id === seller.id) return { ...identity, coins: money(identity.coins + sale.payout) };
      return identity;
    });
    const seq = state.seq + 1;
    const row: FeedRow = {
      id: `feed-${seq}`,
      at: seq,
      tone: "gold",
      title: sale.title,
      detail: sale.detail,
    };
    set({
      identities,
      seq,
      feed: [row, ...state.feed].slice(0, 40),
    });
    return { ok: true };
  },
  assignGrant: (id, grant) => set((state) => ({ grants: { ...state.grants, [id]: grant } })),
  rotateCredential: (id) =>
    set((state) => ({
      credentials: { ...state.credentials, [id]: credentialFor(id, state.seq + 1) },
      seq: state.seq + 1,
    })),
  revokeCredential: (id) => set((state) => ({ credentials: { ...state.credentials, [id]: "" } })),
  rotateServerKey: (serverId) =>
    set((state) => ({
      servers: state.servers.map((server) =>
        server.id === serverId ? { ...server, pluginKey: `vk_${server.id.slice(-4)}_${(state.seq + 1).toString(36)}` } : server,
      ),
      seq: state.seq + 1,
    })),
  rotateHostKey: (serverId) =>
    set((state) => ({
      servers: state.servers.map((server) =>
        server.id === serverId ? { ...server, hostKey: `hk_${server.id.slice(-4)}_${(state.seq + 1).toString(36)}` } : server,
      ),
      seq: state.seq + 1,
    })),
  setServerLicense: (serverId, license) =>
    set((state) => ({
      servers: state.servers.map((server) => (server.id === serverId ? { ...server, license } : server)),
    })),
  addServer: ({ name, game }) =>
    set((state) => {
      const seq = state.seq + 1;
      const slug = seq.toString(36);
      return {
        seq,
        servers: [
          ...state.servers,
          {
            id: `srv-${slug}`,
            name: name.trim().slice(0, 32) || "New connection",
            game,
            guildId: `guild-${slug}`,
            license: "active",
            hostKey: `hk_${slug}`,
            pluginKey: `vk_${slug}`,
          },
        ],
      };
    }),
  removeServer: (serverId) => {
    const state = get();
    if (state.servers.length <= 1) return { ok: false, reason: "Keep at least one API connection." };
    if (state.activeServerId === serverId) {
      const next = state.servers.find((server) => server.id !== serverId);
      set({
        servers: state.servers.filter((server) => server.id !== serverId),
        activeServerId: next?.id ?? state.activeServerId,
      });
      return { ok: true };
    }
    set({ servers: state.servers.filter((server) => server.id !== serverId) });
    return { ok: true };
  },
  removeIdentity: (id) => {
    const state = get();
    if (state.identities.length <= 1) return { ok: false, reason: "The network needs at least one identity." };
    if (id === state.viewerId) return { ok: false, reason: "Switch off this identity before deleting it." };
    const grants = { ...state.grants };
    const credentials = { ...state.credentials };
    delete grants[id];
    delete credentials[id];
    set({
      identities: state.identities.filter((identity) => identity.id !== id),
      grants,
      credentials,
    });
    return { ok: true };
  },
}));

export { budgetLabel };
