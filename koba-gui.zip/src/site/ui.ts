import { create } from "zustand";
import { SEED_PRODUCTS, type ShopProduct } from "@/site/astro";

export type SitePage = "home" | "groups" | "messages" | "shop" | "profile";
export type HomeTab = "feed" | "discover" | "compete" | "rankings" | "social" | "stories";
export type Desk = "play" | "business" | "mod" | "admin" | "super";
export type GameFilter = "all" | "rust" | "dayz";
export type RegionFilter = "all" | "NA" | "EU" | "OCE";
export type StyleFilter = "all" | "Survival" | "Tactical" | "Social" | "Hardcore";

export interface Notice {
  id: number;
  title: string;
  detail: string;
}

interface SiteState {
  page: SitePage;
  homeTab: HomeTab;
  query: string;
  game: GameFilter;
  region: RegionFilter;
  style: StyleFilter;
  saved: string[];
  follows: string[];
  bounties: string[];
  products: ShopProduct[];
  productSeq: number;
  opened: Record<string, string>;
  pulse: number;
  notice: Notice | null;
  palette: boolean;
  accountOpen: boolean;
  focusId: string | null;
  desk: Desk;
  setPage: (page: SitePage) => void;
  setHomeTab: (tab: HomeTab) => void;
  setDesk: (desk: Desk) => void;
  setQuery: (query: string) => void;
  setGame: (game: GameFilter) => void;
  setRegion: (region: RegionFilter) => void;
  setStyle: (style: StyleFilter) => void;
  toggleSaved: (id: string) => void;
  toggleFollow: (id: string) => void;
  toggleBounty: (id: string) => void;
  openBusiness: (id: string, name: string) => void;
  addProduct: (draft: Omit<ShopProduct, "id">) => void;
  ping: (title: string, detail: string) => void;
  setPalette: (palette: boolean) => void;
  setAccountOpen: (accountOpen: boolean) => void;
  openProfile: (id: string) => void;
  reset: () => void;
}

const initial = {
  page: "home" as SitePage,
  homeTab: "feed" as HomeTab,
  query: "",
  game: "all" as GameFilter,
  region: "all" as RegionFilter,
  style: "all" as StyleFilter,
  saved: ["srv-iron"],
  follows: ["koba_dex"],
  bounties: [] as string[],
  products: SEED_PRODUCTS,
  productSeq: 2,
  opened: {} as Record<string, string>,
  pulse: 0,
  notice: null as Notice | null,
  palette: false,
  accountOpen: false,
  focusId: null as string | null,
  desk: "play" as Desk,
};

export const useSite = create<SiteState>((set) => ({
  ...initial,
  setPage: (page) => set({ page, desk: "play", accountOpen: false, palette: false }),
  setHomeTab: (homeTab) => set({ homeTab, page: "home", desk: "play", accountOpen: false, palette: false }),
  setDesk: (desk) => set({ desk, accountOpen: false, palette: false }),
  setQuery: (query) => set({ query }),
  setGame: (game) => set({ game }),
  setRegion: (region) => set({ region }),
  setStyle: (style) => set({ style }),
  toggleSaved: (id) =>
    set((state) => ({
      saved: state.saved.includes(id) ? state.saved.filter((item) => item !== id) : [...state.saved, id],
    })),
  toggleFollow: (id) =>
    set((state) => ({
      follows: state.follows.includes(id) ? state.follows.filter((item) => item !== id) : [...state.follows, id],
    })),
  toggleBounty: (id) =>
    set((state) => ({
      bounties: state.bounties.includes(id) ? state.bounties.filter((item) => item !== id) : [...state.bounties, id],
    })),
  openBusiness: (id, name) => set((state) => ({ opened: { ...state.opened, [id]: name } })),
  addProduct: (draft) =>
    set((state) => {
      const productSeq = state.productSeq + 1;
      const product: ShopProduct = { id: `prd-${productSeq}`, ...draft };
      return { productSeq, products: [product, ...state.products] };
    }),
  ping: (title, detail) => set((state) => ({ pulse: state.pulse + 1, notice: { id: state.pulse + 1, title, detail } })),
  setPalette: (palette) => set({ palette, accountOpen: false }),
  setAccountOpen: (accountOpen) => set({ accountOpen, palette: false }),
  openProfile: (focusId) => set({ focusId, page: "profile", desk: "play", palette: false, accountOpen: false }),
  reset: () => set({ ...initial, products: SEED_PRODUCTS.map((product) => ({ ...product })) }),
}));
