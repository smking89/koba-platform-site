export type BadgeTone = "ok" | "cyan" | "violet" | "gold" | "magenta" | "muted";
export type BadgeGlyph =
  | "seal"
  | "comet"
  | "diamond"
  | "crown"
  | "laurel"
  | "wave"
  | "hex"
  | "peak"
  | "spark"
  | "gift"
  | "clock"
  | "maps"
  | "chevron"
  | "mark";

export interface Pin {
  id: string;
  name: string;
  group: string;
  detail: string;
  tone: BadgeTone;
  glyph: BadgeGlyph;
  /** Threshold that earned this step, drawn on the badge. */
  mark?: string;
}

export interface LadderView {
  id: string;
  label: string;
  unit: string;
  value: number;
  current: Pin | null;
  next: Pin | null;
  nextAt: number | null;
}

export interface BadgeResult {
  featured: Pin[];
  earned: Pin[];
  ladders: LadderView[];
}

interface Step {
  id: string;
  name: string;
  at: number;
  tone: BadgeTone;
  glyph: BadgeGlyph;
  detail: string;
}

const SEASONS: Step[] = [
  { id: "season-spark", name: "Spark", at: 1, tone: "cyan", glyph: "spark", detail: "One season on KOBA." },
  { id: "season-kindling", name: "Kindling", at: 2, tone: "cyan", glyph: "spark", detail: "Two seasons on KOBA." },
  { id: "season-flare", name: "Flare", at: 3, tone: "gold", glyph: "spark", detail: "Three seasons on KOBA." },
  { id: "season-beacon", name: "Beacon", at: 4, tone: "gold", glyph: "spark", detail: "Four seasons on KOBA." },
  { id: "season-signal", name: "Signal", at: 5, tone: "violet", glyph: "spark", detail: "Five seasons on KOBA." },
  { id: "season-monument", name: "Monument", at: 6, tone: "violet", glyph: "spark", detail: "Six or more seasons on KOBA." },
];

const GIFTS: Step[] = [
  { id: "gift-tip", name: "Tip", at: 1, tone: "cyan", glyph: "gift", detail: "Sent 1 shop gift." },
  { id: "gift-backer", name: "Backer", at: 2, tone: "cyan", glyph: "gift", detail: "Sent 2 shop gifts." },
  { id: "gift-patron", name: "Patron", at: 3, tone: "gold", glyph: "gift", detail: "Sent 3 shop gifts." },
  { id: "gift-benefactor", name: "Benefactor", at: 6, tone: "gold", glyph: "gift", detail: "Sent 6 shop gifts." },
  { id: "gift-keeper", name: "Keeper", at: 10, tone: "violet", glyph: "gift", detail: "Sent 10 shop gifts." },
  { id: "gift-legend", name: "Legend", at: 20, tone: "magenta", glyph: "gift", detail: "Sent 20 shop gifts." },
];

const HOURS: Step[] = [
  { id: "hours-scout", name: "Scout", at: 1, tone: "cyan", glyph: "clock", detail: "1 hour on record." },
  { id: "hours-regular", name: "Regular", at: 20, tone: "cyan", glyph: "clock", detail: "20 hours on record." },
  { id: "hours-devoted", name: "Devoted", at: 75, tone: "gold", glyph: "clock", detail: "75 hours on record." },
  { id: "hours-veteran", name: "Veteran", at: 300, tone: "gold", glyph: "clock", detail: "300 hours on record." },
  { id: "hours-iron", name: "Iron", at: 1000, tone: "violet", glyph: "clock", detail: "1,000 hours on record." },
  { id: "hours-mythic", name: "Mythic", at: 2000, tone: "magenta", glyph: "clock", detail: "2,000 hours on record." },
];

const LIBRARY: Step[] = [
  { id: "lib-pair", name: "Pair", at: 2, tone: "cyan", glyph: "maps", detail: "Played 2 games on record." },
  { id: "lib-circuit", name: "Circuit", at: 5, tone: "cyan", glyph: "maps", detail: "Played 5 games on record." },
  { id: "lib-range", name: "Range", at: 10, tone: "gold", glyph: "maps", detail: "Played 10 games on record." },
  { id: "lib-atlas", name: "Atlas", at: 20, tone: "violet", glyph: "maps", detail: "Played 20 games on record." },
];

const RALLY: Step[] = [
  { id: "rally-1", name: "Rally", at: 2, tone: "cyan", glyph: "chevron", detail: "Group has 2 players." },
  { id: "rally-2", name: "Banner", at: 4, tone: "gold", glyph: "chevron", detail: "Group has 4 players." },
  { id: "rally-3", name: "Keep", at: 8, tone: "violet", glyph: "chevron", detail: "Group has 8 players." },
];

const RECORD: Record<string, { seasons: number; gifts: number; hours: number; games: number }> = {
  koba_mara: { seasons: 4, gifts: 6, hours: 320, games: 8 },
  koba_harrow: { seasons: 6, gifts: 12, hours: 900, games: 14 },
  koba_dex: { seasons: 1, gifts: 0, hours: 40, games: 3 },
  koba_nora: { seasons: 3, gifts: 2, hours: 1400, games: 22 },
  koba_ysolde: { seasons: 5, gifts: 1, hours: 180, games: 6 },
};

function pin(step: Step, group: string): Pin {
  return { id: step.id, name: step.name, group, detail: step.detail, tone: step.tone, glyph: step.glyph, mark: String(step.at) };
}

function climb(steps: Step[], value: number, group: string, label: string, unit: string): LadderView {
  let current: Step | null = null;
  for (const step of steps) {
    if (value >= step.at) current = step;
  }
  const next = steps.find((step) => step.at > value) ?? null;
  return {
    id: group,
    label,
    unit,
    value,
    current: current ? pin(current, group) : null,
    next: next ? pin(next, group) : null,
    nextAt: next?.at ?? null,
  };
}

export interface BadgeSource {
  id: string;
  score: number;
  status: string;
  strikes: number;
  warnings: number;
  homes: number;
  steam?: string;
  engineBadges: string[];
  verified: boolean;
  business: boolean;
  subscribed: boolean;
  ownsGroup: boolean;
  officer: boolean;
  house: "wake" | "north" | null;
  groupMembers: number;
  marks: { id: string; name: string; detail: string; rare: boolean }[];
}

export function resolveBadges(source: BadgeSource): BadgeResult {
  const record = RECORD[source.id] ?? { seasons: 1, gifts: 0, hours: 1, games: 2 };
  const earned: Pin[] = [];

  if (source.verified) {
    earned.push({ id: "verified", name: "Verified", group: "Standing", detail: "Verified account. The shop fee is 2.5%.", tone: "cyan", glyph: "seal" });
  }
  if (source.subscribed) {
    earned.push({ id: "astro", name: "Astro", group: "Standing", detail: "Astro pass is active. Cosmetics can be applied.", tone: "ok", glyph: "comet" });
  }
  if (source.business) {
    earned.push({ id: "business", name: "Business", group: "Standing", detail: "Business account. Can list on the Official shop.", tone: "gold", glyph: "diamond" });
  }
  if (source.ownsGroup || source.engineBadges.includes("Clan lead")) {
    earned.push({ id: "founder", name: "Founder", group: "Standing", detail: "Owns a group, or leads a clan.", tone: "violet", glyph: "crown" });
  } else if (source.officer) {
    earned.push({ id: "officer", name: "Officer", group: "Standing", detail: "Officer role in a group.", tone: "cyan", glyph: "chevron" });
  }
  if (source.score >= 2000 || source.engineBadges.includes("Ranked")) {
    earned.push({ id: "ranked", name: "Ranked", group: "Standing", detail: "Top of the current board.", tone: "gold", glyph: "laurel" });
  }
  if (source.house === "wake") {
    earned.push({ id: "house-wake", name: "Wake", group: "House", detail: "House of IRONWAKE.", tone: "cyan", glyph: "wave" });
  }
  if (source.house === "north") {
    earned.push({ id: "house-north", name: "North", group: "House", detail: "House of NORTHLINE.", tone: "violet", glyph: "peak" });
  }

  const ladders = [
    climb(SEASONS, record.seasons, "Season", "Seasons", "seasons"),
    climb(GIFTS, record.gifts, "Gifts", "Gifts", "gifts"),
    climb(HOURS, record.hours, "Hours", "Hours", "hours"),
    climb(LIBRARY, record.games, "Library", "Library", "games"),
    climb(RALLY, source.groupMembers, "Group", "Group", "players"),
  ];

  for (const ladder of ladders) {
    if (ladder.current && ladder.id !== "Group") earned.push(ladder.current);
  }
  const rally = ladders.find((ladder) => ladder.id === "Group");
  if (rally?.current && source.groupMembers > 0) earned.push(rally.current);

  if (source.status === "clear" && source.strikes === 0 && source.warnings === 0) {
    earned.push({ id: "clear", name: "Clear", group: "Marks", detail: "No warnings and no strikes.", tone: "ok", glyph: "seal" });
  }
  if (source.homes >= 2) {
    earned.push({ id: "camps", name: "Twin camp", group: "Marks", detail: "Two homes set.", tone: "cyan", glyph: "mark" });
  }
  if (source.steam) {
    earned.push({ id: "linked", name: "Linked", group: "Marks", detail: "Steam is linked on this identity.", tone: "muted", glyph: "hex" });
  }
  for (const mark of source.marks) {
    earned.push({
      id: `mark-${mark.id}`,
      name: mark.name,
      group: "Marks",
      detail: mark.detail,
      tone: mark.rare ? "gold" : "ok",
      glyph: "mark",
    });
  }

  const preferred = ["verified", "astro", "business", "house-wake", "house-north", "founder", "officer", "ranked"];
  const head = preferred.flatMap((id) => {
    const found = earned.find((item) => item.id === id);
    return found ? [found] : [];
  });
  const season = ladders.find((ladder) => ladder.id === "Season")?.current;
  const gift = ladders.find((ladder) => ladder.id === "Gifts")?.current;
  const featured = [...head.slice(0, 4), ...(season ? [season] : []), ...(gift ? [gift] : [])].slice(0, 6);

  return { featured, earned, ladders };
}

export function sourceFor(
  identity: {
    id: string;
    score: number;
    status: string;
    strikes: number;
    warnings: number;
    homes: { name: string }[];
    steamId?: string;
    badges: string[];
    clanId?: string;
  },
  standing: { verified: boolean; business: boolean },
  flags: { subscribed: boolean; ownsGroup: boolean; officer: boolean; groupId?: string; groupMembers: number },
  marks: { id: string; name: string; detail: string; rare: boolean }[],
): BadgeSource {
  const house: "wake" | "north" | null =
    flags.groupId === "grp-north" ? "north" : flags.groupId === "grp-iron" ? "wake" : identity.clanId === "northline" ? "north" : identity.clanId === "ironwake" ? "wake" : null;
  return {
    id: identity.id,
    score: identity.score,
    status: identity.status,
    strikes: identity.strikes,
    warnings: identity.warnings,
    homes: identity.homes.length,
    steam: identity.steamId,
    engineBadges: identity.badges,
    verified: standing.verified,
    business: standing.business,
    subscribed: flags.subscribed,
    ownsGroup: flags.ownsGroup,
    officer: flags.officer,
    house,
    groupMembers: flags.groupMembers,
    marks,
  };
}
