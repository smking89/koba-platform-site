export type GameId = "all" | "rust" | "dayz";
export type Region = "NA" | "EU" | "OCE";
export type PlayStyle = "Survival" | "Tactical" | "Social" | "Hardcore";

export interface Listing {
  id: string;
  name: string;
  game: "Rust Console" | "DayZ";
  gameId: Exclude<GameId, "all">;
  platform: "Console" | "PC";
  region: Region;
  players: number;
  cap: number;
  tags: string[];
  style: PlayStyle;
  blurb: string;
  rating: string;
}

export interface LfgPost {
  id: string;
  identityId: string;
  listingId: string;
  need: string;
}

export interface Bounty {
  id: string;
  title: string;
  game: string;
  reward: number;
  window: string;
  detail: string;
}

export interface Achievement {
  id: string;
  name: string;
  detail: string;
  rare: boolean;
}

export interface PlayerMeta {
  region: Region;
  dayzScore: number;
  achievements: Achievement[];
}

export const LISTINGS: Listing[] = [
  {
    id: "srv-iron",
    name: "IRONWAKE Harbor",
    game: "Rust Console",
    gameId: "rust",
    platform: "Console",
    region: "NA",
    players: 84,
    cap: 100,
    tags: ["Monthly wipe", "Vanilla+", "Active admins"],
    style: "Survival",
    blurb: "Harbor monuments, a quiet south road, and a clan that actually answers LFG.",
    rating: "4.6",
  },
  {
    id: "srv-rig",
    name: "Rig 19",
    game: "Rust Console",
    gameId: "rust",
    platform: "Console",
    region: "NA",
    players: 67,
    cap: 100,
    tags: ["Monuments", "No offline raid"],
    style: "Tactical",
    blurb: "Oil and rig cycles on a timer. Teams that show up late lose the puzzle.",
    rating: "4.5",
  },
  {
    id: "srv-north",
    name: "Northline Ice",
    game: "Rust Console",
    gameId: "rust",
    platform: "Console",
    region: "EU",
    players: 41,
    cap: 80,
    tags: ["Hardcore", "No team cap"],
    style: "Hardcore",
    blurb: "Cold north, thin loot, and wars that last the whole wipe.",
    rating: "4.2",
  },
  {
    id: "srv-salt",
    name: "Saltflat",
    game: "Rust Console",
    gameId: "rust",
    platform: "Console",
    region: "OCE",
    players: 12,
    cap: 50,
    tags: ["Builders", "Low pop"],
    style: "Social",
    blurb: "A smaller map for crews who would rather build than snowball.",
    rating: "4.0",
  },
  {
    id: "srv-cherno",
    name: "Cherno Line",
    game: "DayZ",
    gameId: "dayz",
    platform: "PC",
    region: "EU",
    players: 36,
    cap: 60,
    tags: ["Fresh spawns", "Medical trade"],
    style: "Tactical",
    blurb: "Coastal runs with a clinic at the north end of the line.",
    rating: "4.4",
  },
  {
    id: "srv-black",
    name: "Black Coast",
    game: "DayZ",
    gameId: "dayz",
    platform: "PC",
    region: "NA",
    players: 58,
    cap: 70,
    tags: ["Low loot", "Night raids"],
    style: "Hardcore",
    blurb: "The coast is loud. The inland stashes are why people stay.",
    rating: "4.7",
  },
];

export const LFG: LfgPost[] = [
  { id: "lfg-1", identityId: "koba_mara", listingId: "srv-iron", need: "Duo for the harbor puzzle. Mics on, no random door camp." },
  { id: "lfg-2", identityId: "koba_dex", listingId: "srv-rig", need: "Three for oil. Bring satchels, not a speech." },
  { id: "lfg-3", identityId: "koba_ysolde", listingId: "srv-north", need: "NORTHLINE is recruiting one more for the ice war." },
  { id: "lfg-4", identityId: "koba_nora", listingId: "srv-black", need: "Quiet inland run. I have the route, I need a second rifle." },
];

export const BOUNTIES: Bounty[] = [
  { id: "b-harbor", title: "Harbor headshots", game: "Rust Console", reward: 40, window: "Ends this wipe", detail: "Five headshots on IRONWAKE Harbor." },
  { id: "b-night", title: "Cherno night", game: "DayZ", reward: 25, window: "Ends in 6 days", detail: "Survive one full night on Cherno Line without a clinic." },
  { id: "b-blood", title: "First blood", game: "Clan war", reward: 60, window: "While a war is live", detail: "Your clan draws first blood in a declared war." },
];

export const PLAYER_META: Record<string, PlayerMeta> = {
  koba_mara: {
    region: "NA",
    dayzScore: 1720,
    achievements: [
      { id: "a1", name: "Harbor regular", detail: "Thirty sessions on IRONWAKE.", rare: false },
      { id: "a2", name: "Astro", detail: "Season mark for form that kept rising.", rare: true },
    ],
  },
  koba_harrow: {
    region: "NA",
    dayzScore: 1804,
    achievements: [{ id: "a3", name: "Clan lead", detail: "IRONWAKE roster held through a wipe.", rare: false }],
  },
  koba_dex: {
    region: "EU",
    dayzScore: 1696,
    achievements: [{ id: "a4", name: "Warned, still queued", detail: "One warning on file. Still on the ladder.", rare: false }],
  },
  koba_nora: {
    region: "NA",
    dayzScore: 2174,
    achievements: [
      { id: "a5", name: "Ranked", detail: "Top of the current board.", rare: true },
      { id: "a6", name: "Unattached", detail: "No clan. Still the score to beat.", rare: false },
    ],
  },
  koba_ysolde: {
    region: "EU",
    dayzScore: 1992,
    achievements: [{ id: "a7", name: "Ice lead", detail: "NORTHLINE still answers.", rare: false }],
  },
};

export function metaFor(id: string, fallbackScore: number): PlayerMeta {
  return (
    PLAYER_META[id] ?? {
      region: "NA",
      dayzScore: fallbackScore,
      achievements: [],
    }
  );
}

export function scoreFor(id: string, base: number, game: GameId): number {
  if (game === "dayz") return metaFor(id, base).dayzScore;
  return base;
}

export interface WipeClock {
  wiped: string;
  next: string;
  groups: string;
  gather: string;
}

export const WIPE: Record<string, WipeClock> = {
  "srv-iron": { wiped: "14h ago", next: "6d", groups: "8", gather: "1.5x" },
  "srv-rig": { wiped: "2d ago", next: "5d", groups: "4", gather: "2x" },
  "srv-north": { wiped: "6h ago", next: "13d", groups: "No cap", gather: "1x" },
  "srv-salt": { wiped: "9d ago", next: "21d", groups: "4", gather: "1x" },
  "srv-cherno": { wiped: "1d ago", next: "Tonight", groups: "3", gather: "1x" },
  "srv-black": { wiped: "4h ago", next: "2d", groups: "2", gather: "Low" },
};

export function wipeFor(id: string): WipeClock {
  return WIPE[id] ?? { wiped: "Unknown", next: "Unposted", groups: "Any", gather: "1x" };
}

export interface WipeEvent {
  id: string;
  listingId: string;
  title: string;
  when: string;
  cap: number;
  filled: number;
}

export const WIPE_EVENTS: WipeEvent[] = [
  { id: "ev-iron", listingId: "srv-iron", title: "IRONWAKE wipe night", when: "Fri 20:00 NA", cap: 40, filled: 28 },
  { id: "ev-rig", listingId: "srv-rig", title: "Rig 19 puzzle hour", when: "Sat 18:00 NA", cap: 12, filled: 9 },
  { id: "ev-cherno", listingId: "srv-cherno", title: "Cherno night run", when: "Sun 21:00 EU", cap: 8, filled: 5 },
];

export interface Clip {
  id: string;
  listingId: string;
  identityId: string;
  title: string;
  length: string;
}

export const CLIPS: Clip[] = [
  { id: "clip-harbor", listingId: "srv-iron", identityId: "koba_mara", title: "Harbor door camp", length: "0:18" },
  { id: "clip-rig", listingId: "srv-rig", identityId: "koba_harrow", title: "Oil timer", length: "0:12" },
  { id: "clip-coast", listingId: "srv-black", identityId: "koba_nora", title: "Coast shot", length: "0:21" },
  { id: "clip-ice", listingId: "srv-north", identityId: "koba_ysolde", title: "Ice push", length: "0:16" },
];

export interface Party {
  id: string;
  name: string;
  gameId: Exclude<GameId, "all">;
  region: Region;
  mic: "on" | "off";
  size: number;
  filled: number;
  hours: "day" | "night";
  listingId: string;
}

export const PARTIES: Party[] = [
  { id: "pty-1", name: "Harbor duo", gameId: "rust", region: "NA", mic: "on", size: 2, filled: 1, hours: "night", listingId: "srv-iron" },
  { id: "pty-2", name: "Rig quad", gameId: "rust", region: "NA", mic: "on", size: 4, filled: 3, hours: "night", listingId: "srv-rig" },
  { id: "pty-3", name: "Ice line", gameId: "rust", region: "EU", mic: "on", size: 3, filled: 2, hours: "day", listingId: "srv-north" },
  { id: "pty-4", name: "Salt builders", gameId: "rust", region: "OCE", mic: "off", size: 4, filled: 2, hours: "day", listingId: "srv-salt" },
  { id: "pty-5", name: "Cherno clinic", gameId: "dayz", region: "EU", mic: "on", size: 2, filled: 1, hours: "night", listingId: "srv-cherno" },
  { id: "pty-6", name: "Black coast", gameId: "dayz", region: "NA", mic: "on", size: 3, filled: 2, hours: "night", listingId: "srv-black" },
];

