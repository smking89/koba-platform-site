import { create } from "zustand";

export type ChannelKind = "text" | "voice";

export interface Role {
  id: string;
  groupId: string;
  name: string;
  rank: number;
}

export interface Category {
  id: string;
  groupId: string;
  name: string;
  rank: number;
}

export interface Channel {
  id: string;
  groupId: string;
  categoryId: string;
  name: string;
  kind: ChannelKind;
  rank: number;
}

export interface RoomMessage {
  id: string;
  authorId: string;
  text: string;
}

export interface DirectMessage {
  id: string;
  authorId: string;
  text: string;
  sticker?: string;
  packTitle?: string;
  kind?: "text" | "sticker" | "gif" | "location" | "draw" | "photo" | "voice";
  payload?: string;
  at?: number;
}

export interface DirectThread {
  id: string;
  a: string;
  b: string;
  messages: DirectMessage[];
}

export interface Story {
  id: string;
  authorId: string;
  text: string;
  sticker?: string;
}

export interface Sticker {
  id: string;
  name: string;
  tone: "ok" | "cyan" | "gold";
}

export interface StickerPack {
  id: string;
  productId: string;
  title: string;
  stickers: Sticker[];
}

interface CommunityState {
  groups: { id: string; name: string; tag: string; ownerId: string }[];
  roles: Role[];
  members: { groupId: string; identityId: string; roleId: string }[];
  categories: Category[];
  channels: Channel[];
  rooms: Record<string, RoomMessage[]>;
  directs: DirectThread[];
  stories: Story[];
  astroPass: string[];
  owned: Record<string, string[]>;
  equipped: Record<string, string | null>;
  packs: StickerPack[];
  ownedPacks: Record<string, string[]>;
  seq: number;
  activeGroup: string;
  activeChannel: string;
  activeThread: string;
  setActiveGroup: (id: string) => void;
  setActiveChannel: (id: string) => void;
  setActiveThread: (id: string) => void;
  createGroup: (ownerId: string, name: string) => void;
  joinGroup: (groupId: string, identityId: string) => void;
  addCategory: (groupId: string, identityId: string, name: string) => string | null;
  addChannel: (groupId: string, identityId: string, categoryId: string, name: string, kind: ChannelKind) => string | null;
  addRole: (groupId: string, identityId: string, name: string) => string | null;
  moveRole: (groupId: string, identityId: string, roleId: string, direction: -1 | 1) => void;
  postRoom: (channelId: string, authorId: string, text: string) => void;
  openThread: (selfId: string, otherId: string) => string;
  sendDirect: (threadId: string, authorId: string, text: string, sticker?: { name: string; packTitle: string }, extra?: { kind?: DirectMessage["kind"]; payload?: string }) => void;
  addStory: (authorId: string, text: string, sticker?: string) => void;
  subscribe: (identityId: string) => void;
  endPass: (identityId: string) => void;
  grantProduct: (identityId: string, productId: string, kind: string, title: string, stickerNames?: string[]) => void;
  equip: (identityId: string, productId: string) => boolean;
  clearEquip: (identityId: string) => void;
  canManage: (groupId: string, identityId: string) => boolean;
  reset: () => void;
}

const SEED_PACK: StickerPack = {
  id: "pack-harbor",
  productId: "prd-marks",
  title: "Harbor marks",
  stickers: [
    { id: "stk-mark", name: "Mark", tone: "ok" },
    { id: "stk-lane", name: "Lane", tone: "cyan" },
    { id: "stk-hold", name: "Hold", tone: "gold" },
    { id: "stk-clear", name: "Clear", tone: "ok" },
  ],
};

function seed(): Omit<
  CommunityState,
  | "setActiveGroup"
  | "setActiveChannel"
  | "setActiveThread"
  | "createGroup"
  | "joinGroup"
  | "addCategory"
  | "addChannel"
  | "addRole"
  | "moveRole"
  | "postRoom"
  | "openThread"
  | "sendDirect"
  | "addStory"
  | "subscribe"
  | "endPass"
  | "grantProduct"
  | "equip"
  | "clearEquip"
  | "canManage"
  | "reset"
> {
  return {
    groups: [
      { id: "grp-iron", name: "IRONWAKE", tag: "IRN", ownerId: "koba_harrow" },
      { id: "grp-north", name: "NORTHLINE", tag: "NTH", ownerId: "koba_ysolde" },
    ],
    roles: [
      { id: "role-iron-owner", groupId: "grp-iron", name: "Owner", rank: 3 },
      { id: "role-iron-officer", groupId: "grp-iron", name: "Officer", rank: 2 },
      { id: "role-iron-member", groupId: "grp-iron", name: "Member", rank: 1 },
      { id: "role-north-owner", groupId: "grp-north", name: "Owner", rank: 3 },
      { id: "role-north-member", groupId: "grp-north", name: "Member", rank: 1 },
    ],
    members: [
      { groupId: "grp-iron", identityId: "koba_harrow", roleId: "role-iron-owner" },
      { groupId: "grp-iron", identityId: "koba_mara", roleId: "role-iron-officer" },
      { groupId: "grp-iron", identityId: "koba_nora", roleId: "role-iron-member" },
      { groupId: "grp-north", identityId: "koba_ysolde", roleId: "role-north-owner" },
      { groupId: "grp-north", identityId: "koba_dex", roleId: "role-north-member" },
    ],
    categories: [
      { id: "cat-iron-text", groupId: "grp-iron", name: "Text", rank: 1 },
      { id: "cat-iron-voice", groupId: "grp-iron", name: "Voice", rank: 2 },
      { id: "cat-north-text", groupId: "grp-north", name: "Text", rank: 1 },
    ],
    channels: [
      { id: "ch-general", groupId: "grp-iron", categoryId: "cat-iron-text", name: "general", kind: "text", rank: 1 },
      { id: "ch-lfg", groupId: "grp-iron", categoryId: "cat-iron-text", name: "lfg", kind: "text", rank: 2 },
      { id: "ch-harbor", groupId: "grp-iron", categoryId: "cat-iron-voice", name: "harbor", kind: "voice", rank: 1 },
      { id: "ch-ops", groupId: "grp-iron", categoryId: "cat-iron-voice", name: "ops", kind: "voice", rank: 2 },
      { id: "ch-north", groupId: "grp-north", categoryId: "cat-north-text", name: "line", kind: "text", rank: 1 },
    ],
    rooms: {
      "ch-general": [
        { id: "rm-1", authorId: "koba_harrow", text: "Harbor window is open until 22:00. Bring a kit." },
        { id: "rm-2", authorId: "koba_mara", text: "Supply drop is listed. Don't stack the same call." },
      ],
      "ch-lfg": [{ id: "rm-3", authorId: "koba_nora", text: "Duo for a short scrap run. No hero plays." }],
      "ch-north": [{ id: "rm-4", authorId: "koba_ysolde", text: "North road is quiet. Stay off the ridge." }],
    },
    directs: [
      {
        id: "dm-mara-harrow",
        a: "koba_mara",
        b: "koba_harrow",
        messages: [
          { id: "dm-1", authorId: "koba_harrow", text: "You still running harbor tonight?" },
          { id: "dm-2", authorId: "koba_mara", text: "Yes. Take this.", sticker: "Hold", packTitle: "Harbor marks" },
        ],
      },
    ],
    stories: [
      { id: "story-1", authorId: "koba_mara", text: "Harbor window is live.", sticker: "Mark" },
      { id: "story-2", authorId: "koba_nora", text: "Looking for one more on the south road." },
    ],
    astroPass: ["koba_mara"],
    owned: { koba_mara: ["prd-harbor"] },
    equipped: { koba_mara: "prd-harbor" },
    packs: [SEED_PACK],
    ownedPacks: { koba_mara: ["pack-harbor"] },
    seq: 40,
    activeGroup: "grp-iron",
    activeChannel: "ch-general",
    activeThread: "dm-mara-harrow",
  };
}

function nextId(seq: number, prefix: string) {
  return `${prefix}-${seq}`;
}

export const useCommunity = create<CommunityState>((set, get) => ({
  ...seed(),
  setActiveGroup: (id) => {
    const channel = get().channels.find((item) => item.groupId === id);
    set({ activeGroup: id, activeChannel: channel?.id ?? get().activeChannel });
  },
  setActiveChannel: (id) => set({ activeChannel: id }),
  setActiveThread: (id) => set({ activeThread: id }),
  canManage: (groupId, identityId) => {
    const group = get().groups.find((item) => item.id === groupId);
    if (!group) return false;
    if (group.ownerId === identityId) return true;
    const member = get().members.find((item) => item.groupId === groupId && item.identityId === identityId);
    if (!member) return false;
    const role = get().roles.find((item) => item.id === member.roleId);
    return (role?.rank ?? 0) >= 2;
  },
  createGroup: (ownerId, name) =>
    set((state) => {
      const trimmed = name.trim();
      if (trimmed.length < 2) return state;
      const seq = state.seq + 1;
      const id = nextId(seq, "grp");
      const roleId = nextId(seq, "role");
      const categoryId = nextId(seq, "cat");
      const channelId = nextId(seq, "ch");
      return {
        seq,
        groups: [...state.groups, { id, name: trimmed.slice(0, 24), tag: trimmed.slice(0, 3).toUpperCase(), ownerId }],
        roles: [...state.roles, { id: roleId, groupId: id, name: "Owner", rank: 3 }],
        members: [...state.members, { groupId: id, identityId: ownerId, roleId }],
        categories: [...state.categories, { id: categoryId, groupId: id, name: "Text", rank: 1 }],
        channels: [...state.channels, { id: channelId, groupId: id, categoryId, name: "general", kind: "text", rank: 1 }],
        rooms: { ...state.rooms, [channelId]: [] },
        activeGroup: id,
        activeChannel: channelId,
      };
    }),
  joinGroup: (groupId, identityId) =>
    set((state) => {
      if (state.members.some((item) => item.groupId === groupId && item.identityId === identityId)) return state;
      const roles = state.roles.filter((item) => item.groupId === groupId).sort((a, b) => a.rank - b.rank);
      const role = roles[0];
      if (!role) return state;
      return { members: [...state.members, { groupId, identityId, roleId: role.id }] };
    }),
  addCategory: (groupId, identityId, name) => {
    if (!get().canManage(groupId, identityId)) return null;
    const trimmed = name.trim();
    if (trimmed.length < 2) return null;
    const seq = get().seq + 1;
    const id = nextId(seq, "cat");
    const rank = get().categories.filter((item) => item.groupId === groupId).length + 1;
    set((state) => ({
      seq,
      categories: [...state.categories, { id, groupId, name: trimmed.slice(0, 24), rank }],
    }));
    return id;
  },
  addChannel: (groupId, identityId, categoryId, name, kind) => {
    if (!get().canManage(groupId, identityId)) return null;
    const trimmed = name.trim().toLowerCase().replace(/\s+/g, "-");
    if (trimmed.length < 2) return null;
    const seq = get().seq + 1;
    const id = nextId(seq, "ch");
    const rank = get().channels.filter((item) => item.categoryId === categoryId).length + 1;
    set((state) => ({
      seq,
      channels: [...state.channels, { id, groupId, categoryId, name: trimmed.slice(0, 24), kind, rank }],
      rooms: { ...state.rooms, [id]: [] },
      activeChannel: id,
    }));
    return id;
  },
  addRole: (groupId, identityId, name) => {
    if (!get().canManage(groupId, identityId)) return null;
    const trimmed = name.trim();
    if (trimmed.length < 2) return null;
    const seq = get().seq + 1;
    const id = nextId(seq, "role");
    const lowest = get()
        .roles.filter((item) => item.groupId === groupId && item.name !== "Owner")
        .reduce((min, role) => Math.min(min, role.rank), 2);
      set((state) => ({
        seq,
        roles: [...state.roles, { id, groupId, name: trimmed.slice(0, 24), rank: Math.max(1, lowest) }],
      }));
    return id;
  },
  moveRole: (groupId, identityId, roleId, direction) =>
    set((state) => {
      if (!state.canManage(groupId, identityId)) return state;
      const group = state.groups.find((item) => item.id === groupId);
      const role = state.roles.find((item) => item.id === roleId);
      if (!group || !role || role.groupId !== groupId) return state;
      if (role.name === "Owner") return state;
      const sibling = state.roles
        .filter((item) => item.groupId === groupId && item.id !== roleId && item.name !== "Owner")
        .filter((item) => (direction < 0 ? item.rank > role.rank : item.rank < role.rank))
        .sort((a, b) => (direction < 0 ? a.rank - b.rank : b.rank - a.rank))[0];
      if (!sibling) return state;
      return {
        roles: state.roles.map((item) => {
          if (item.id === role.id) return { ...item, rank: sibling.rank };
          if (item.id === sibling.id) return { ...item, rank: role.rank };
          return item;
        }),
      };
    }),
  postRoom: (channelId, authorId, text) =>
    set((state) => {
      const trimmed = text.trim();
      if (!trimmed) return state;
      const seq = state.seq + 1;
      const current = state.rooms[channelId] ?? [];
      return {
        seq,
        rooms: { ...state.rooms, [channelId]: [...current, { id: nextId(seq, "rm"), authorId, text: trimmed.slice(0, 240) }] },
      };
    }),
  openThread: (selfId, otherId) => {
    const existing = get().directs.find(
      (thread) => (thread.a === selfId && thread.b === otherId) || (thread.a === otherId && thread.b === selfId),
    );
    if (existing) {
      set({ activeThread: existing.id });
      return existing.id;
    }
    const seq = get().seq + 1;
    const id = nextId(seq, "dm");
    set((state) => ({
      seq,
      directs: [...state.directs, { id, a: selfId, b: otherId, messages: [] }],
      activeThread: id,
    }));
    return id;
  },
  sendDirect: (threadId, authorId, text, sticker, extra) =>
    set((state) => {
      const trimmed = text.trim();
      if (!trimmed && !sticker && !extra?.payload) return state;
      const seq = state.seq + 1;
      return {
        seq,
        directs: state.directs.map((thread) =>
          thread.id === threadId
            ? {
                ...thread,
                messages: [
                  ...thread.messages,
                  {
                    id: nextId(seq, "dmmsg"),
                    authorId,
                    text: trimmed.slice(0, 240),
                    sticker: sticker?.name,
                    packTitle: sticker?.packTitle,
                    kind: extra?.kind ?? (sticker ? "sticker" : "text"),
                    payload: extra?.payload,
                    at: Date.now(),
                  },
                ],
              }
            : thread,
        ),
      };
    }),
  addStory: (authorId, text, sticker) =>
    set((state) => {
      const trimmed = text.trim();
      if (!trimmed && !sticker) return state;
      const seq = state.seq + 1;
      return {
        seq,
        stories: [{ id: nextId(seq, "story"), authorId, text: trimmed.slice(0, 140) || "Sticker", sticker }, ...state.stories],
      };
    }),
  subscribe: (identityId) =>
    set((state) => ({ astroPass: state.astroPass.includes(identityId) ? state.astroPass : [...state.astroPass, identityId] })),
  endPass: (identityId) =>
    set((state) => ({
      astroPass: state.astroPass.filter((id) => id !== identityId),
      equipped: { ...state.equipped, [identityId]: null },
    })),
  grantProduct: (identityId, productId, kind, title, stickerNames) =>
    set((state) => {
      if (kind === "sticker-pack") {
        const existing = state.packs.find((pack) => pack.productId === productId);
        const seq = state.seq + 1;
        const fallback = ["Mark", "Lane", "Hold", "Clear"];
        const source = stickerNames && stickerNames.length >= 4 ? stickerNames : fallback;
        const tones = ["ok", "cyan", "gold", "ok"] as const;
        const pack =
          existing ??
          ({
            id: nextId(seq, "pack"),
            productId,
            title,
            stickers: source.slice(0, 8).map((name, index) => ({
              id: `${nextId(seq, "stk")}-${index}`,
              name: name.replace(/\.[a-z0-9]+$/i, "").slice(0, 16) || `Sticker ${index + 1}`,
              tone: tones[index % tones.length],
            })),
          } satisfies StickerPack);
        const mine = state.ownedPacks[identityId] ?? [];
        return {
          seq: existing ? state.seq : seq,
          packs: existing ? state.packs : [...state.packs, pack],
          ownedPacks: { ...state.ownedPacks, [identityId]: mine.includes(pack.id) ? mine : [...mine, pack.id] },
        };
      }
      const mine = state.owned[identityId] ?? [];
      if (mine.includes(productId)) return state;
      return { owned: { ...state.owned, [identityId]: [...mine, productId] } };
    }),
  equip: (identityId, productId) => {
    const state = get();
    if (!state.astroPass.includes(identityId)) return false;
    if (!(state.owned[identityId] ?? []).includes(productId)) return false;
    set({ equipped: { ...state.equipped, [identityId]: productId } });
    return true;
  },
  clearEquip: (identityId) => set((state) => ({ equipped: { ...state.equipped, [identityId]: null } })),
  reset: () => set(seed()),
}));
