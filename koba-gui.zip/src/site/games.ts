export type Device = "PC" | "Console" | "Mobile" | "Web";
export type Connector = "Plugin" | "REST" | "Logs" | "Match API";

export interface SupportedGame {
  id: string;
  name: string;
  devices: Device[];
  connector: Connector;
  reach: "Strong" | "Good" | "Limited" | "Read";
}

/** Titles the connector blueprint can onboard. Not a fake server list. */
export const SUPPORTED_GAMES: SupportedGame[] = [
  { id: "ARK", name: "ARK: Survival Ascended", devices: ["PC", "Console"], connector: "Plugin", reach: "Strong" },
  { id: "RUST", name: "Rust", devices: ["PC"], connector: "Plugin", reach: "Strong" },
  { id: "RUST_CONSOLE", name: "Rust Console", devices: ["Console"], connector: "Plugin", reach: "Strong" },
  { id: "MINECRAFT", name: "Minecraft", devices: ["PC", "Mobile", "Console"], connector: "Plugin", reach: "Strong" },
  { id: "PALWORLD", name: "Palworld", devices: ["PC", "Console"], connector: "REST", reach: "Good" },
  { id: "DAYZ", name: "DayZ", devices: ["PC", "Console"], connector: "Logs", reach: "Limited" },
  { id: "ENSHROUDED", name: "Enshrouded", devices: ["PC"], connector: "Logs", reach: "Limited" },
  { id: "CS2", name: "Counter-Strike 2", devices: ["PC"], connector: "Match API", reach: "Strong" },
  { id: "VALORANT", name: "Valorant", devices: ["PC", "Console"], connector: "Match API", reach: "Read" },
  { id: "VALHEIM", name: "Valheim", devices: ["PC"], connector: "Plugin", reach: "Good" },
  { id: "SCUM", name: "SCUM", devices: ["PC"], connector: "Plugin", reach: "Good" },
  { id: "UNTURNED", name: "Unturned", devices: ["PC"], connector: "Plugin", reach: "Good" },
  { id: "SEVEN_DAYS", name: "7 Days to Die", devices: ["PC", "Console"], connector: "Logs", reach: "Limited" },
  { id: "SATISFACTORY", name: "Satisfactory", devices: ["PC"], connector: "Plugin", reach: "Good" },
];

export function gameName(id: string) {
  return SUPPORTED_GAMES.find((game) => game.id === id)?.name ?? id;
}
