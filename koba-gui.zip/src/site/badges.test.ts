import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { resolveBadges, type BadgeSource } from "./badges.ts";

function source(patch: Partial<BadgeSource>): BadgeSource {
  return {
    id: "koba_mara",
    score: 1840,
    status: "clear",
    strikes: 0,
    warnings: 0,
    homes: 2,
    steam: "steam",
    engineBadges: [],
    verified: true,
    business: true,
    subscribed: true,
    ownsGroup: false,
    officer: true,
    house: "wake",
    groupMembers: 3,
    marks: [{ id: "a1", name: "Harbor regular", detail: "Thirty sessions.", rare: false }],
    ...patch,
  };
}

describe("koba badges", () => {
  it("puts verified, astro, and the top season on the name row", () => {
    const result = resolveBadges(source({}));
    const names = result.featured.map((pin) => pin.name);
    assert.ok(names.includes("Verified"));
    assert.ok(names.includes("Astro"));
    assert.ok(names.includes("Beacon"));
    assert.ok(names.includes("Benefactor"));
    assert.equal(result.featured.length <= 6, true);
  });

  it("does not give an unverified player the verified pin", () => {
    const result = resolveBadges(source({ id: "koba_dex", verified: false, business: true, subscribed: false, officer: false, house: "north", groupMembers: 2, score: 1896 }));
    assert.equal(result.earned.some((pin) => pin.id === "verified"), false);
    assert.equal(result.earned.some((pin) => pin.name === "Spark"), true);
    assert.equal(result.earned.some((pin) => pin.id.startsWith("gift-")), false);
  });

  it("awards ranked at 2000 and keeps only the highest hour mark", () => {
    const result = resolveBadges(source({ id: "koba_nora", score: 2144, subscribed: false, business: false, officer: false, house: "wake", groupMembers: 3 }));
    assert.ok(result.earned.some((pin) => pin.id === "ranked"));
    const hours = result.earned.filter((pin) => pin.glyph === "clock");
    assert.equal(hours.length, 1);
    assert.equal(hours[0]?.name, "Iron");
  });
});
