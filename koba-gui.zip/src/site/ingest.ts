export const TOKEN_TTL_MS = 15 * 60 * 1000;
export const RATE_WINDOW_MS = 10_000;
export const RATE_LIMIT = 6;
export const DOCUMENTED_CLOCK = 1792120740;

export const GAME_TYPES = ["RUST", "RUST_CONSOLE", "DAYZ", "ARK", "SEVEN_DAYS", "LOL", "VALORANT", "APEX", "CS2"] as const;
export const EVENT_TYPES = ["COMBAT_KILL", "OBJECTIVE", "SESSION_JOIN", "MATCH_END"] as const;

export type GameType = (typeof GAME_TYPES)[number];
export type EventType = (typeof EVENT_TYPES)[number];

export interface NormalizedEvent {
  integration_metadata: {
    koba_server_id: string;
    game_type: GameType;
    payload_timestamp_utc: number;
  };
  event_envelope: {
    event_type: EventType;
    cryptographic_signature: string;
    fps_at_execution: number;
  };
  data_payload: {
    actor_identity: string;
    target_identity: string;
    weapon_used: string;
    is_headshot: boolean;
    combat_distance_meters: number;
  };
}

export interface Gate {
  id: string;
  name: string;
  pass: boolean;
  detail: string;
}

export const SAMPLE_EVENT: NormalizedEvent = {
  integration_metadata: {
    koba_server_id: "srv_rust_us_east_091",
    game_type: "RUST_CONSOLE",
    payload_timestamp_utc: DOCUMENTED_CLOCK,
  },
  event_envelope: {
    event_type: "COMBAT_KILL",
    cryptographic_signature: "0x7f8a9cd3e2a14b80",
    fps_at_execution: 59.4,
  },
  data_payload: {
    actor_identity: "steam_76561198000000000",
    target_identity: "epic_4a8b2c3d4e5f6a7b",
    weapon_used: "AK47_RIFLE",
    is_headshot: true,
    combat_distance_meters: 142.5,
  },
};

const FORGERY = /<|>|script|javascript:|\$\{|onerror|`|\u0000/i;
const IDENTITY = /^(steam|epic|riot|psn|xbox|koba)_[A-Za-z0-9]{4,32}$/;
const WEAPON = /^[A-Z0-9_]{2,32}$/;
const SERVER = /^srv_[a-z0-9_]{4,48}$/;
const SIGNATURE = /^0x[0-9a-f]{16,64}$/i;

export function neutralize(value: string) {
  return value.replace(/[<>`${}]/g, "").replace(/javascript:/gi, "").replace(/\u0000/g, "").slice(0, 64);
}

function gate(id: string, name: string, pass: boolean, detail: string): Gate {
  return { id, name, pass, detail };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function inspectPayload(raw: string, nowSec: number): { gates: Gate[]; event: NormalizedEvent | null } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return {
      gates: [gate("json", "JSON parse", false, "The body is not JSON. Nothing was written.")],
      event: null,
    };
  }
  if (!isRecord(parsed)) {
    return { gates: [gate("json", "JSON parse", false, "The body must be an object.")], event: null };
  }
  const gates: Gate[] = [gate("json", "JSON parse", true, "Object parsed in the isolated layer.")];
  const meta = parsed.integration_metadata;
  const envelope = parsed.event_envelope;
  const data = parsed.data_payload;
  const extra = Object.keys(parsed).filter((key) => !["integration_metadata", "event_envelope", "data_payload"].includes(key));
  gates.push(
    gate(
      "shape",
      "Normalized shape",
      extra.length === 0 && isRecord(meta) && isRecord(envelope) && isRecord(data),
      extra.length ? `Drop unknown keys: ${extra.join(", ")}.` : "integration_metadata, event_envelope, and data_payload are present.",
    ),
  );
  if (!isRecord(meta) || !isRecord(envelope) || !isRecord(data)) return { gates, event: null };

  const serverId = meta.koba_server_id;
  const game = meta.game_type;
  const clock = meta.payload_timestamp_utc;
  const eventType = envelope.event_type;
  const signature = envelope.cryptographic_signature;
  const fps = envelope.fps_at_execution;
  const actor = data.actor_identity;
  const target = data.target_identity;
  const weapon = data.weapon_used;
  const headshot = data.is_headshot;
  const distance = data.combat_distance_meters;

  const strings = [serverId, game, eventType, signature, actor, target, weapon].filter((value): value is string => typeof value === "string");
  const dirty = strings.filter((value) => FORGERY.test(value));
  gates.push(
    gate(
      "forgery",
      "Forgery gate",
      dirty.length === 0,
      dirty.length ? `Rejected ${dirty.map(neutralize).join(", ") || "a control string"}. Markup is not stored.` : "Strings stayed inside the allowed alphabet.",
    ),
  );
  gates.push(gate("server", "Server id", typeof serverId === "string" && SERVER.test(serverId), "srv_ plus a short server key."));
  gates.push(
    gate("game", "Game type", typeof game === "string" && (GAME_TYPES as readonly string[]).includes(game), GAME_TYPES.join(", ")),
  );
  const fresh = typeof clock === "number" && (clock === DOCUMENTED_CLOCK || Math.abs(clock - nowSec) <= 15 * 60);
  gates.push(gate("clock", "Payload clock", fresh, fresh ? "Clock is the documented sample or within 15 minutes." : "Clock is stale or not a unix second."));
  gates.push(
    gate("event", "Event type", typeof eventType === "string" && (EVENT_TYPES as readonly string[]).includes(eventType), EVENT_TYPES.join(", ")),
  );
  gates.push(gate("signature", "Event signature", typeof signature === "string" && SIGNATURE.test(signature), "0x and 16 to 64 hex characters. The docs abbreviate this."));
  gates.push(gate("fps", "Frame time", typeof fps === "number" && fps >= 1 && fps <= 240, "Frames per second at execution, 1 to 240."));
  gates.push(gate("actor", "Actor identity", typeof actor === "string" && IDENTITY.test(actor), "steam_, epic_, riot_, psn_, xbox_, or koba_."));
  gates.push(gate("target", "Target identity", typeof target === "string" && IDENTITY.test(target), "Same identity shape as the actor."));
  gates.push(gate("weapon", "Weapon", typeof weapon === "string" && WEAPON.test(weapon), "Uppercase token such as AK47_RIFLE."));
  gates.push(gate("headshot", "Headshot flag", typeof headshot === "boolean", "true or false, not a string."));
  gates.push(gate("distance", "Distance", typeof distance === "number" && distance >= 0 && distance <= 2000, "Meters, 0 to 2000."));

  const event: NormalizedEvent | null =
    gates.every((item) => item.pass)
      ? {
          integration_metadata: { koba_server_id: serverId as string, game_type: game as GameType, payload_timestamp_utc: clock as number },
          event_envelope: { event_type: eventType as EventType, cryptographic_signature: signature as string, fps_at_execution: fps as number },
          data_payload: {
            actor_identity: actor as string,
            target_identity: target as string,
            weapon_used: weapon as string,
            is_headshot: headshot as boolean,
            combat_distance_meters: distance as number,
          },
        }
      : null;
  return { gates, event };
}

export function noteRate(hits: number[], nowMs: number) {
  const kept = hits.filter((stamp) => nowMs - stamp < RATE_WINDOW_MS);
  if (kept.length >= RATE_LIMIT) return { hits: kept, allowed: false };
  return { hits: [...kept, nowMs], allowed: true };
}

function b64url(bytes: Uint8Array) {
  let text = "";
  for (const byte of bytes) text += String.fromCharCode(byte);
  return btoa(text).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function b64urlDecode(value: string) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function hmac(secret: string, message: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message)));
  return b64url(mac);
}

export async function mintToken(kobaId: string, nowMs: number, secret: string) {
  const jtiBytes = new Uint8Array(9);
  crypto.getRandomValues(jtiBytes);
  const jti = [...jtiBytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  const exp = nowMs + TOKEN_TTL_MS;
  const body = b64url(new TextEncoder().encode(JSON.stringify({ kobaId, exp, jti })));
  const sig = await hmac(secret, body);
  return { token: `v1.${body}.${sig}`, jti, exp };
}

export async function readToken(token: string, nowMs: number, secret: string): Promise<{ ok: true; kobaId: string; jti: string; exp: number } | { ok: false; reason: "malformed" | "signature" | "expired" }> {
  const parts = token.split(".");
  if (parts.length !== 3 || parts[0] !== "v1") return { ok: false, reason: "malformed" };
  const expected = await hmac(secret, parts[1]);
  if (expected !== parts[2]) return { ok: false, reason: "signature" };
  let claims: { kobaId?: unknown; exp?: unknown; jti?: unknown };
  try {
    claims = JSON.parse(new TextDecoder().decode(b64urlDecode(parts[1])));
  } catch {
    return { ok: false, reason: "malformed" };
  }
  if (typeof claims.kobaId !== "string" || typeof claims.exp !== "number" || typeof claims.jti !== "string") return { ok: false, reason: "malformed" };
  if (claims.exp <= nowMs) return { ok: false, reason: "expired" };
  return { ok: true, kobaId: claims.kobaId, jti: claims.jti, exp: claims.exp };
}
