import { useEffect, useMemo, useState } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Chip } from "@/components/ui";
import { BadgeBoard } from "@/components/network/badges";
import { useResolvedBadges } from "@/components/network/badge-state";
import { CountUp } from "@/components/network/shared";
import { MotionPreview, VerifiedMark } from "@/components/network/shop";
import { formSeries, type DisciplineStatus, type Identity } from "@/platform/engine";
import { ASTRO_PRICE, formatCoins, quote, type AstroAccount } from "@/site/astro";
import { LISTINGS, metaFor, scoreFor } from "@/site/catalog";

const STATUS: Record<DisciplineStatus, { label: string; tone: "ok" | "warn" | "danger" | "neutral" }> = {
  clear: { label: "Clear", tone: "ok" },
  warned: { label: "Warned", tone: "warn" },
  struck: { label: "Struck", tone: "danger" },
  under_review: { label: "Under review", tone: "danger" },
  blacklisted: { label: "Blacklisted", tone: "danger" },
};

export function ProfilePage({
  viewer,
  account,
  rank,
  clanName,
  followed,
  onFollow,
  onShop,
  self,
  subscribed,
  equippedName,
  equippedMotion,
}: {
  viewer: Identity;
  account: AstroAccount;
  rank: number;
  clanName: string;
  followed: boolean;
  onFollow: () => void;
  onShop: () => void;
  self: boolean;
  subscribed: boolean;
  equippedName: string | null;
  equippedMotion?: string | null;
}) {
  const [game, setGame] = useState<"rust" | "dayz">("rust");
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const series = useMemo(() => formSeries(viewer), [viewer]);
  const meta = metaFor(viewer.id, viewer.score);
  const status = STATUS[viewer.status];
  const shown = scoreFor(viewer.id, viewer.score, game);
  const badges = useResolvedBadges([viewer])[viewer.id];
  const recent = LISTINGS.find((listing) => listing.region === meta.region) ?? LISTINGS[0];
  const hours = Math.max(12, Math.round(viewer.score / 40));
  const rating = Math.max(3.2, 4.9 - viewer.strikes * 0.4).toFixed(1);

  return (
    <div className="grid gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-center gap-3">
          {equippedMotion ? <MotionPreview compact motion={equippedMotion} title={equippedName ?? viewer.name} /> : null}
          <div>
          <p className="font-mono text-xs text-cyan">{viewer.id}</p>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-medium tracking-tight">{viewer.name}</h1>
            <VerifiedMark verified={account.verified} />
          </div>
          <p className="mt-1 text-sm text-muted">
            @{viewer.handle} · {meta.region} · {clanName}
          </p>
          <p className="mt-1 text-sm text-muted">
            {account.business && account.businessName ? `${account.businessName} · business` : "Player account"} · Astro fee {quote(100, account.verified).label}
          </p>
          <p className="mt-1 text-sm text-muted">
            {subscribed ? `Astro active · ${ASTRO_PRICE} · 150 coins each renewal · animated group banner` : `No Astro pass · ${ASTRO_PRICE} · includes 150 coins a month and one animated group banner`}
            {equippedName ? ` · wearing ${equippedName}` : ""}
          </p>
          </div>
        </div>
        {self ? (
          <button type="button" onClick={onShop} className="min-h-11 rounded-lg border border-border px-3 text-sm">
            Official shop
          </button>
        ) : (
          <button type="button" onClick={onFollow} className="min-h-11 rounded-lg border border-border px-3 text-sm">
            {followed ? "Following" : "Follow"}
          </button>
        )}
      </div>

      <section className="rounded-3xl border border-border bg-bg-elevated p-4">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Trust</h2>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
          <div>
            <dt className="text-muted">Standing</dt>
            <dd className="mt-1">{account.verified ? "Verified" : "Unverified"} · {status.label}</dd>
          </div>
          <div>
            <dt className="text-muted">Strikes</dt>
            <dd className="mt-1 font-mono text-xs">{viewer.strikes}</dd>
          </div>
          <div>
            <dt className="text-muted">Hours</dt>
            <dd className="mt-1 font-mono text-xs">{hours}</dd>
          </div>
          <div>
            <dt className="text-muted">Group</dt>
            <dd className="mt-1">{clanName}</dd>
          </div>
          <div>
            <dt className="text-muted">Recent server</dt>
            <dd className="mt-1">{recent?.name}</dd>
          </div>
          <div>
            <dt className="text-muted">Seller rating</dt>
            <dd className="mt-1 font-mono text-xs text-ok">{rating}</dd>
          </div>
        </dl>
      </section>

      <div className="grid gap-4 lg:grid-cols-5">
        <section className="rounded-3xl border border-border bg-bg-elevated p-4 lg:col-span-2">
          <div className="flex items-baseline justify-between gap-3">
            <p className="font-mono text-xs text-faint">Rank #{rank}</p>
            <Chip tone={status.tone}>{status.label}</Chip>
          </div>
          <p className="mt-2 text-4xl font-medium tabular-nums tracking-tight">
            <CountUp key={`${viewer.id}-${game}`} value={shown} from={game === "rust" ? shown - viewer.scoreDelta : shown} />
          </p>
          <p className={`mt-1 font-mono text-xs ${viewer.scoreDelta >= 0 ? "text-ok" : "text-danger"}`}>
            {viewer.scoreDelta >= 0 ? "↑" : "↓"} {Math.abs(viewer.scoreDelta)} this session · {viewer.form}
          </p>
          <div className="mt-4 flex gap-2">
            {(
              [
                ["rust", "Rust Console"],
                ["dayz", "DayZ"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                aria-pressed={game === id}
                onClick={() => setGame(id)}
                className={`min-h-11 rounded-lg border px-3 text-sm ${game === id ? "border-cyan text-cyan" : "border-border text-muted"}`}
              >
                {label}
              </button>
            ))}
          </div>
          <p className="mt-3 text-sm text-muted">{game === "rust" ? "Rust Console score is the identity’s main KOBA number." : "DayZ score is tracked separately. It does not replace the global rank."}</p>
          <div className="mt-4 h-28">
            {mounted ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={series} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
                  <XAxis dataKey="label" tick={{ fill: "var(--color-faint)", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis hide domain={["dataMin - 8", "dataMax + 8"]} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--color-bg-elevated)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 8,
                      color: "var(--color-fg)",
                      fontSize: 12,
                    }}
                  />
                  <Area type="monotone" dataKey="form" name="Form" stroke="var(--color-ok)" fill="var(--color-ok)" fillOpacity={0.16} strokeWidth={2} isAnimationActive={false} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full rounded-lg bg-bg-subtle" />
            )}
          </div>
        </section>

        <section className="rounded-3xl border border-border bg-bg-elevated p-4 lg:col-span-3">
          <h2 className="text-sm font-medium">Badges</h2>
          <p className="mt-1 text-sm text-muted">Flair sits on the name. Achievements climb as the record grows. Tap a pin to read it.</p>
          <div className="mt-3">
            {badges ? <BadgeBoard result={badges} /> : null}
          </div>
        </section>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl border border-border bg-bg-elevated p-4">
          <h2 className="text-sm font-medium">Linked</h2>
          <dl className="mt-3 grid gap-2 text-sm">
            <Row label="Steam" value={viewer.steamId ?? "Not linked"} />
            <Row label="Discord" value={viewer.discordId ?? "Not linked"} />
            <Row label="Coins" value={formatCoins(viewer.coins)} />
            <Row label="Strikes" value={`${viewer.strikes}/3`} />
          </dl>
        </section>
        <section className="rounded-3xl border border-border bg-bg-elevated p-4">
          <h2 className="text-sm font-medium">Homes</h2>
          {viewer.homes.length === 0 ? <p className="mt-3 text-sm text-muted">No homes set. The cap is 3.</p> : null}
          <ul className="mt-3 grid gap-3">
            {viewer.homes.map((home) => (
              <li key={home.name}>
                <p className="text-sm">{home.name}</p>
                <p className="font-mono text-xs text-muted">
                  {home.x.toFixed(1)}, {home.y.toFixed(1)}, {home.z.toFixed(1)}
                </p>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <dt className="text-muted">{label}</dt>
      <dd className="font-mono text-xs">{value}</dd>
    </div>
  );
}
