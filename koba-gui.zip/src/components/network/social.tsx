import { Button, Chip } from "@/components/ui";
import { clanTier, type Identity } from "@/platform/engine";

export function SocialPage({
  viewer,
  identities,
  clans,
  follows,
  onFollow,
  onOpen,
}: {
  viewer: Identity;
  identities: Identity[];
  clans: { id: string; name: string; memberIds: string[]; atWarWith?: string }[];
  follows: string[];
  onFollow: (id: string) => void;
  onOpen: (id: string) => void;
}) {
  const mine = clans.find((clan) => clan.id === viewer.clanId);
  const followed = identities.filter((identity) => follows.includes(identity.id));
  const suggestions = identities.filter((identity) => identity.id !== viewer.id && !follows.includes(identity.id));

  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-medium tracking-tight">Social</h1>
        <p className="mt-1 max-w-xl text-sm text-muted">People you follow, and the clan roster on this identity.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl border border-border bg-bg-elevated p-4">
          <h2 className="text-sm font-medium">Following</h2>
          {followed.length === 0 ? <p className="mt-3 text-sm text-muted">You are not following anyone yet.</p> : null}
          <ul className="mt-2 grid">
            {followed.map((identity) => (
              <li key={identity.id} className="flex items-center justify-between gap-3 border-b border-border py-2 last:border-b-0">
                <button type="button" onClick={() => onOpen(identity.id)} className="min-h-11 text-left text-sm">
                  {identity.name}
                </button>
                <Button onClick={() => onFollow(identity.id)}>Unfollow</Button>
              </li>
            ))}
          </ul>
          <h3 className="mt-5 text-sm font-medium">Suggested</h3>
          <ul className="mt-2 grid">
            {suggestions.map((identity) => (
              <li key={identity.id} className="flex items-center justify-between gap-3 border-b border-border py-2 last:border-b-0">
                <button type="button" onClick={() => onOpen(identity.id)} className="min-h-11 text-left">
                  <span className="block text-sm">{identity.name}</span>
                  <span className="font-mono text-xs text-faint">{identity.handle}</span>
                </button>
                <Button variant="primary" onClick={() => onFollow(identity.id)}>
                  Follow
                </Button>
              </li>
            ))}
          </ul>
        </section>
        <section className="rounded-3xl border border-border bg-bg-elevated p-4">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-medium">{mine ? mine.name : "No clan"}</h2>
            {mine ? <Chip tone="cyan">{clanTier(mine.memberIds.length)}</Chip> : null}
          </div>
          {!mine ? <p className="mt-3 text-sm text-muted">Join a roster from a clan page once recruitment is open. This identity is unaffiliated.</p> : null}
          <ul className="mt-2 grid">
            {mine?.memberIds.map((id) => {
              const member = identities.find((identity) => identity.id === id);
              if (!member) return null;
              return (
                <li key={id}>
                  <button type="button" onClick={() => onOpen(id)} className="flex min-h-11 w-full items-baseline justify-between text-left">
                    <span className="text-sm">{member.name}</span>
                    <span className="font-mono text-xs tabular-nums text-muted">{member.score}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </div>
  );
}
