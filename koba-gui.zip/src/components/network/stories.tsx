import { useState } from "react";
import { Plus } from "lucide-react";
import { PlayerFace } from "@/components/network/shared";
import type { Identity } from "@/platform/engine";
import { useCommunity } from "@/site/community";

export function StoriesPage({ viewer, identities }: { viewer: Identity; identities: Identity[] }) {
  const stories = useCommunity((s) => s.stories);
  const addStory = useCommunity((s) => s.addStory);
  const [open, setOpen] = useState<string | null>(stories[0]?.id ?? null);
  const [text, setText] = useState("");
  const nameFor = (id: string) => identities.find((identity) => identity.id === id)?.name ?? id;
  const authors = [...new Set(stories.map((story) => story.authorId))];
  const current = stories.find((story) => story.id === open) ?? stories[0];

  return (
    <div className="grid gap-4">
      <div className="flex gap-3 overflow-x-auto pb-1" data-noswipe>
        {authors.map((authorId) => {
          const latest = stories.find((story) => story.authorId === authorId);
          return (
            <button key={authorId} type="button" onClick={() => latest && setOpen(latest.id)} className="grid w-16 shrink-0 justify-items-center gap-1">
              <PlayerFace name={nameFor(authorId)} id={authorId} />
              <span className="max-w-16 truncate text-[10px] text-muted">{nameFor(authorId).split(" ")[0]}</span>
            </button>
          );
        })}
      </div>
      {current ? (
        <article className="rounded-3xl bg-bg-elevated p-5">
          <p className="text-xs text-muted">{nameFor(current.authorId)}</p>
          <p className="mt-3 text-xl font-medium">{current.text}</p>
          {current.sticker ? <p className="mt-4 text-sm text-ok">{current.sticker}</p> : null}
        </article>
      ) : (
        <p className="text-sm text-muted">No stories yet.</p>
      )}
      <form
        className="flex flex-wrap gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          addStory(viewer.id, text);
          setText("");
        }}
      >
        <input value={text} onChange={(event) => setText(event.target.value)} placeholder="Add to your story" aria-label="Add to your story" className="h-11 min-w-0 flex-1 rounded-full bg-bg-subtle px-4 text-sm outline-none" />
        <button type="submit" aria-label="Post story" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-fg text-bg"><Plus size={18} /></button>
      </form>
    </div>
  );
}
