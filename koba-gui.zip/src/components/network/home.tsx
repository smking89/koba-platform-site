import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import { Button, Chip } from "@/components/ui";
import { CountUp, PlayerFace } from "@/components/network/shared";
import { BadgeRow } from "@/components/network/badges";
import { useResolvedBadges } from "@/components/network/badge-state";
import { MotionPreview, VerifiedMark } from "@/components/network/shop";
import { cn } from "@/lib/cn";
import { clanTier, formSeries, type Clan, type Identity } from "@/platform/engine";
import { formatCoins, accountFor, quote, specFor, type AstroAccount, type ShopProduct } from "@/site/astro";
import { BOUNTIES, LISTINGS, metaFor } from "@/site/catalog";
import { useCommunity } from "@/site/community";
import type { HomeTab, SitePage } from "@/site/ui";

export function HomePage({
  viewer,
  identities,
  clans,
  rank,
  account,
  products,
  pending,
  pulse,
  feed,
  onOpen,
  onOpenPlayer,
}: {
  viewer: Identity;
  identities: Identity[];
  clans: Clan[];
  rank: number;
  account: AstroAccount;
  products: ShopProduct[];
  pending: number;
  pulse: number;
  feed: { id: string; title: string; detail: string; tone: string }[];
  onOpen: (target: SitePage | HomeTab) => void;
  onOpenPlayer: (id: string) => void;
}) {
  const series = useMemo(() => formSeries(viewer), [viewer]);
  const meta = metaFor(viewer.id, viewer.score);
  const up = viewer.scoreDelta >= 0;
  const rivals = viewer.rivals
    .map((id) => identities.find((identity) => identity.id === id))
    .filter((identity): identity is Identity => Boolean(identity))
    .slice(0, 3);
  const board = identities.slice().sort((a, b) => b.score - a.score).slice(0, 5);
  const fee = quote(100, account.verified).label;
  const rust = LISTINGS.filter((listing) => listing.gameId === "rust");
  const dayz = LISTINGS.filter((listing) => listing.gameId === "dayz");
  const latest = series[series.length - 1]?.form ?? 0;
  const badgeMap = useResolvedBadges(identities);

  return (
    <div className="grid min-w-0 gap-4">
      <MarketBoard identities={identities} products={products} onOpen={onOpen} />
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-12">
      <section className="dash-card relative min-w-0 p-4 xl:col-span-3">
        <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl">
          <img src="/brand/koba-mark.gif" alt="" width={264} height={264} className="absolute -right-4 -bottom-6 h-36 w-28 object-contain opacity-30" />
        </div>
        <p className="font-mono text-xs tracking-widest text-faint uppercase">You</p>
        <div className="mt-3 flex items-center gap-3">
          <PlayerFace name={viewer.name} id={viewer.id} size="lg" />
          <div className="min-w-0">
            <p className="flex items-center gap-1 truncate text-base font-medium">
              {viewer.name}
              <BadgeRow pins={(badgeMap[viewer.id]?.earned ?? []).filter((pin) => pin.id === "verified")} size={16} />
            </p>
            <p className="font-mono text-xs text-faint">@{viewer.handle}</p>
            <div className="mt-2">
              <BadgeRow muted pins={(badgeMap[viewer.id]?.earned ?? []).filter((pin) => pin.id !== "verified")} size={36} />
            </div>
          </div>
        </div>
        <ScoreReadout key={viewer.id} score={viewer.score} delta={viewer.scoreDelta} rank={rank} up={up} />
        <CoinPocket
          region={meta.region}
          coins={viewer.coins}
          identityId={viewer.id}
          feed={feed}
          products={products}
          onShop={() => onOpen("shop")}
        />
        <ShopButton onClick={() => onOpen("shop")}>{account.business ? "Open shop" : "Official shop"}</ShopButton>
      </section>

      <Dash title="Form" fold className="max-xl:order-first xl:col-span-5" action={<span className="rounded-full bg-cyan/15 px-3 py-1 font-mono text-xs text-cyan">{latest} · {viewer.form}</span>}>
        <Sparkline series={series} label="Form chart" />
      </Dash>

      <Dash title="Top rivals" className="xl:col-span-4" action={<span className="font-mono text-xs text-faint">{pending ? `${pending} open` : "Clear"}</span>}>
        {rivals.length === 0 ? <p className="text-sm text-muted">No rivals on this identity.</p> : null}
        <ul className="grid gap-1">
          {rivals.map((rival) => (
            <li key={rival.id}>
              <button type="button" onClick={() => onOpenPlayer(rival.id)} className="flex min-h-14 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle">
                <PlayerFace name={rival.name} id={rival.id} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1">
                    <span className="truncate text-sm">{rival.name}</span>
                    <BadgeRow pins={(badgeMap[rival.id]?.earned ?? []).filter((pin) => pin.id === "verified")} size={16} />
                  </span>
                  <span className="font-mono text-xs text-faint">@{rival.handle}</span>
                </span>
                <span className="font-mono text-xs text-cyan">{rival.score.toLocaleString("en-US")}</span>
              </button>
            </li>
          ))}
        </ul>
      </Dash>

      <Dash title="Games" className="xl:col-span-3" action={<TextLink onClick={() => onOpen("discover")}>See all</TextLink>}>
        <GameBlock label="Rust Console" rows={rust.slice(0, 3)} onOpen={() => onOpen("discover")} />
        <GameBlock label="DayZ" rows={dayz.slice(0, 2)} onOpen={() => onOpen("discover")} />
      </Dash>

      <Dash title="Activity" className="xl:col-span-5" action={pulse > 0 ? <span className="rounded-full bg-ok/15 px-3 py-1 font-mono text-xs text-ok">Live</span> : <TextLink onClick={() => onOpen("feed")}>Feed</TextLink>}>
        <ul>
          {feed.slice(0, 5).map((row) => (
            <li key={row.id} className="flex items-start gap-3 border-b border-border/70 py-3 last:border-b-0">
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${row.tone === "danger" ? "bg-danger" : row.tone === "gold" ? "bg-gold" : row.tone === "ok" ? "bg-ok" : "bg-cyan"}`} />
              <div className="min-w-0 flex-1">
                <p className="text-sm">{row.title}</p>
                <p className="mt-1 text-sm text-muted">{row.detail}</p>
              </div>
              <Chip tone={row.tone === "gold" ? "warn" : row.tone === "cyan" ? "cyan" : row.tone === "ok" ? "ok" : row.tone === "danger" ? "danger" : "neutral"}>
                {row.tone === "gold" ? "coins" : row.tone === "ok" ? "form" : row.tone === "cyan" ? "live" : row.tone === "danger" ? "alert" : "note"}
              </Chip>
            </li>
          ))}
        </ul>
      </Dash>

      <Dash title="Astro" className="xl:col-span-4">
        <VerifiedMark verified={account.verified} />
        <p className="mt-4 text-3xl font-medium tabular-nums text-ok">{fee}</p>
        <p className="mt-1 text-sm text-muted">Seller fee on the Official shop. Astro also drops 150 coins each month and an animated banner for one group.</p>
        <p className="mt-3 text-sm">{account.business ? account.businessName : "Not a business yet"}</p>
        <Button variant="primary" className="mt-4 w-full" onClick={() => onOpen("shop")}>
          {account.business ? "List a product" : "Open a business"}
        </Button>
      </Dash>

      <Dash title="Communities" className="xl:col-span-3" action={<TextLink onClick={() => onOpen("social")}>Social</TextLink>}>
        <ul className="grid gap-1">
          {clans.map((clan) => (
            <li key={clan.id}>
              <button type="button" onClick={() => onOpen("groups")} className="flex min-h-14 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle">
                <span className="grid h-11 w-11 shrink-0 place-items-center text-base font-medium">{clan.name.slice(0, 1)}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm">{clan.name}</span>
                  <span className="font-mono text-xs text-faint">{clan.memberIds.length} players</span>
                </span>
                <span className="font-mono text-xs text-muted">{clanTier(clan.memberIds.length)}</span>
              </button>
            </li>
          ))}
        </ul>
      </Dash>

      <Dash title="Leaderboard" className="xl:col-span-5" action={<TextLink onClick={() => onOpen("rankings")}>Ranks</TextLink>}>
        <div className="grid grid-cols-[1.4rem_minmax(0,1fr)_auto] gap-x-3 px-1 font-mono text-xs text-faint">
          <span>#</span>
          <span>Player</span>
          <span>Score</span>
        </div>
        <ul className="mt-1">
          {board.map((identity, index) => (
            <li key={identity.id}>
              <button type="button" onClick={() => onOpenPlayer(identity.id)} className="grid min-h-12 w-full grid-cols-[1.4rem_minmax(0,1fr)_auto] items-center gap-x-3 rounded-2xl px-1 text-left hover:bg-bg-subtle">
                <span className="font-mono text-xs text-faint">{index + 1}</span>
                <span className="flex min-w-0 items-center gap-2">
                  <PlayerFace name={identity.name} id={identity.id} size="sm" />
                  <span className={`flex min-w-0 items-center gap-1 truncate text-sm ${identity.id === viewer.id ? "text-ok" : ""}`}>
                    <span className="truncate">{identity.name}</span>
                    <BadgeRow pins={(badgeMap[identity.id]?.earned ?? []).filter((pin) => pin.id === "verified")} size={14} />
                  </span>
                </span>
                <span className="font-mono text-xs text-muted">{identity.score.toLocaleString("en-US")}</span>
              </button>
            </li>
          ))}
        </ul>
      </Dash>

      <Dash title="Official shop" className="md:col-span-2 xl:col-span-4" action={<TextLink onClick={() => onOpen("shop")}>Shop</TextLink>}>
        <div className="grid gap-2">
          {products.slice(0, 3).map((product) => (
            <button key={product.id} type="button" onClick={() => onOpen("shop")} className="card-lift flex min-h-16 items-center gap-3 rounded-2xl bg-bg-subtle px-3 py-2 text-left">
              <span className="grid h-11 w-11 shrink-0 place-items-center text-sm font-medium">{specFor(product.kind).name.slice(0, 1)}</span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm">{product.title}</span>
                <span className="block truncate font-mono text-xs text-faint">{specFor(product.kind).name}</span>
              </span>
              <span className="font-mono text-xs text-ok">{formatCoins(product.price)}</span>
            </button>
          ))}
        </div>
      </Dash>

      <Dash title="Session" className="hidden xl:col-span-12 xl:block" action={<span className="rounded-full bg-violet/20 px-3 py-1 font-mono text-xs text-fg">{viewer.form}</span>}>
        <Bars series={series} label="Session chart" />
      </Dash>
    </div>
    </div>
  );
}

type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary" | "relic";

interface Lot {
  id: string;
  title: string;
  sellerId: string;
  price: number;
  rarity: Rarity;
  kind: string;
  game: string;
  motion?: string;
  auction: string | null;
  productId: string | null;
}

const RARITIES: Rarity[] = ["common", "uncommon", "rare", "epic", "legendary", "relic"];

function rarityForPrice(price: number): Rarity {
  if (price >= 160) return "relic";
  if (price >= 120) return "legendary";
  if (price >= 70) return "epic";
  if (price >= 35) return "rare";
  if (price >= 20) return "uncommon";
  return "common";
}

function marketLots(products: ShopProduct[]): Lot[] {
  return products.map((product) => ({
    id: product.id,
    title: product.title,
    sellerId: product.sellerId,
    price: product.price,
    rarity: rarityForPrice(product.price),
    kind: product.kind,
    game: product.game,
    motion: product.motion,
    auction: null,
    productId: product.id,
  }));
}

function MarketBoard({
  identities,
  products,
  onOpen,
}: {
  identities: Identity[];
  products: ShopProduct[];
  onOpen: (target: SitePage | HomeTab) => void;
}) {
  const lots = useMemo(() => marketLots(products), [products]);
  const [rarity, setRarity] = useState<Rarity | "all">("all");
  const [shown, setShown] = useState(6);
  const [focus, setFocus] = useState<string | null>(null);
  const [held, setHeld] = useState<string | null>(null);
  const [bids, setBids] = useState<Record<string, number>>({});
  const [watch, setWatch] = useState<string[]>([]);
  const freshFrom = useRef(0);
  const sentinel = useRef<HTMLDivElement>(null);
  const filtered = rarity === "all" ? lots : lots.filter((lot) => lot.rarity === rarity);
  const visible = filtered.slice(0, shown);
  const featured = lots.filter((lot) => lot.rarity === "legendary" || lot.rarity === "relic" || lot.rarity === "epic").slice(0, 6);
  const ticks = lots.filter((lot) => lot.auction || lot.productId).slice(0, 8);
  const online = LISTINGS.reduce((sum, listing) => sum + listing.players, 0);

  const nameFor = (id: string) => identities.find((identity) => identity.id === id)?.name ?? "KOBA";

  useEffect(() => {
    if (!focus) return;
    document.getElementById(`lot-${focus}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [focus, shown, rarity]);

  useEffect(() => {
    const node = sentinel.current;
    if (!node) return;
    const observer = new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting)) return;
      setShown((count) => {
        if (count >= filtered.length) return count;
        freshFrom.current = count;
        return Math.min(filtered.length, count + 6);
      });
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, [filtered.length, rarity]);

  const pick = (next: Rarity | "all") => {
    freshFrom.current = 0;
    setRarity(next);
    setShown(6);
    setFocus(null);
  };

  const jump = (lot: Lot) => {
    freshFrom.current = 0;
    setRarity("all");
    setShown(lots.length);
    setFocus(lot.id);
  };

  const buy = (lot: Lot) => onOpen(lot.productId ? "shop" : "discover");

  return (
    <section className="grid min-w-0 gap-3">
      <div className="dash-card flex min-w-0 items-center gap-3 px-3" data-noswipe>
        <span className="flex shrink-0 items-center gap-2 font-mono text-xs tracking-widest text-ok uppercase">
          <span className="h-2 w-2 rounded-full bg-ok" />
          Live
        </span>
        <div className="ticker min-w-0 flex-1 py-1">
          <div className="ticker-track">
            {[0, 1].map((copy) => (
              <div key={copy} className="flex">
                {ticks.map((lot) => (
                  <button key={`${copy}-${lot.id}`} type="button" onClick={() => jump(lot)} className="min-h-11 shrink-0 px-4 text-left text-sm text-fg">
                    {lot.auction ? `Auction for ${lot.title} ending in ${lot.auction}` : `${nameFor(lot.sellerId)} listed ${lot.title}`}
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex min-w-0 gap-2 overflow-x-auto pb-1" data-noswipe role="toolbar" aria-label="Rarity">
        <RarityPill label="All" on={rarity === "all"} onClick={() => pick("all")} />
        {RARITIES.map((item) => (
          <RarityPill key={item} label={item} on={rarity === item} onClick={() => pick(item)} />
        ))}
      </div>

      <div className="min-w-0">
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Featured</h2>
          <span className="font-mono text-xs text-ok">Trending up</span>
        </div>
        <div className="flex min-w-0 snap-x snap-mandatory gap-3 overflow-x-auto pb-1" data-noswipe>
          {featured.map((lot) => (
            <LotCard
              key={lot.id}
              lot={lot}
              seller={nameFor(lot.sellerId)}
              verified={accountFor(lot.sellerId, {}).verified}
              held={held === lot.id}
              bid={bids[lot.id] ?? 0}
              watched={watch.includes(lot.id)}
              featured
              onHold={setHeld}
              onBuy={() => buy(lot)}
              onBid={() => setBids((current) => ({ ...current, [lot.id]: (current[lot.id] ?? lot.price) + 5 }))}
              onWatch={() => setWatch((current) => (current.includes(lot.id) ? current.filter((id) => id !== lot.id) : [...current, lot.id]))}
              onOpen={() => jump(lot)}
            />
          ))}
        </div>
      </div>

      <div className="dash-card grid grid-cols-3 gap-3 p-4">
        <div>
          <p className="font-mono text-xs tracking-widest text-muted uppercase">Servers</p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{LISTINGS.length}</p>
        </div>
        <div>
          <p className="flex items-center gap-2 font-mono text-xs tracking-widest text-ok uppercase">
            <span className="h-2 w-2 rounded-full bg-ok" />
            Online
          </p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{online}</p>
        </div>
        <div>
          <p className="font-mono text-xs tracking-widest text-muted uppercase">Events</p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{BOUNTIES.length}</p>
        </div>
      </div>

      <div className="min-w-0">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Board</h2>
        {filtered.length === 0 ? <p className="mt-3 text-sm text-muted">Nothing listed in this tier.</p> : null}
        <ul className="mt-2 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((lot, index) => (
            <li key={lot.id} className={index >= freshFrom.current ? "lot-in" : undefined} style={{ animationDelay: `${(index % 6) * 40}ms` }}>
              <LotCard
                lot={lot}
                seller={nameFor(lot.sellerId)}
                verified={accountFor(lot.sellerId, {}).verified}
                held={held === lot.id}
                focused={focus === lot.id}
                bid={bids[lot.id] ?? 0}
                watched={watch.includes(lot.id)}
                onHold={setHeld}
                onBuy={() => buy(lot)}
                onBid={() => setBids((current) => ({ ...current, [lot.id]: (current[lot.id] ?? lot.price) + 5 }))}
              onWatch={() => setWatch((current) => (current.includes(lot.id) ? current.filter((id) => id !== lot.id) : [...current, lot.id]))}
                onOpen={() => jump(lot)}
              />
            </li>
          ))}
        </ul>
        <div ref={sentinel} className="h-6" />
        <p className="text-center font-mono text-xs text-faint">{shown < filtered.length ? "More on the board" : "That's the board."}</p>
      </div>
    </section>
  );
}

function RarityPill({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick} className={`min-h-11 shrink-0 rounded-full px-4 text-sm capitalize ${on ? "bg-ok text-bg" : "bg-bg-subtle text-muted"}`}>
      {label}
    </button>
  );
}

function LotCard({
  lot,
  seller,
  verified,
  held,
  focused = false,
  bid,
  watched,
  featured = false,
  onHold,
  onBuy,
  onBid,
  onWatch,
  onOpen,
}: {
  lot: Lot;
  seller: string;
  verified: boolean;
  held: boolean;
  focused?: boolean;
  bid: number;
  watched: boolean;
  featured?: boolean;
  onHold: (id: string | null) => void;
  onBuy: () => void;
  onBid: () => void;
  onWatch: () => void;
  onOpen: () => void;
}) {
  const premium = lot.rarity === "legendary" || lot.rarity === "relic";
  const high = bid || lot.price;
  return (
    <article
      id={featured ? undefined : `lot-${lot.id}`}
      data-rarity={lot.rarity}
      className={`lot-card dash-card p-3 ${featured ? "w-64 shrink-0 snap-start" : ""} ${held ? "is-held" : ""} ${premium ? "is-shimmer" : ""} ${focused ? "is-focus" : ""}`}
      onPointerDown={() => onHold(lot.id)}
      onPointerUp={() => onHold(null)}
      onPointerCancel={() => onHold(null)}
      onPointerLeave={() => onHold(null)}
    >
      <button type="button" onClick={onOpen} className="grid h-28 w-full place-items-center overflow-hidden rounded-3xl bg-bg text-center">
        {lot.motion ? <MotionPreview motion={lot.motion} title={lot.title} /> : <span className="text-lg font-medium">{lot.title}</span>}
      </button>
      <div className="mt-3 flex items-center justify-between gap-2">
        <p className="min-w-0 truncate text-sm">{seller}</p>
        {verified ? <VerifiedMark verified /> : <span className="shrink-0 font-mono text-xs text-muted">Unverified</span>}
      </div>
      <p className="mt-1 font-mono text-xs text-muted capitalize">
        {lot.rarity} · {lot.auction ? <AuctionClock label={lot.auction} high={high} /> : `${formatCoins(lot.price)} coins`}
      </p>
      <Button variant="primary" className="mt-3 w-full" onClick={lot.auction ? onBid : onBuy}>
        {lot.auction ? `Bid ${formatCoins(high + 5)}` : "Buy now"}
      </Button>
      {lot.auction ? (
        <button type="button" onClick={onWatch} className="mt-2 min-h-11 w-full text-sm text-muted">
          {watched ? "Watching" : "Watch"}
        </button>
      ) : null}
    </article>
  );
}

function AuctionClock({ label, high }: { label: string; high: number }) {
  const minutes = Number.parseInt(label, 10);
  const [left, setLeft] = useState(Number.isFinite(minutes) ? minutes * 60 : 0);
  useEffect(() => {
    const timer = window.setInterval(() => setLeft((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, []);
  const shown = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`;
  return (
    <span>
      high {formatCoins(high)} · {left === 0 ? "closed" : shown}
    </span>
  );
}

function Dash({
  title,
  action,
  children,
  className,
  fold = false,
}: {
  title: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  fold?: boolean;
}) {
  const [open, setOpen] = useState(false);
  if (!fold) {
    return (
      <section className={cn("dash-card min-w-0 p-4", className)}>
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-mono text-xs tracking-widest text-faint uppercase">{title}</h2>
          {action}
        </div>
        <div className="mt-3 min-w-0">{children}</div>
      </section>
    );
  }
  return (
    <section className={cn("dash-card min-w-0 p-4", className)}>
      <button type="button" aria-expanded={open} onClick={() => setOpen((value) => !value)} className="flex min-h-11 w-full items-center justify-between gap-3 text-left">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">{title}</h2>
        <span className="flex items-center gap-2">
          {action}
          <ChevronDown size={16} aria-hidden className={`text-muted transition-transform ${open ? "rotate-180" : ""}`} />
        </span>
      </button>
      <div className={`fold ${open ? "is-open" : ""}`}>
        <div>
          <div className="min-w-0 pt-3">{children}</div>
        </div>
      </div>
    </section>
  );
}

function ScoreReadout({ score, delta, rank, up }: { score: number; delta: number; rank: number; up: boolean }) {
  const [pop, setPop] = useState(false);
  const [floater, setFloater] = useState<number | null>(null);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || delta === 0) return;
    setPop(true);
    setFloater(delta);
    const timer = window.setTimeout(() => {
      setPop(false);
      setFloater(null);
    }, 860);
    return () => window.clearTimeout(timer);
  }, [delta, score]);

  return (
    <div className="relative mt-3">
      <p className="text-3xl font-medium tabular-nums tracking-tight">
        <CountUp value={score} from={score - delta} />
      </p>
      <p className={`mt-1 font-mono text-xs ${up ? "text-ok" : "text-danger"} ${pop ? "session-pop" : ""}`}>
        #{rank} · {up ? "+" : ""}
        {delta} this session
      </p>
      {floater != null ? <span className={`float-gain ${floater >= 0 ? "text-ok" : "text-danger"}`}>{floater > 0 ? "+" : ""}{floater}</span> : null}
    </div>
  );
}

const EMPTY_OWNED: string[] = [];

function CoinPocket({
  region,
  coins,
  identityId,
  feed,
  products,
  onShop,
}: {
  region: string;
  coins: number;
  identityId: string;
  feed: { id: string; title: string; detail: string; tone: string }[];
  products: ShopProduct[];
  onShop: () => void;
}) {
  const [open, setOpen] = useState(false);
  const ownedIds = useCommunity((state) => state.owned[identityId]);
  const owned = ownedIds ?? EMPTY_OWNED;
  const credits = feed.filter((row) => row.tone === "gold" || /coin/i.test(`${row.title} ${row.detail}`)).slice(0, 3);
  const history = products.filter((product) => owned.includes(product.id));

  return (
    <div className="relative mt-2">
      <button type="button" aria-expanded={open} onClick={() => setOpen((value) => !value)} className="min-h-11 text-left text-xs text-muted">
        {region} · {formatCoins(coins)} coins
      </button>
      {open ? (
        <div className="mt-1 rounded-2xl bg-bg-subtle p-3 text-sm">
          <p className="font-mono text-xs tracking-widest text-faint uppercase">Balance</p>
          <p className="mt-2 flex items-baseline justify-between gap-3">
            <span>KOBA coins</span>
            <span className="font-mono text-ok">{formatCoins(coins)}</span>
          </p>
          <p className="mt-3 font-mono text-xs tracking-widest text-faint uppercase">Recent credits</p>
          {credits.length === 0 ? <p className="mt-1 text-muted">No coin credits yet.</p> : null}
          <ul className="mt-1 grid gap-1">
            {credits.map((row) => (
              <li key={row.id} className="text-muted">
                {row.title}
              </li>
            ))}
          </ul>
          <p className="mt-3 font-mono text-xs tracking-widest text-faint uppercase">Purchases</p>
          {history.length === 0 ? <p className="mt-1 text-muted">Nothing bought on this identity.</p> : null}
          <ul className="mt-1 grid gap-1">
            {history.map((product) => (
              <li key={product.id} className="flex items-baseline justify-between gap-3">
                <span className="truncate">{product.title}</span>
                <span className="font-mono text-xs text-muted">{formatCoins(product.price)}</span>
              </li>
            ))}
          </ul>
          <button type="button" onClick={onShop} className="mt-2 min-h-11 text-sm text-cyan">
            Purchase history
          </button>
        </div>
      ) : null}
    </div>
  );
}

function ShopButton({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  const [rips, setRips] = useState<{ id: number; x: number; y: number }[]>([]);
  const seq = useRef(0);
  return (
    <Button
      variant="primary"
      className="shop-cta relative mt-3 w-full"
      onClick={onClick}
      onPointerDown={(event) => {
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
        const rect = event.currentTarget.getBoundingClientRect();
        const id = ++seq.current;
        setRips((list) => [...list, { id, x: event.clientX - rect.left, y: event.clientY - rect.top }]);
        window.setTimeout(() => setRips((list) => list.filter((rip) => rip.id !== id)), 520);
      }}
    >
      {children}
      {rips.map((rip) => (
        <span key={rip.id} className="ripple" style={{ left: rip.x, top: rip.y }} />
      ))}
    </Button>
  );
}

function TextLink({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="min-h-11 rounded-full px-2 text-sm text-cyan">
      {children}
    </button>
  );
}

function GameBlock({
  label,
  rows,
  onOpen,
}: {
  label: string;
  rows: typeof LISTINGS;
  onOpen: () => void;
}) {
  return (
    <div className="mb-2 last:mb-0">
      <p className="mb-1 font-mono text-xs text-muted">{label}</p>
      <ul>
        {rows.map((listing) => (
          <li key={listing.id}>
            <button type="button" onClick={onOpen} className="flex min-h-11 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle">
              <span className="grid w-6 shrink-0 place-items-center text-xs text-cyan">{listing.name.slice(0, 1)}</span>
              <span className="min-w-0 flex-1 truncate text-sm">{listing.name}</span>
              <span className="shrink-0 font-mono text-xs text-ok">
                {listing.players}/{listing.cap}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Sparkline({ series, label }: { series: { label: string; form: number }[]; label: string }) {
  const w = 320;
  const h = 144;
  const forms = series.map((point) => point.form);
  const min = Math.min(...forms);
  const max = Math.max(...forms);
  const span = Math.max(1, max - min);
  const pts = series.map((point, index) => {
    const x = Math.round(18 + (index / Math.max(1, series.length - 1)) * (w - 36));
    const y = Math.round(16 + (1 - (point.form - min) / span) * (h - 48));
    return { x, y, label: point.label };
  });
  const line = pts.map((point, index) => `${index === 0 ? "M" : "L"}${point.x} ${point.y}`).join(" ");
  const last = pts[pts.length - 1];
  const first = pts[0];
  const fill = last && first ? `${line} L${last.x} ${h - 24} L${first.x} ${h - 24} Z` : "";
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-36 w-full" role="img" aria-label={label}>
      {fill ? <path d={fill} fill="var(--color-cyan)" opacity="0.22" /> : null}
      {line ? <path d={line} fill="none" stroke="var(--color-cyan)" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" /> : null}
      {pts.map((point) => (
        <text key={point.label} x={point.x} y={h - 6} textAnchor="middle" fill="var(--color-faint)" fontSize="11" fontFamily="IBM Plex Mono, ui-monospace, monospace">
          {point.label}
        </text>
      ))}
    </svg>
  );
}

function Bars({ series, label }: { series: { label: string; form: number }[]; label: string }) {
  const w = 320;
  const h = 128;
  const max = Math.max(...series.map((point) => point.form), 1);
  const gap = 8;
  const width = (w - gap * (series.length + 1)) / Math.max(1, series.length);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-32 w-full" role="img" aria-label={label}>
      {series.map((point, index) => {
        const bar = Math.round((point.form / max) * (h - 32));
        const x = Math.round(gap + index * (width + gap));
        const y = h - 22 - bar;
        return (
          <g key={point.label}>
            <rect x={x} y={y} width={Math.round(width)} height={bar} rx="6" fill="var(--color-violet)" />
            <text x={x + Math.round(width / 2)} y={h - 6} textAnchor="middle" fill="var(--color-faint)" fontSize="11" fontFamily="IBM Plex Mono, ui-monospace, monospace">
              {point.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
