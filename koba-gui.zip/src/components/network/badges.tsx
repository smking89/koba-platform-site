import { useRef, useState } from "react";
import { type BadgeGlyph, type BadgeResult, type Pin } from "@/site/badges";

const GLOW: Record<string, [string, string, string]> = {
  gold: ["#2a1808", "#ffb020", "#ff7a18"],
  violet: ["#140c28", "#7a4de0", "#d2a6ff"],
  magenta: ["#280816", "#e23b6a", "#ff9ab8"],
  cyan: ["#061422", "#1490e0", "#8ae4ff"],
  ok: ["#041810", "#1f9a52", "#8dffb8"],
  muted: ["#12161e", "#7d8798", "#d7dee8"],
};

const FRAME = "M40 3 51 13 67 7 71 23 78 33 70 46 78 59 67 73 51 67 40 77 29 67 13 73 9 59 2 46 10 33 2 23 13 7 29 13Z";
const WELL = "M40 12 49 20 61 16 64 28 70 36 64 48 70 56 61 66 49 62 40 70 31 62 19 66 16 56 10 48 16 36 10 28 19 16 31 20Z";
const VERIFIED_SEAL =
  "M32 2 38.5 7.9 47 6 49.7 14.3 58 17 56.1 25.5 62 32 56.1 38.5 58 47 49.7 49.7 47 58 38.5 56.1 32 62 25.5 56.1 17 58 14.3 49.7 6 47 7.9 38.5 2 32 7.9 25.5 6 17 14.3 14.3 17 6 25.5 7.9Z";

export function BadgeIcon({
  glyph,
  tone = "cyan",
  mark,
  name,
  size = 22,
  labeled = false,
}: {
  glyph: BadgeGlyph;
  tone?: string;
  mark?: string;
  name?: string;
  size?: number;
  labeled?: boolean;
}) {
  if (glyph === "seal" && tone === "cyan" && !mark && !labeled) {
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden className="shrink-0">
        <path d={VERIFIED_SEAL} fill="#0095F6" />
        <path d="M22 33.5 29.2 41.2 43.5 23.5" fill="none" stroke="#fff" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  const [well, hot, edge] = GLOW[tone] ?? GLOW.cyan;
  const height = labeled ? Math.round(size * 1.28) : size;
  const caption = (name ?? glyph).toUpperCase().slice(0, 14);
  return (
    <svg width={size} height={height} viewBox={labeled ? "0 0 80 104" : "0 0 80 80"} aria-hidden className="shrink-0">
      <path d={FRAME} fill="#9aa3b2" />
      <path d={FRAME} fill={edge} opacity="0.55" />
      <path d={WELL} fill="#0b0d12" />
      <path d={WELL} fill={well} />
      <circle cx="40" cy="40" r="16" fill={hot} opacity="0.28" />
      <Scene glyph={glyph} hot={hot} edge={edge} />
      {mark ? (
        <g>
          <circle cx="62" cy="16" r="8" fill="#0b0d12" stroke={edge} strokeWidth="1.4" />
          <text x="62" y="19" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="ui-sans-serif, system-ui, sans-serif" fontWeight="700">
            {mark}
          </text>
        </g>
      ) : null}
      {labeled ? (
        <g>
          <path d="M12 80h56l-3 16H15Z" fill={hot} />
          <path d="M12 80h56l-3 2H15Z" fill="#fff" opacity="0.35" />
          <text x="40" y="92" textAnchor="middle" fill="#fff" fontSize="7.5" fontFamily="ui-sans-serif, system-ui, sans-serif" fontWeight="700">
            {caption}
          </text>
        </g>
      ) : null}
    </svg>
  );
}

function Scene({ glyph, hot, edge }: { glyph: BadgeGlyph; hot: string; edge: string }) {
  if (glyph === "seal") {
    return (
      <g fill="none" stroke={edge} strokeWidth="2.4" strokeLinecap="round">
        <path d="M28 40 36 48 54 30" stroke="#fff" strokeWidth="3.2" />
        <circle cx="40" cy="40" r="14" stroke={hot} />
      </g>
    );
  }
  if (glyph === "spark") {
    return (
      <g>
        <circle cx="40" cy="42" r="8" fill={hot} />
        <path fill={edge} d="M40 24 43 34 40 32 37 34Zm0 28-3-10 3 2 3-2Zm14-14-10 3 2-3-2-3Zm-28 0 10 3-2-3 2-3Z" />
        <path fill="#1a1208" d="M30 40c4-6 8-8 10-8s6 2 10 8c-4 2-7 2-10 2s-6 0-10-2Z" />
      </g>
    );
  }
  if (glyph === "gift") {
    return (
      <g>
        <path fill="#6b3a12" d="M26 36h28v18H26Z" />
        <path fill={hot} d="M24 32h32v6H24Z" />
        <path fill={edge} d="M38 32h4v22h-4Z" />
        <path fill={edge} d="M30 28c0-4 4-6 6-2 2-4 6-2 6 2" />
        <path fill="#39e07a" d="M46 42 50 40 48 46 52 48 46 48 44 52 42 46 36 46 40 42Z" />
      </g>
    );
  }
  if (glyph === "clock") {
    return (
      <g>
        <circle cx="40" cy="40" r="13" fill="#101820" stroke={edge} strokeWidth="2" />
        <path stroke="#fff" strokeWidth="2" strokeLinecap="round" d="M40 32v9l6 4" />
        <path fill={hot} d="M54 28 62 22 58 34 66 36 54 40 58 30Z" />
      </g>
    );
  }
  if (glyph === "maps") {
    return (
      <g>
        <circle cx="40" cy="40" r="13" fill="#102028" stroke={edge} strokeWidth="2" />
        <path fill={hot} d="M40 28 44 40 40 52 36 40Z" />
        <path fill="#fff" d="M28 40 40 36 52 40 40 44Z" opacity="0.8" />
      </g>
    );
  }
  if (glyph === "crown") {
    return (
      <g>
        <path fill={hot} d="M24 46h32v6H24Z" />
        <path fill={edge} d="M22 46 28 30l8 8 4-14 4 14 8-8 6 16Z" />
        <path fill="none" stroke="#f6d36b" strokeWidth="2" d="M26 52c4 4 8 4 14 0s10-4 14 0" />
      </g>
    );
  }
  if (glyph === "diamond") {
    return (
      <g>
        <path fill={edge} d="M28 44h8l2 8h-6Zm16 0h8l-4 8h-6Z" />
        <path fill={hot} d="M24 30h12l-4 10H28Zm20 0h12l-4 10h-4Z" />
        <path stroke={edge} strokeWidth="2" d="M40 22v28M32 28h16" />
      </g>
    );
  }
  if (glyph === "laurel") {
    return (
      <g fill={edge}>
        <path d="M40 26c6 4 8 10 8 16s-2 12-8 16c-6-4-8-10-8-16s2-12 8-16Z" />
        <path fill={hot} d="M22 34c4 1 6 4 6 8-4 1-8 0-10-4 1-2 2-3 4-4Zm36 0c-4 1-6 4-6 8 4 1 8 0 10-4-1-2-2-3-4-4Z" />
      </g>
    );
  }
  if (glyph === "wave") {
    return (
      <g fill={edge}>
        <path d="M28 48c2-10 6-16 12-16 2 6 2 12-2 18 4 0 8-2 10-6 2 8-4 14-12 14-6 0-10-4-8-10Z" />
        <path fill="#fff" d="M34 34c2 2 2 4 0 6 3-1 5 0 6 2-4-1-5 1-5 3 2-2 1-4-1-5Z" />
      </g>
    );
  }
  if (glyph === "peak") {
    return (
      <g>
        <path fill={edge} d="M18 58 34 28l8 14 6-8 16 24Z" />
        <path fill={hot} d="M34 28 40 40 30 40Z" />
        <circle cx="54" cy="26" r="5" fill="#e8eef8" />
      </g>
    );
  }
  if (glyph === "comet") {
    return (
      <g>
        <path fill={hot} d="M22 50c8-2 14-10 16-20 6 8 8 14 6 22-6 2-14 1-22-2Z" />
        <circle cx="44" cy="32" r="6" fill={edge} />
        <circle cx="46" cy="30" r="2" fill="#fff" />
      </g>
    );
  }
  if (glyph === "hex") {
    return (
      <g fill="none" stroke={hot} strokeWidth="3">
        <path d="M28 32h10a6 6 0 0 1 0 12H28a6 6 0 0 1 0-12Z" />
        <path d="M42 36h8a6 6 0 0 1 0 12h-8" />
      </g>
    );
  }
  if (glyph === "chevron") {
    return (
      <g fill={edge}>
        <path d="M24 46c2-8 6-12 8-12s6 4 8 12c-2 2-5 3-8 3s-6-1-8-3Z" />
        <path d="M18 40c2-6 4-8 6-8s4 2 6 8c-2 1-4 2-6 2s-4-1-6-2Zm32 0c-2-6-4-8-6-8s-4 2-6 8c2 1 4 2 6 2s4-1 6-2Z" />
      </g>
    );
  }
  return (
    <g>
      <path fill={hot} d="M26 34h28l-2 16H28Z" />
      <path fill={edge} d="M40 24 46 34H34Z" />
      <path fill="#fff" d="M36 40h8l-1 6h-6Z" />
    </g>
  );
}

export function BadgeRow({ pins, size = 18, enter = false, muted = false }: { pins: Pin[]; size?: number; enter?: boolean; muted?: boolean }) {
  const [openId, setOpenId] = useState<string | null>(null);
  const [heldId, setHeldId] = useState<string | null>(null);
  const timer = useRef<number | null>(null);
  const held = useRef(false);
  if (pins.length === 0) return null;

  const clearTimer = () => {
    if (timer.current != null) window.clearTimeout(timer.current);
    timer.current = null;
  };

  return (
    <span className={`inline-flex flex-wrap items-center gap-1 align-middle ${muted ? "origin-left scale-90 grayscale opacity-55" : ""}`} aria-label="Badges">
      {pins.map((pin, index) => {
        const open = openId === pin.id;
        return (
          <span key={pin.id} className="relative" data-badge>
            <span
              className={`badge-pin inline-flex items-center ${enter ? "badge-enter" : ""} ${heldId === pin.id ? "is-held" : ""}`}
              style={enter ? { animationDelay: `${index * 70}ms` } : undefined}
              role="img"
              aria-label={`${pin.name}. ${pin.detail}`}
              onMouseEnter={() => setOpenId(pin.id)}
              onMouseLeave={() => setOpenId((current) => (current === pin.id ? null : current))}
              onPointerDown={(event) => {
                event.stopPropagation();
                held.current = false;
                clearTimer();
                timer.current = window.setTimeout(() => {
                  held.current = true;
                  setHeldId(pin.id);
                  setOpenId(pin.id);
                }, 380);
              }}
              onPointerUp={() => {
                clearTimer();
                window.setTimeout(() => setHeldId(null), 420);
              }}
              onPointerCancel={() => {
                clearTimer();
                setHeldId(null);
              }}
              onClick={(event) => {
                event.stopPropagation();
                event.preventDefault();
                if (held.current) return;
                setOpenId((current) => (current === pin.id ? null : pin.id));
              }}
            >
              <BadgeIcon glyph={pin.glyph} tone={pin.tone} mark={pin.mark} size={size} />
            </span>
            {open ? (
              <span role="tooltip" className="badge-tip text-xs">
                <span className="block font-medium text-fg">{pin.name}</span>
                <span className="mt-0.5 block text-muted">{pin.detail}</span>
              </span>
            ) : null}
          </span>
        );
      })}
    </span>
  );
}

export function BadgeBoard({ result }: { result: BadgeResult }) {
  const [activeId, setActiveId] = useState<string | null>(result.featured[0]?.id ?? result.earned[0]?.id ?? null);
  const active = result.earned.find((pin) => pin.id === activeId) ?? result.featured[0] ?? null;

  return (
    <div className="grid gap-4">
      <div>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4" data-noswipe>
          {result.earned.map((pin) => {
            const on = pin.id === active?.id;
            return (
              <button
                key={pin.id}
                type="button"
                aria-pressed={on}
                aria-label={pin.name}
                onClick={() => setActiveId(pin.id)}
                className={`grid justify-items-center rounded-2xl px-1 py-2 ${on ? "bg-bg-subtle" : ""}`}
              >
                <BadgeIcon glyph={pin.glyph} tone={pin.tone} mark={pin.mark} name={pin.name} size={84} labeled />
              </button>
            );
          })}
        </div>
        {active ? (
          <p className="mt-3 text-sm" role="status">
            <span className="font-medium">{active.name}.</span> <span className="text-muted">{active.detail}</span>
          </p>
        ) : (
          <p className="mt-3 text-sm text-muted">No badges on this identity yet.</p>
        )}
      </div>
      <ul className="grid gap-3 sm:grid-cols-2">
        {result.ladders.map((ladder) => (
          <li key={ladder.id} className="rounded-2xl bg-bg-subtle p-3">
            <div className="flex items-center gap-3">
              {ladder.current ? <BadgeIcon glyph={ladder.current.glyph} tone={ladder.current.tone} mark={ladder.current.mark} name={ladder.current.name} size={56} labeled /> : <span className="text-xs text-faint">–</span>}
              <div className="min-w-0 flex-1">
                <p className="font-mono text-xs tracking-widest text-faint uppercase">{ladder.label}</p>
                <p className="truncate text-sm">{ladder.current?.name ?? "Not started"}</p>
              </div>
            </div>
            <p className="mt-2 text-sm text-muted">
              {ladder.value.toLocaleString("en-US")} {ladder.unit}
              {ladder.next && ladder.nextAt != null ? `. Next is ${ladder.next.name} at ${ladder.nextAt.toLocaleString("en-US")}.` : ". Top mark."}
            </p>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-bg">
              <div className="h-full rounded-full bg-violet" style={{ width: ladder.nextAt == null ? "100%" : `${Math.max(8, Math.min(100, Math.round((ladder.value / ladder.nextAt) * 100)))}%` }} />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
