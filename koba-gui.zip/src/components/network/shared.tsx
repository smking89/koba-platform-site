import { useEffect, useState, type ReactNode } from "react";
import { Chip } from "@/components/ui";
import { cn } from "@/lib/cn";
import type { Listing } from "@/site/catalog";

export function CountUp({ value, from }: { value: number; from?: number }) {
  const origin = from ?? value;
  const [n, setN] = useState(origin);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || origin === value) {
      setN(value);
      return;
    }
    const started = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - started) / 420);
      const eased = 1 - (1 - p) ** 3;
      setN(Math.round(origin + (value - origin) * eased));
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [origin, value]);

  return <>{n.toLocaleString("en-US")}</>;
}

export function PulseFrame({ live, children, className }: { live: boolean; children: ReactNode; className?: string }) {
  return <div className={cn("pulse-frame rounded-3xl", live && "is-live", className)}>{children}</div>;
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="rounded-3xl border border-border bg-bg-elevated p-4">
      <p className="font-mono text-xs text-faint">{label}</p>
      <p className="mt-2 text-2xl font-medium tabular-nums tracking-tight">{value}</p>
      {hint ? <p className="mt-1 text-sm text-muted">{hint}</p> : null}
    </div>
  );
}

export function ServerFace({ listing }: { listing: Listing }) {
  const wash =
    listing.gameId === "dayz"
      ? "color-mix(in oklab, var(--color-cyan) 16%, var(--color-bg-subtle))"
      : listing.style === "Hardcore"
        ? "color-mix(in oklab, var(--color-danger) 14%, var(--color-bg-subtle))"
        : "color-mix(in oklab, var(--color-ok) 14%, var(--color-bg-subtle))";
  return (
    <div className="flex h-16 items-end rounded-3xl bg-bg px-3 py-2" style={{ background: wash }}>
      <div>
        <p className="font-mono text-xs text-faint">{listing.game}</p>
        <p className="text-sm">{listing.region}</p>
      </div>
    </div>
  );
}

export function Tag({ children }: { children: ReactNode }) {
  return <Chip>{children}</Chip>;
}

const FACE = [
  "color-mix(in oklab, var(--color-violet) 72%, var(--color-bg))",
  "color-mix(in oklab, var(--color-cyan) 48%, var(--color-bg))",
  "color-mix(in oklab, var(--color-magenta) 58%, var(--color-bg))",
  "color-mix(in oklab, var(--color-ok) 42%, var(--color-bg))",
  "color-mix(in oklab, var(--color-gold) 46%, var(--color-bg))",
];

export function PlayerFace({ name, id, size = "md" }: { name: string; id: string; size?: "sm" | "md" | "lg" }) {
  const initials = name
    .split(" ")
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  let hash = 0;
  for (const char of id) hash += char.charCodeAt(0);
  const box = size === "lg" ? "h-16 w-16 text-lg" : size === "sm" ? "h-9 w-9 text-xs" : "h-11 w-11 text-sm";
  return (
    <span className={`grid shrink-0 place-items-center rounded-full font-medium text-fg ${box}`} style={{ background: FACE[hash % FACE.length] }} aria-hidden>
      {initials}
    </span>
  );
}
