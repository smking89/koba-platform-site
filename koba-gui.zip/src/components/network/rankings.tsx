import type { Identity } from "@/platform/engine";
import { BadgeRow } from "@/components/network/badges";
import { useResolvedBadges } from "@/components/network/badge-state";
import { metaFor, scoreFor, type GameId, type Region } from "@/site/catalog";

export function RankingsPage({
  identities,
  viewerId,
  game,
  region,
  follows,
  clanIds,
  onGame,
  onRegion,
  onOpen,
}: {
  identities: Identity[];
  viewerId: string;
  game: GameId;
  region: "all" | Region;
  follows: string[];
  clanIds: string[];
  onGame: (game: GameId) => void;
  onRegion: (region: "all" | Region) => void;
  onOpen: (id: string) => void;
}) {
  const rows = identities
    .filter((identity) => region === "all" || metaFor(identity.id, identity.score).region === region)
    .map((identity) => ({ identity, score: scoreFor(identity.id, identity.score, game) }))
    .sort((a, b) => b.score - a.score);
  const badgeMap = useResolvedBadges(identities);

  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-medium tracking-tight">Rankings</h1>
        <p className="mt-1 max-w-xl text-sm text-muted">KOBA Score, not a single game’s raw kills. Switch the board when you care about DayZ instead of Rust.</p>
      </div>
      <div className="grid min-w-0 gap-2">
        <div className="flex gap-2 overflow-x-auto" data-noswipe>
        {(
          [
            ["all", "All games"],
            ["rust", "Rust Console"],
            ["dayz", "DayZ"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            aria-pressed={game === id}
            onClick={() => onGame(id)}
            className={`h-9 shrink-0 border px-3 text-sm whitespace-nowrap ${game === id ? "border-fg bg-fg text-bg" : "border-border text-muted"}`}
          >
            {label}
          </button>
        ))}
        </div>
        <div className="hidden gap-2 overflow-x-auto lg:flex" data-noswipe>
        {(["all", "NA", "EU", "OCE"] as const).map((id) => (
          <button
            key={id}
            type="button"
            aria-pressed={region === id}
            onClick={() => onRegion(id)}
            className={`h-9 shrink-0 border px-3 text-sm whitespace-nowrap ${region === id ? "border-fg bg-fg text-bg" : "border-border text-muted"}`}
          >
            {id === "all" ? "All regions" : id}
          </button>
        ))}
        </div>
      </div>
      <ol className="rounded-3xl border border-border bg-bg-elevated">
        {rows.map((row, index) => {
          const friend = follows.includes(row.identity.id);
          const clan = clanIds.includes(row.identity.id);
          const you = row.identity.id === viewerId;
          return (
            <li key={row.identity.id} className="border-b border-border last:border-b-0">
              <button type="button" onClick={() => onOpen(row.identity.id)} className="flex min-h-14 w-full items-center justify-between gap-3 px-4 text-left">
                <span className="min-w-0">
                  <span className="font-mono text-xs text-faint">{String(index + 1).padStart(2, "0")}</span>
                  <span className="ml-3 inline-flex items-center gap-1 text-sm">
                    {row.identity.name}
                    <BadgeRow pins={(badgeMap[row.identity.id]?.earned ?? []).filter((pin) => pin.id === "verified")} size={14} />
                  </span>
                  <span className="mt-0.5 block text-sm text-muted sm:mt-0 sm:ml-8 sm:inline">
                    {metaFor(row.identity.id, row.identity.score).region}
                    {you ? " · you" : ""}
                    {friend ? " · followed" : ""}
                    {clan ? " · clan" : ""}
                  </span>
                </span>
                <span className="text-right">
                  <span className="block font-mono text-sm tabular-nums">{row.score.toLocaleString("en-US")}</span>
                  <span className={`font-mono text-xs ${row.identity.scoreDelta >= 0 ? "text-ok" : "text-danger"}`}>
                    {row.identity.scoreDelta >= 0 ? "↑" : "↓"} {Math.abs(row.identity.scoreDelta)}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
        {rows.length === 0 ? <li className="px-4 py-6 text-sm text-muted">Nobody on this board.</li> : null}
      </ol>
    </div>
  );
}
