import { useState } from "react";
import { Button, Chip } from "@/components/ui";
import { PlayerFace } from "@/components/network/shared";
import { VerifiedMark } from "@/components/network/shop";
import { cn } from "@/lib/cn";
import { AccessPanel } from "@/components/network/access-panel";
import { runPulse } from "@/engine/pipeline";
import { ACTIONS, type Compliance } from "@/engine/types";
import { usePulse } from "@/state/pulse";
import { usePlatform, type DeskGrant } from "@/platform/store";
import type { AuditRow, DisciplineStatus, Embed, FeedRow, Identity, ServerAdapter } from "@/platform/engine";
import { gameLabel } from "@/platform/engine";
import { accountFor, formatCoins, quote, specFor, type AstroAccount, type ShopProduct } from "@/site/astro";
import type { Desk } from "@/site/ui";

const STATUS: Record<DisciplineStatus, string> = {
  clear: "Clear",
  warned: "Warned",
  struck: "Struck",
  under_review: "Review",
  blacklisted: "Banned",
};

export function DeskPage({
  desk,
  viewer,
  identities,
  groups,
  servers,
  feed,
  audit,
  products,
  opened,
  account,
  onAct,
  onOpenBusiness,
  onOpenPlayer,
  onShop,
  onReset,
}: {
  desk: Exclude<Desk, "play">;
  viewer: Identity;
  identities: Identity[];
  groups: { id: string; name: string; tag: string; ownerId: string }[];
  servers: ServerAdapter[];
  feed: FeedRow[];
  audit: AuditRow[];
  products: ShopProduct[];
  opened: Record<string, string>;
  account: AstroAccount;
  onAct: (line: string) => Embed;
  onOpenBusiness: (name: string) => void;
  onOpenPlayer: (id: string) => void;
  onShop: () => void;
  onReset: () => void;
}) {
  if (desk === "business") {
    return (
      <BusinessDesk
        viewer={viewer}
        account={account}
        products={products.filter((product) => product.sellerId === viewer.id)}
        feed={feed}
        onOpenBusiness={onOpenBusiness}
        onShop={onShop}
      />
    );
  }
  if (desk === "mod") {
    return <ModDesk identities={identities} onAct={onAct} onOpenPlayer={onOpenPlayer} />;
  }
  if (desk === "admin") {
    return (
      <AdminDesk
        identities={identities}
        groups={groups}
        servers={servers}
        products={products}
        feed={feed}
        onAct={onAct}
        onOpenPlayer={onOpenPlayer}
      />
    );
  }
  return (
    <SuperDesk
      identities={identities}
      opened={opened}
      audit={audit}
      onAct={onAct}
      onOpenPlayer={onOpenPlayer}
      onReset={onReset}
    />
  );
}

function BusinessDesk({
  viewer,
  account,
  products,
  feed,
  onOpenBusiness,
  onShop,
}: {
  viewer: Identity;
  account: AstroAccount;
  products: ShopProduct[];
  feed: FeedRow[];
  onOpenBusiness: (name: string) => void;
  onShop: () => void;
}) {
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const fee = quote(100, account.verified);
  const once = products.reduce((sum, product) => sum + quote(product.price, account.verified).payout, 0);
  const sales = feed.filter((row) => row.title.includes("bought") && row.detail.startsWith(viewer.name));

  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-12">
      <DeskIntro
        kicker="Business"
        title={account.business ? account.businessName || "Business" : "No business yet"}
        body="Buyers pay the listed price. You receive that price minus the Astro fee. Opening a business does not verify the account."
        className="xl:col-span-7"
      />
      <section className="dash-card min-w-0 p-4 xl:col-span-5">
        <p className="font-mono text-xs tracking-widest text-faint uppercase">Seller fee</p>
        <div className="mt-3">
          <VerifiedMark verified={account.verified} />
        </div>
        <p className="mt-3 text-3xl font-medium tabular-nums text-ok">{fee.label}</p>
        <p className="mt-1 text-sm text-muted">Verified sellers pay 2.5%. Unverified sellers pay 3.5%.</p>
        <p className="mt-3 font-mono text-xs text-cyan">{formatCoins(viewer.coins)} coins on hand</p>
      </section>

      {account.business ? (
        <section className="dash-card min-w-0 p-4 md:col-span-2 xl:col-span-7">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Listings</h2>
            <button type="button" onClick={onShop} className="min-h-11 rounded-full px-2 text-sm text-cyan">
              Official shop
            </button>
          </div>
          {products.length === 0 ? <p className="mt-3 text-sm text-muted">Nothing listed under this business yet.</p> : null}
          <ul className="mt-2 grid gap-2">
            {products.map((product) => {
              const sale = quote(product.price, account.verified);
              return (
                <li key={product.id} className="grid min-h-16 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl bg-bg-subtle px-3 py-2">
                  <span className="min-w-0">
                    <span className="block truncate text-sm">{product.title}</span>
                    <span className="block truncate font-mono text-xs text-faint">{specFor(product.kind).name}</span>
                  </span>
                  <span className="text-right">
                    <span className="block font-mono text-xs text-fg">{formatCoins(product.price)}</span>
                    <span className="block font-mono text-xs text-ok">You {formatCoins(sale.payout)}</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </section>
      ) : (
        <form
          className="dash-card grid min-w-0 gap-3 p-4 md:col-span-2 xl:col-span-7"
          onSubmit={(event) => {
            event.preventDefault();
            const trimmed = name.trim();
            if (trimmed.length < 2 || trimmed.length > 32) {
              setError("Use 2–32 characters.");
              return;
            }
            setError("");
            onOpenBusiness(trimmed);
          }}
        >
          <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Open a business</h2>
          <p className="text-sm text-muted">Any account can list. The fee stays {fee.label} because this identity is {account.verified ? "verified" : "unverified"}.</p>
          <label className="grid gap-1">
            <span className="font-mono text-xs text-faint">Business name</span>
            <input value={name} onChange={(event) => setName(event.target.value)} className="h-11 rounded-2xl border border-border bg-bg px-3 text-sm" />
          </label>
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button type="submit" variant="primary" className="w-full sm:w-auto">
            Open business account
          </Button>
        </form>
      )}

      <section className="dash-card min-w-0 p-4 xl:col-span-5">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Payout</h2>
        <p className="mt-3 text-3xl font-medium tabular-nums">{formatCoins(once)}</p>
        <p className="mt-1 text-sm text-muted">If every current listing sold once, after the {fee.label} fee.</p>
        <ul className="mt-3">
          {sales.length === 0 ? <li className="text-sm text-muted">No sales on this identity yet.</li> : null}
          {sales.slice(0, 4).map((row) => (
            <li key={row.id} className="border-b border-border/70 py-3 last:border-b-0">
              <p className="text-sm">{row.title}</p>
              <p className="mt-1 text-sm text-muted">{row.detail}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function ModDesk({
  identities,
  onAct,
  onOpenPlayer,
}: {
  identities: Identity[];
  onAct: (line: string) => Embed;
  onOpenPlayer: (id: string) => void;
}) {
  return (
    <div className="grid gap-3">
      <DeskIntro
        kicker="Admin mod"
        title="Discipline queue"
        body="Warn and strike write on this network. A player can hold one warning. Three strikes puts the profile under review."
      />
      <Discipline identities={identities} canClear={false} canBan={false} onAct={onAct} onOpenPlayer={onOpenPlayer} />
    </div>
  );
}

function AdminDesk({
  identities,
  groups,
  servers,
  products,
  feed,
  onAct,
  onOpenPlayer,
}: {
  identities: Identity[];
  groups: { id: string; name: string; tag: string; ownerId: string }[];
  servers: ServerAdapter[];
  products: ShopProduct[];
  feed: FeedRow[];
  onAct: (line: string) => Embed;
  onOpenPlayer: (id: string) => void;
}) {
  const open = identities.filter((identity) => identity.status !== "clear").length;
  const coins = identities.reduce((sum, identity) => sum + identity.coins, 0);
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-12">
      <DeskIntro
        kicker="Admin"
        title="Network overview"
        body="Players, groups, servers, and the Official shop. Mod tools on this seat can warn and strike. Clearing a strike stays with superadmin."
        className="xl:col-span-12"
      />
      <Stat label="Players" value={String(identities.length)} className="xl:col-span-3" />
      <Stat label="Open cases" value={String(open)} className="xl:col-span-3" />
      <Stat label="Servers" value={String(servers.length)} className="xl:col-span-3" />
      <Stat label="Coins" value={formatCoins(coins)} className="xl:col-span-3" />
      <section className="dash-card min-w-0 p-4 xl:col-span-6">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Groups</h2>
        <ul className="mt-2">
          {groups.map((group) => {
            const owner = identities.find((identity) => identity.id === group.ownerId);
            return (
              <li key={group.id} className="flex min-h-12 items-center justify-between gap-3 border-b border-border/70 last:border-b-0">
                <span className="min-w-0">
                  <span className="block truncate text-sm">{group.name}</span>
                  <span className="font-mono text-xs text-faint">{group.tag}</span>
                </span>
                <span className="truncate text-sm text-muted">{owner?.name ?? "Unowned"}</span>
              </li>
            );
          })}
        </ul>
      </section>
      <section className="dash-card min-w-0 p-4 xl:col-span-6">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Servers</h2>
        <ul className="mt-2">
          {servers.map((server) => (
            <li key={server.id} className="flex min-h-12 items-center justify-between gap-3 border-b border-border/70 last:border-b-0">
              <span className="min-w-0">
                <span className="block truncate text-sm">{server.name}</span>
                <span className="font-mono text-xs text-faint">{gameLabel(server.game)}</span>
              </span>
              <Chip tone={server.license === "active" ? "ok" : "danger"}>{server.license}</Chip>
            </li>
          ))}
        </ul>
        <p className="mt-3 font-mono text-xs text-muted">{products.length} shop listings · {feed.length} feed notes</p>
      </section>
      <div className="md:col-span-2 xl:col-span-12">
        <Discipline identities={identities} canClear={false} canBan={false} onAct={onAct} onOpenPlayer={onOpenPlayer} />
      </div>
    </div>
  );
}

function EngineConsole() {
  const weights = usePulse((state) => state.weights);
  const setWeight = usePulse((state) => state.setWeight);
  const resetWeights = usePulse((state) => state.resetWeights);
  const overrides = usePulse((state) => state.overrides);
  const setOverride = usePulse((state) => state.setOverride);
  const clearOverride = usePulse((state) => state.clearOverride);
  const result = runPulse({
    viewerId: "mara",
    query: "",
    weights,
    boosts: {},
    overrides,
    dismissed: [],
    nowMs: 0,
    limit: 8,
  });
  return (
    <section className="dash-card grid gap-4 p-4 lg:grid-cols-[16rem_minmax(0,1fr)]">
      <div>
        <h2 className="text-sm">Ranker</h2>
        <p className="mt-1 text-xs text-muted">Live weights for Mara. Moving a slider reruns the pulse. Cluster: {result.clusterName}.</p>
        <ul className="mt-3 grid gap-3">
          {ACTIONS.map((action) => (
            <li key={action.id}>
              <label className="grid gap-1 text-xs text-muted">
                <span className="flex justify-between">
                  {action.label}
                  <span className="font-mono text-fg">{weights[action.id].toFixed(2)}</span>
                </span>
                <input
                  type="range"
                  min={0}
                  max={2}
                  step={0.05}
                  value={weights[action.id]}
                  onChange={(event) => setWeight(action.id, Number(event.target.value))}
                />
              </label>
            </li>
          ))}
        </ul>
        <Button variant="ghost" className="mt-3" onClick={resetWeights}>
          Reset weights
        </Button>
      </div>
      <div className="min-w-0">
        <h2 className="text-sm">Feed after the gates</h2>
        <ul className="mt-2 divide-y divide-border border-y border-border">
          {result.feed.map((item, index) => {
            const gate = overrides[item.candidate.id];
            return (
              <li key={item.candidate.id} className="flex items-center gap-3 py-2 text-sm">
                <span className="w-5 font-mono text-xs text-faint">{index + 1}</span>
                <span className="min-w-0 flex-1 truncate">{item.candidate.title}</span>
                <span className="font-mono text-xs text-muted">{item.clickScore.toFixed(2)}</span>
                <select
                  value={gate ?? "allow"}
                  onChange={(event) => {
                    const next = event.target.value as Compliance | "allow";
                    if (next === "allow") clearOverride(item.candidate.id);
                    else setOverride(item.candidate.id, next);
                  }}
                  className="h-8 border border-border bg-bg px-1 text-xs"
                >
                  <option value="allow">Allow</option>
                  <option value="interstitial">Hold</option>
                  <option value="drop">Drop</option>
                </select>
              </li>
            );
          })}
        </ul>
        {result.dropped.length ? <p className="mt-2 text-xs text-muted">{result.dropped.length} dropped by the compliance gate.</p> : null}
      </div>
    </section>
  );
}

function SuperDesk({
  identities,
  opened,
  audit,
  onAct,
  onOpenPlayer,
  onReset,
}: {
  identities: Identity[];
  opened: Record<string, string>;
  audit: AuditRow[];
  onAct: (line: string) => Embed;
  onOpenPlayer: (id: string) => void;
  onReset: () => void;
}) {
  const servers = usePlatform((state) => state.servers);
  const grants = usePlatform((state) => state.grants);
  const assignGrant = usePlatform((state) => state.assignGrant);
  const removeIdentity = usePlatform((state) => state.removeIdentity);
  const [note, setNote] = useState("");
  const open = identities.filter((identity) => identity.status !== "clear").length;
  const banned = identities.filter((identity) => identity.status === "blacklisted").length;
  const coins = identities.reduce((sum, identity) => sum + identity.coins, 0);
  const connected = servers.filter((server) => server.license === "active").length;
  const clearShare = identities.length ? Math.round(((identities.length - banned) / identities.length) * 100) : 0;
  const scores = identities.map((identity) => identity.score);
  return (
    <div className="grid grid-cols-1 gap-3 xl:grid-cols-12">
      <div className="grid grid-cols-2 gap-2 xl:col-span-12 xl:grid-cols-4">
        <StatCard label="Players" value={String(identities.length)} series={scores.length > 1 ? scores : [1, 2, 3, 2]} />
        <StatCard label="Open cases" value={String(open)} series={[1, open + 1, Math.max(1, open), open + 2, open]} />
        <StatCard label="APIs connected" value={`${connected}/${servers.length}`} series={servers.map((server) => (server.license === "active" ? 3 : 1))} />
        <StatCard label="Coins" value={formatCoins(coins)} series={identities.map((identity) => identity.coins)} />
      </div>
      <AccessPanel />
      <section className="dash-card min-w-0 p-4 xl:col-span-8">
        <h2 className="text-sm">Staff</h2>
        <p className="mt-1 text-xs text-muted">Assign a lower role, rotate that credential, blacklist, or delete. Super cannot delete the identity you are signed in as.</p>
        {note ? <p className="mt-3 border border-border px-3 py-2 text-sm">{note}</p> : null}
        <ul className="mt-3 divide-y divide-border border-y border-border">
          {identities.map((identity) => {
            const grant = grants[identity.id] ?? "player";
            const standing = accountFor(identity.id, opened);
            return (
              <li key={identity.id} className="grid gap-2 py-3">
                <div className="flex items-center gap-3">
                  <button type="button" onClick={() => onOpenPlayer(identity.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                    <PlayerFace name={identity.name} id={identity.id} size="sm" />
                    <span className="min-w-0">
                      <span className="block truncate text-sm">{identity.name}</span>
                      <span className="block truncate font-mono text-xs text-faint">{standing.verified ? "Verified · 2.5%" : "Unverified · 3.5%"}</span>
                    </span>
                  </button>
                  <Chip tone={identity.status === "blacklisted" ? "danger" : identity.status === "clear" ? "ok" : "warn"}>{STATUS[identity.status]}</Chip>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    aria-label={`Role for ${identity.name}`}
                    value={grant}
                    onChange={(event) => assignGrant(identity.id, event.target.value as DeskGrant)}
                    className="h-9 border border-border bg-bg px-2 text-sm"
                  >
                    {(["player", "business", "mod", "admin", "super"] as const).map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className="h-9 border border-border px-2 text-xs"
                    onClick={() => onAct(identity.status === "blacklisted" ? `/globalunban ${identity.handle}` : `/globalban ${identity.handle}`)}
                  >
                    {identity.status === "blacklisted" ? "Lift blacklist" : "Blacklist"}
                  </button>
                  <button
                    type="button"
                    className="h-9 border border-danger px-2 text-xs text-danger"
                    onClick={() => {
                      const result = removeIdentity(identity.id);
                      setNote(result.ok ? `${identity.name} deleted.` : result.reason);
                    }}
                  >
                    Delete
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
      <div className="grid min-w-0 gap-3 xl:col-span-4">
        <section className="dash-card p-4">
          <h2 className="text-sm">Standing</h2>
          <div className="mt-3 flex items-center gap-4">
            <Ring percent={clearShare} />
            <div>
              <p className="font-mono text-2xl">{clearShare}%</p>
              <p className="text-xs text-muted">Not blacklisted</p>
              <p className="mt-2 text-xs text-muted">{banned} on the blacklist</p>
            </div>
          </div>
        </section>
      </div>
      <p className="text-sm text-muted xl:hidden">Ranker weights stay on a computer.</p>
      <div className="hidden xl:col-span-12 xl:block">
        <EngineConsole />
      </div>
      <section className="dash-card flex min-w-0 flex-col justify-between gap-3 p-4 xl:col-span-4">
        <div>
          <p className="text-sm">Reset</p>
          <p className="mt-2 text-sm text-muted">Restores identities, keys, roles, and the shop to the fixture.</p>
        </div>
        <Button variant="ghost" onClick={onReset}>
          Reset network
        </Button>
      </section>
      <section className="dash-card min-w-0 p-4 xl:col-span-8">
        <h2 className="text-sm">Audit</h2>
        <ul className="mt-2">
          {audit.slice(0, 6).map((row) => (
            <li key={row.id} className="border-b border-border py-2 last:border-b-0">
              <p className="text-sm">{row.action}</p>
              <p className="text-xs text-muted">{row.actor} · {row.detail}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function StatCard({ label, value, series }: { label: string; value: string; series: number[] }) {
  return (
    <section className="dash-card p-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-mono text-2xl">{value}</p>
      <Spark series={series.length > 1 ? series : [1, 1]} />
    </section>
  );
}

function Spark({ series }: { series: number[] }) {
  const w = 120;
  const h = 32;
  const min = Math.min(...series);
  const max = Math.max(...series);
  const span = max - min || 1;
  const d = series
    .map((point, index) => {
      const x = (index / Math.max(1, series.length - 1)) * w;
      const y = h - 2 - ((point - min) / span) * (h - 6);
      return `${index ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="mt-2 h-8 w-full" aria-hidden>
      <path d={d} fill="none" stroke="#ffffff" strokeWidth="1.5" />
    </svg>
  );
}

function Ring({ percent }: { percent: number }) {
  const r = 28;
  const c = 2 * Math.PI * r;
  const dash = (Math.max(0, Math.min(100, percent)) / 100) * c;
  return (
    <svg viewBox="0 0 72 72" className="h-16 w-16" aria-hidden>
      <circle cx="36" cy="36" r={r} fill="none" stroke="#2e2e2e" strokeWidth="6" />
      <circle cx="36" cy="36" r={r} fill="none" stroke="#ffffff" strokeWidth="6" strokeDasharray={`${dash} ${c}`} transform="rotate(-90 36 36)" />
    </svg>
  );
}

function Discipline({
  identities,
  canClear,
  canBan,
  onAct,
  onOpenPlayer,
}: {
  identities: Identity[];
  canClear: boolean;
  canBan: boolean;
  onAct: (line: string) => Embed;
  onOpenPlayer: (id: string) => void;
}) {
  const [note, setNote] = useState("");
  const act = (line: string) => {
    const embed = onAct(line);
    setNote(`${embed.title}. ${embed.description}`);
  };
  const rows = identities.slice().sort((a, b) => rankStatus(b.status) - rankStatus(a.status) || b.strikes - a.strikes);
  return (
    <section className="dash-card min-w-0 p-4">
      <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Players</h2>
      {note ? <p className="mt-3 rounded-2xl bg-bg-subtle px-3 py-3 text-sm">{note}</p> : null}
      <ul className="mt-2 grid gap-2">
        {rows.map((identity) => (
          <li key={identity.id} className="rounded-2xl bg-bg-subtle p-3">
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => onOpenPlayer(identity.id)} className="flex min-h-11 min-w-0 flex-1 items-center gap-3 text-left">
                <PlayerFace name={identity.name} id={identity.id} size="sm" />
                <span className="min-w-0">
                  <span className="block truncate text-sm">{identity.name}</span>
                  <span className="font-mono text-xs text-faint">@{identity.handle}</span>
                </span>
              </button>
              <Chip tone={identity.status === "clear" ? "ok" : identity.status === "warned" ? "warn" : "danger"}>{STATUS[identity.status]}</Chip>
            </div>
            <p className="mt-2 font-mono text-xs text-muted">
              {identity.warnings} warning · {identity.strikes}/3 strikes
            </p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Button variant="ghost" disabled={identity.warnings >= 1} onClick={() => act(`/mod warning ${identity.handle}`)}>
                Warn
              </Button>
              <Button variant="ghost" disabled={identity.strikes >= 3 || identity.status === "blacklisted"} onClick={() => act(`/mod strike ${identity.handle}`)}>
                Strike
              </Button>
              {canClear ? (
                <Button variant="ghost" disabled={identity.strikes <= 0} onClick={() => act(`/mod clear ${identity.handle}`)}>
                  Clear strike
                </Button>
              ) : null}
              {canBan ? (
                <Button
                  variant="ghost"
                  onClick={() => act(identity.status === "blacklisted" ? `/globalunban ${identity.handle}` : `/globalban ${identity.handle}`)}
                >
                  {identity.status === "blacklisted" ? "Lift ban" : "Ban"}
                </Button>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function DeskIntro({ kicker, title, body, className }: { kicker: string; title: string; body: string; className?: string }) {
  return (
    <section className={cn("dash-card min-w-0 p-4", className)}>
      <p className="font-mono text-xs tracking-widest text-faint uppercase">{kicker}</p>
      <h1 className="mt-2 text-2xl font-medium tracking-tight">{title}</h1>
      <p className="mt-2 text-sm text-muted">{body}</p>
    </section>
  );
}

function Stat({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <section className={cn("dash-card min-w-0 p-4", className)}>
      <p className="font-mono text-xs tracking-widest text-faint uppercase">{label}</p>
      <p className="mt-2 text-2xl font-medium tabular-nums">{value}</p>
    </section>
  );
}

function rankStatus(status: DisciplineStatus): number {
  if (status === "blacklisted") return 5;
  if (status === "under_review") return 4;
  if (status === "struck") return 3;
  if (status === "warned") return 2;
  return 1;
}
