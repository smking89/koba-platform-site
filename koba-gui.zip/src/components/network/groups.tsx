import { useState } from "react";
import { Hash, Mic, Plus, Send } from "lucide-react";
import { MenuSelect } from "@/components/ui";
import type { Identity } from "@/platform/engine";
import { useCommunity } from "@/site/community";

export function GroupsPage({ viewer, identities }: { viewer: Identity; identities: Identity[] }) {
  const groups = useCommunity((s) => s.groups);
  const roles = useCommunity((s) => s.roles);
  const members = useCommunity((s) => s.members);
  const categories = useCommunity((s) => s.categories);
  const channels = useCommunity((s) => s.channels);
  const rooms = useCommunity((s) => s.rooms);
  const activeGroup = useCommunity((s) => s.activeGroup);
  const activeChannel = useCommunity((s) => s.activeChannel);
  const setActiveGroup = useCommunity((s) => s.setActiveGroup);
  const setActiveChannel = useCommunity((s) => s.setActiveChannel);
  const createGroup = useCommunity((s) => s.createGroup);
  const joinGroup = useCommunity((s) => s.joinGroup);
  const addCategory = useCommunity((s) => s.addCategory);
  const addChannel = useCommunity((s) => s.addChannel);
  const addRole = useCommunity((s) => s.addRole);
  const moveRole = useCommunity((s) => s.moveRole);
  const postRoom = useCommunity((s) => s.postRoom);
  const canManage = useCommunity((s) => s.canManage);

  const [groupName, setGroupName] = useState("");
  const [categoryName, setCategoryName] = useState("");
  const [channelName, setChannelName] = useState("");
  const [channelKind, setChannelKind] = useState<"text" | "voice">("text");
  const [categoryId, setCategoryId] = useState("");
  const [roleName, setRoleName] = useState("");
  const [draft, setDraft] = useState("");
  const [note, setNote] = useState("");

  const group = groups.find((item) => item.id === activeGroup) ?? groups[0];
  const member = members.find((item) => item.groupId === group?.id && item.identityId === viewer.id);
  const manage = group ? canManage(group.id, viewer.id) : false;
  const groupRoles = roles.filter((item) => item.groupId === group?.id).slice().sort((a, b) => b.rank - a.rank);
  const groupCategories = categories.filter((item) => item.groupId === group?.id).slice().sort((a, b) => a.rank - b.rank);
  const channel = channels.find((item) => item.id === activeChannel && item.groupId === group?.id) ?? channels.find((item) => item.groupId === group?.id);
  const lines = channel ? rooms[channel.id] ?? [] : [];

  const nameFor = (id: string) => identities.find((identity) => identity.id === id)?.name ?? id;

  return (
    <div className="grid gap-4 xl:grid-cols-[16rem_minmax(0,1fr)]">
      <div className="grid content-start gap-3">
        <div className="flex gap-2 overflow-x-auto pb-1" data-noswipe>
          {groups.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveGroup(item.id)}
              className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl font-mono text-xs ${item.id === group?.id ? "bg-ok/15 text-ok" : "text-muted"}`}
              aria-label={item.name}
            >
              {item.tag}
            </button>
          ))}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            createGroup(viewer.id, groupName);
            setGroupName("");
          }}
        >
          <input value={groupName} onChange={(event) => setGroupName(event.target.value)} placeholder="Group name" aria-label="New group" className="h-11 min-w-0 flex-1 rounded-full bg-bg-subtle px-4 text-sm outline-none" />
          <button type="submit" aria-label="Create group" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-fg text-bg"><Plus size={18} /></button>
        </form>
        {group ? (
          <section className="rounded-2xl border border-border bg-bg-elevated p-3">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-sm font-medium">{group.name}</h2>
              {member ? <span className="font-mono text-[10px] text-ok">Joined</span> : (
                <button type="button" className="min-h-11 text-xs text-cyan" onClick={() => joinGroup(group.id, viewer.id)}>Join</button>
              )}
            </div>
            <p className="mt-1 text-xs text-muted">Owner {nameFor(group.ownerId)}. Higher roles sit above lower ones.</p>
            <div className="mt-3 grid gap-3">
              {groupCategories.map((category) => (
                <div key={category.id}>
                  <p className="font-mono text-[10px] tracking-[0.14em] text-faint uppercase">{category.name}</p>
                  <div className="mt-1 grid">
                    {channels
                      .filter((item) => item.categoryId === category.id)
                      .slice()
                      .sort((a, b) => a.rank - b.rank)
                      .map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setActiveChannel(item.id)}
                          className={`flex min-h-11 items-center gap-2 rounded-lg px-2 text-left text-sm ${item.id === channel?.id ? "bg-ok/10 text-ok" : "text-muted"}`}
                        >
                          {item.kind === "voice" ? <Mic size={14} /> : <Hash size={14} />}
                          {item.name}
                        </button>
                      ))}
                  </div>
                </div>
              ))}
            </div>
            {manage ? (
              <div className="mt-3 grid gap-2 border-t border-border pt-3">
                <form className="flex gap-2" onSubmit={(event) => { event.preventDefault(); const id = addCategory(group.id, viewer.id, categoryName); setNote(id ? "Category added." : "Could not add category."); setCategoryName(""); }}>
                  <input value={categoryName} onChange={(event) => setCategoryName(event.target.value)} placeholder="Category" aria-label="Category" className="h-11 min-w-0 flex-1 rounded-full bg-bg px-4 text-sm outline-none" />
                  <button type="submit" aria-label="Add category" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-fg text-bg"><Plus size={16} /></button>
                </form>
                <form className="grid gap-2" onSubmit={(event) => {
                  event.preventDefault();
                  const chosen = categoryId || groupCategories[0]?.id;
                  if (!chosen) return;
                  const id = addChannel(group.id, viewer.id, chosen, channelName, channelKind);
                  setNote(id ? "Channel added." : "Could not add channel.");
                  setChannelName("");
                }}>
                  <div className="flex gap-2">
                    <input value={channelName} onChange={(event) => setChannelName(event.target.value)} placeholder="Channel" aria-label="Channel" className="h-11 min-w-0 flex-1 rounded-full bg-bg px-4 text-sm outline-none" />
                    <MenuSelect
                      className="w-32 shrink-0"
                      ariaLabel="Channel type"
                      value={channelKind}
                      options={[
                        { value: "text", label: "Text" },
                        { value: "voice", label: "Voice" },
                      ]}
                      onChange={(value) => setChannelKind(value as "text" | "voice")}
                    />
                  </div>
                  <MenuSelect
                    ariaLabel="Category"
                    value={categoryId || groupCategories[0]?.id || ""}
                    options={groupCategories.map((category) => ({ value: category.id, label: category.name }))}
                    onChange={setCategoryId}
                  />
                  <button type="submit" aria-label="Add channel" className="grid h-11 w-11 place-items-center rounded-full bg-fg text-bg"><Plus size={16} /></button>
                </form>
              </div>
            ) : (
              <p className="mt-3 text-xs text-muted">Owner and officer roles can add channels, categories, and roles.</p>
            )}
          </section>
        ) : null}
        {group ? (
          <section className="rounded-2xl border border-border bg-bg-elevated p-3">
            <h2 className="text-sm font-medium">Roles</h2>
            <ol className="mt-2 grid gap-1">
              {groupRoles.map((role) => (
                <li key={role.id} className="flex min-h-11 items-center justify-between gap-2 px-1">
                  <span className="text-sm">{role.name} <span className="font-mono text-[10px] text-faint">rank {role.rank}</span></span>
                  {manage && role.name !== "Owner" ? (
                    <span className="flex gap-1">
                      <button type="button" className="min-h-11 px-2 text-xs" onClick={() => moveRole(group.id, viewer.id, role.id, -1)} aria-label={`Move ${role.name} up`}>Up</button>
                      <button type="button" className="min-h-11 px-2 text-xs" onClick={() => moveRole(group.id, viewer.id, role.id, 1)} aria-label={`Move ${role.name} down`}>Down</button>
                    </span>
                  ) : null}
                </li>
              ))}
            </ol>
            {manage ? (
              <form className="mt-2 flex gap-2" onSubmit={(event) => { event.preventDefault(); const id = addRole(group.id, viewer.id, roleName); setNote(id ? "Role added under the current ranks." : "Could not add role."); setRoleName(""); }}>
                <input value={roleName} onChange={(event) => setRoleName(event.target.value)} placeholder="Role name" aria-label="New role" className="h-11 min-w-0 flex-1 rounded-full bg-bg px-4 text-sm outline-none" />
                <button type="submit" aria-label="Add role" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-fg text-bg"><Plus size={16} /></button>
              </form>
            ) : null}
            {note ? <p className="mt-2 text-xs text-ok">{note}</p> : null}
          </section>
        ) : null}
      </div>

      <section className="grid min-h-[24rem] content-start gap-3 rounded-2xl border border-border bg-bg-elevated p-4">
        {channel ? (
          <>
            <header>
              <p className="font-mono text-[10px] tracking-[0.16em] text-faint uppercase">{channel.kind}</p>
              <h2 className="text-lg font-medium">{channel.name}</h2>
            </header>
            <div className="grid gap-2">
              {lines.map((line) => (
                <article key={line.id} className="rounded-2xl bg-bg px-3 py-2">
                  <p className="text-xs text-cyan">{nameFor(line.authorId)}</p>
                  <p className="mt-1 text-sm">{line.text}</p>
                </article>
              ))}
              {lines.length === 0 ? <p className="text-sm text-muted">No messages in this channel yet.</p> : null}
            </div>
            {channel.kind === "text" && member ? (
              <form className="mt-auto flex gap-2" onSubmit={(event) => { event.preventDefault(); postRoom(channel.id, viewer.id, draft); setDraft(""); }}>
                <input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={`Message ${channel.name}`} aria-label={`Message ${channel.name}`} className="h-11 min-w-0 flex-1 rounded-full bg-bg px-4 text-sm outline-none" />
                <button type="submit" aria-label="Send" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-fg text-bg"><Send size={16} /></button>
              </form>
            ) : (
              <p className="text-sm text-muted">{channel.kind === "voice" ? "Voice channels are listed here. Join the group to talk in text." : "Join the group to post."}</p>
            )}
          </>
        ) : (
          <p className="text-sm text-muted">Pick a group.</p>
        )}
      </section>
    </div>
  );
}
