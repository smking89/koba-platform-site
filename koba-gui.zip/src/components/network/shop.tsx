import { useEffect, useRef, useState } from "react";
import { BadgeIcon } from "@/components/network/badges";
import { Button } from "@/components/ui";
import { PulseFrame } from "@/components/network/shared";
import type { Identity } from "@/platform/engine";
import {
  accountFor,
  ASTRO_PRICE,
  ASTRO_SPECS,
  auditUploads,
  formatBytes,
  formatCoins,
  quote,
  sizeWindow,
  specFor,
  themeError,
  type AstroAccount,
  type AstroGroup,
  type AstroKind,
  type AstroSpec,
  type ListedFile,
  type MeasuredFile,
  type ShopProduct,
} from "@/site/astro";
import { measureFile } from "@/site/measure";

const GROUPS: { id: "all" | AstroGroup; label: string }[] = [
  { id: "all", label: "All sizes" },
  { id: "decoration", label: "Profile decoration" },
  { id: "profile", label: "Profile and client" },
  { id: "chat", label: "Chat and voice" },
];

type UploadRow = MeasuredFile & { preview: string | null };

function release(rows: Array<UploadRow | null>) {
  for (const row of rows) {
    if (row?.preview) URL.revokeObjectURL(row.preview);
  }
}

function CanvasMark({ spec }: { spec: AstroSpec }) {
  const slot = spec.slots.length === 1 ? spec.slots[0] : null;
  if (!slot?.maxWidth || !slot.maxHeight || !slot.minWidth || !slot.minHeight) {
    return (
      <div className="grid h-16 place-items-center rounded-lg border border-dashed border-border bg-bg">
        <p className="font-mono text-xs text-muted">{spec.canvas}</p>
      </div>
    );
  }
  const scale = Math.min(220 / slot.maxWidth, 64 / slot.maxHeight);
  const maxWidth = Math.max(16, Math.round(slot.maxWidth * scale));
  const maxHeight = Math.max(12, Math.round(slot.maxHeight * scale));
  const minWidth = Math.max(8, Math.round(slot.minWidth * scale));
  const minHeight = Math.max(8, Math.round(slot.minHeight * scale));
  const ranged = slot.minWidth !== slot.maxWidth || slot.minHeight !== slot.maxHeight;
  return (
    <div className="grid h-16 place-items-center rounded-lg bg-bg">
      <div className="relative border border-ok/50 bg-ok/10" style={{ width: maxWidth, height: maxHeight }}>
        {ranged ? (
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border border-cyan/70"
            style={{ width: minWidth, height: minHeight }}
          />
        ) : null}
      </div>
    </div>
  );
}

export function MotionPreview({ motion, title, compact = false }: { motion?: string; title: string; compact?: boolean }) {
  const stage = compact ? "astro-stage is-mini" : "astro-stage";
  if (motion === "ring") {
    return (
      <div className={stage} aria-hidden>
        <span className="astro-ring" />
        <span className="astro-face">{title.slice(0, 1)}</span>
      </div>
    );
  }
  if (motion === "plate") {
    return (
      <div className={stage} aria-hidden>
        <span className="astro-plate flex items-center gap-2 text-sm">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-bg text-xs">{title.slice(0, 1)}</span>
          {title}
        </span>
      </div>
    );
  }
  if (motion === "burst") {
    return (
      <div className={stage} aria-hidden>
        <span className="astro-burst" />
        <span className="relative z-10 text-sm">{title}</span>
      </div>
    );
  }
  if (motion === "banner") {
    return (
      <div className={stage} aria-hidden>
        <span className="astro-banner" />
        <span className="relative z-10 text-sm">{title}</span>
      </div>
    );
  }
  if (motion === "stickers") {
    return (
      <div className={stage} aria-hidden>
        <span className="flex gap-2">
          {["Mk", "Ln", "Hd", "Cl"].map((mark, index) => (
            <span key={mark} className="astro-sticker" style={{ animationDelay: `${index * 120}ms` }}>
              {mark}
            </span>
          ))}
        </span>
      </div>
    );
  }
  return null;
}

export function VerifiedMark({ verified }: { verified: boolean }) {
  if (verified) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs">
        <BadgeIcon glyph="seal" tone="cyan" size={18} />
        Verified
      </span>
    );
  }
  return <span className="text-xs text-muted">Unverified</span>;
}

export function ShopPage({
  viewer,
  identities,
  products,
  opened,
  onOpenBusiness,
  onCreate,
  onBuy,
  onOpenPlayer,
  subscribed,
  owned,
  equipped,
  onSubscribe,
  onEndPass,
  onEquip,
}: {
  viewer: Identity;
  identities: Identity[];
  products: ShopProduct[];
  opened: Record<string, string>;
  onOpenBusiness: (name: string) => void;
  onCreate: (draft: { title: string; detail: string; price: number; kind: AstroKind; files: ListedFile[] }) => void;
  onBuy: (product: ShopProduct, seller: AstroAccount) => string | null;
  onOpenPlayer: (id: string) => void;
  subscribed: boolean;
  owned: string[];
  equipped: string | null;
  onSubscribe: () => void;
  onEndPass: () => void;
  onEquip: (productId: string) => boolean;
}) {
  const standing = accountFor(viewer.id, opened);
  const fee = quote(100, standing.verified);
  const [businessName, setBusinessName] = useState("");
  const [businessError, setBusinessError] = useState("");
  const [title, setTitle] = useState("");
  const [detail, setDetail] = useState("");
  const [price, setPrice] = useState("25");
  const [kind, setKind] = useState<AstroKind>("avatar-frame");
  const [group, setGroup] = useState<"all" | AstroGroup>("all");
  const [formError, setFormError] = useState("");
  const [flash, setFlash] = useState(0);
  const [result, setResult] = useState("");
  const [rows, setRows] = useState<Array<UploadRow | null>>([]);
  const [busy, setBusy] = useState(false);
  const [fileEpoch, setFileEpoch] = useState(0);
  const rowsRef = useRef<Array<UploadRow | null>>([]);
  const gen = useRef(0);

  useEffect(() => {
    rowsRef.current = rows;
  }, [rows]);

  useEffect(() => {
    gen.current += 1;
    setRows([]);
    setBusy(false);
    return () => release(rowsRef.current);
  }, [kind]);

  const priceNumber = Number(price);
  const preview = Number.isFinite(priceNumber) && priceNumber > 0 ? quote(priceNumber, standing.verified) : null;

  const openBusiness = () => {
    const name = businessName.trim();
    if (name.length < 2 || name.length > 32) {
      setBusinessError("Use 2–32 characters.");
      return;
    }
    setBusinessError("");
    onOpenBusiness(name);
    setResult(`${name} can list on the Official shop. Verification did not change.`);
    setFlash((value) => value + 1);
  };

  const spec = specFor(kind);
  const visible = ASTRO_SPECS.filter((item) => group === "all" || item.group === group);
  const bounds = sizeWindow(spec);
  const uploads = rows.filter((row): row is UploadRow => row != null);
  const liveIssue = spec.slots.length === 0 ? null : auditUploads(spec, uploads);

  const ingest = async (list: File[], index: number | null) => {
    const token = gen.current + 1;
    gen.current = token;
    setBusy(true);
    setFormError("");
    try {
      const measured = await Promise.all(
        list.map(async (file) => {
          const row = await measureFile(file);
          const preview = row.type.startsWith("image/") ? URL.createObjectURL(file) : null;
          return { ...row, preview };
        }),
      );
      if (gen.current !== token) {
        release(measured);
        return;
      }
      setRows((current) => {
        if (index === null) {
          release(current);
          return measured;
        }
        const next = [...current];
        if (next[index]?.preview) URL.revokeObjectURL(next[index].preview);
        next[index] = measured[0];
        return next;
      });
    } catch {
      if (gen.current !== token) return;
      setFormError("That file could not be read. Check the format and export it again.");
    } finally {
      if (gen.current === token) setBusy(false);
    }
  };

  const create = () => {
    const nextTitle = title.trim();
    const nextDetail = detail.trim();
    if (nextTitle.length < 3 || nextTitle.length > 48) {
      setFormError("Title needs 3–48 characters.");
      return;
    }
    if (nextDetail.length < 8 || nextDetail.length > 140) {
      setFormError("Detail needs 8–140 characters.");
      return;
    }
    if (!Number.isInteger(priceNumber) || priceNumber < 1 || priceNumber > 500) {
      setFormError("Price is a whole number of coins, from 1 to 500.");
      return;
    }
    const colors = themeError(spec, nextDetail);
    if (colors) {
      setFormError(colors);
      return;
    }
    if (spec.slots.length > 0) {
      if (busy) {
        setFormError("Still checking the file size.");
        return;
      }
      const issue = auditUploads(spec, uploads);
      if (issue) {
        setFormError(issue);
        return;
      }
    }
    const files: ListedFile[] = uploads.map((row) => ({
      name: row.name,
      bytes: row.bytes,
      width: row.width,
      height: row.height,
      seconds: row.seconds,
    }));
    setFormError("");
    onCreate({ title: nextTitle, detail: nextDetail, price: priceNumber, kind, files });
    setTitle("");
    setDetail("");
    release(rows);
    setRows([]);
    setFileEpoch((value) => value + 1);
    setResult(`${nextTitle} is listed. Buyers pay ${formatCoins(priceNumber)}. You receive ${formatCoins(quote(priceNumber, standing.verified).payout)} after the ${fee.label} Astro fee.`);
    setFlash((value) => value + 1);
  };

  return (
    <div className="grid gap-5">
      <div>
        <p className="font-mono text-xs text-cyan">Official shop</p>
        <h1 className="mt-1 text-2xl font-medium tracking-tight">KOBA Astro</h1>
        <p className="mt-1 max-w-xl text-sm text-muted">
          Astro is the cosmetic pass. Players equip what they buy. Businesses upload a file between the minimum and the maximum. KOBA does not rescale art.
        </p>
      </div>

      <PulseFrame key={flash} live={flash > 0} className="border border-border bg-bg-elevated p-4">
        <h2 className="text-sm font-medium">How a sale works</h2>
        <ul className="mt-3 grid gap-3 text-sm text-muted">
          <li>Verified accounts get a blue badge. The shop takes 2.5% from the seller.</li>
          <li>Unverified accounts have no badge. The shop takes 3.5% from the seller.</li>
          <li>The buyer pays the listed price. The fee follows the seller, not the buyer.</li>
          <li>Listing is not a verified-player perk. Any business account can create a product, verified or not.</li>
          <li>Upload between the minimum and the maximum for that type, then list. The fee is still 2.5% verified or 3.5% unverified.</li>
          <li>Astro is {ASTRO_PRICE} a month. Cosmetics can be bought without it. Applying one needs an active pass.</li>
        </ul>
      </PulseFrame>

      <section className="rounded-3xl border border-border bg-bg-elevated p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-mono text-xs text-faint">This identity</p>
            <p className="mt-1 text-sm">
              {viewer.name}
              {standing.business && standing.businessName ? ` · ${standing.businessName}` : ""}
            </p>
          </div>
          <VerifiedMark verified={standing.verified} />
        </div>
        <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-3">
          <div>
            <dt className="text-muted">Astro fee</dt>
            <dd className="mt-1 font-mono text-xs">{fee.label}</dd>
          </div>
          <div>
            <dt className="text-muted">Can list</dt>
            <dd className="mt-1 font-mono text-xs">{standing.business ? "Yes" : "No"}</dd>
          </div>
          <div>
            <dt className="text-muted">Coins</dt>
            <dd className="mt-1 font-mono text-xs">{formatCoins(viewer.coins)}</dd>
          </div>
        </dl>
        {result ? (
          <p className="mt-3 text-sm text-fg" role="status">
            {result}
          </p>
        ) : null}
      </section>

      <section className="rounded-3xl border border-border bg-bg-elevated p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-medium">Astro pass</h2>
            <p className="mt-1 text-sm text-muted">
              {ASTRO_PRICE} a month. Each renewal drops 150 coins and unlocks an animated banner for one group. Applying a cosmetic still needs the pass.
            </p>
          </div>
          {subscribed ? (
            <button type="button" onClick={onEndPass} className="min-h-11 text-sm text-muted">
              End Astro
            </button>
          ) : (
            <Button type="button" variant="primary" onClick={onSubscribe}>
              Start Astro · {ASTRO_PRICE}
            </Button>
          )}
        </div>
        <p className="mt-3 text-sm" role="status">
          {subscribed ? "Astro is active. The stipend and group banner are armed." : "Astro is not active. Apply stays locked."}
        </p>
      </section>

      <section className="grid gap-3">
        <div>
          <h2 className="text-sm font-medium">File sizes</h2>
          <p className="mt-1 text-sm text-muted">Product types for the Official shop. The canvas is the file you export. Select one to build it.</p>
        </div>
        <div className="flex gap-2 overflow-x-auto">
          {GROUPS.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={group === item.id}
              onClick={() => {
                setGroup(item.id);
                const matched = ASTRO_SPECS.filter((specRow) => item.id === "all" || specRow.group === item.id);
                if (!matched.some((specRow) => specRow.id === kind)) setKind(matched[0].id);
              }}
              className={`min-h-11 shrink-0 rounded-lg border px-3 text-sm ${group === item.id ? "border-ok text-ok" : "border-border text-muted"}`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {visible.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={kind === item.id}
              onClick={() => setKind(item.id)}
              className={`rounded-3xl border p-4 text-left ${kind === item.id ? "border-ok bg-bg-elevated" : "border-border bg-bg-elevated"}`}
            >
              <p className="font-mono text-xs text-faint">{item.groupLabel}</p>
              <p className="mt-1 text-sm">{item.name}</p>
              <p className="mt-2 font-mono text-lg text-ok">{item.canvas}</p>
              <p className="mt-1 text-sm text-muted">{item.formats}</p>
              <p className="mt-2 font-mono text-xs text-muted">Min {sizeWindow(item).min}</p>
              <p className="font-mono text-xs text-muted">Max {sizeWindow(item).max}</p>
            </button>
          ))}
        </div>
      </section>

      <section className="grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4">
        <div>
          <p className="font-mono text-xs text-faint">{spec.groupLabel}</p>
          <h2 className="mt-1 text-base font-medium">{spec.name}</h2>
          <p className="mt-2 font-mono text-2xl text-ok">{spec.canvas}</p>
          <p className="mt-1 text-sm text-muted">
            {spec.formats}. {spec.limit}.
          </p>
        </div>
        <CanvasMark spec={spec} />
        {spec.slots.length === 1 && spec.slots[0].minWidth !== spec.slots[0].maxWidth ? (
          <p className="text-sm text-muted">Outer line is the maximum. Inner line is the minimum.</p>
        ) : null}
        <dl className="grid gap-3 text-sm sm:grid-cols-2">
          <div>
            <dt className="text-muted">Where it shows</dt>
            <dd className="mt-1">{spec.where}</dd>
          </div>
          <div>
            <dt className="text-muted">Minimum</dt>
            <dd className="mt-1">{bounds.min}</dd>
          </div>
          <div>
            <dt className="text-muted">Maximum</dt>
            <dd className="mt-1">{bounds.max}</dd>
          </div>
          <div>
            <dt className="text-muted">How to make it</dt>
            <dd className="mt-1">{spec.make}</dd>
          </div>
          <div>
            <dt className="text-muted">Do not</dt>
            <dd className="mt-1">{spec.avoid}</dd>
          </div>
        </dl>
      </section>

      {standing.business ? (
        <form
          className="grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4"
          onSubmit={(event) => {
            event.preventDefault();
            create();
          }}
        >
          <h2 className="text-sm font-medium">List this {spec.name.toLowerCase()}</h2>
          <p className="text-sm text-muted">
            {standing.businessName} lists at {fee.label}.{" "}
            {spec.slots.length > 0
              ? "The file has to land between the minimum and the maximum. KOBA does not rescale."
              : "This type has no image. Put two hex colors in the detail."}{" "}
            {standing.verified ? "The blue badge is already on this account." : "This business is unverified, so the higher fee applies."}
          </p>
          {spec.slots.length === 0 ? null : spec.slots.length === 1 ? (
            <label className="grid gap-1">
              <span className="font-mono text-xs text-faint">{spec.maxCount > 1 ? `Upload ${spec.minCount} to ${spec.maxCount} files` : "Upload"}</span>
              <input
                key={`${kind}-${fileEpoch}`}
                type="file"
                accept={spec.slots[0].accept}
                multiple={spec.maxCount > 1}
                aria-label={spec.maxCount > 1 ? "Upload sticker files" : "Upload cosmetic file"}
                onChange={(event) => {
                  const list = event.target.files;
                  if (!list?.length) return;
                  void ingest(Array.from(list), null);
                }}
                className="block w-full text-sm file:mr-3 file:h-11 file:rounded-lg file:border file:border-border file:bg-bg file:px-3 file:text-sm file:text-fg"
              />
            </label>
          ) : (
            spec.slots.map((slot, index) => (
              <label key={slot.id} className="grid gap-1">
                <span className="font-mono text-xs text-faint">
                  {slot.label} · min {slot.minWidth}×{slot.minHeight} · max {slot.maxWidth}×{slot.maxHeight}
                </span>
                <input
                  key={`${kind}-${slot.id}-${fileEpoch}`}
                  type="file"
                  accept={slot.accept}
                  aria-label={`Upload ${slot.label}`}
                  onChange={(event) => {
                    const list = event.target.files;
                    if (!list?.length) return;
                    void ingest([list[0]], index);
                  }}
                  className="block w-full text-sm file:mr-3 file:h-11 file:rounded-lg file:border file:border-border file:bg-bg file:px-3 file:text-sm file:text-fg"
                />
              </label>
            ))
          )}
          {busy ? <p className="text-sm text-muted">Checking size…</p> : null}
          {uploads.map((row, index) => (
            <p key={`${row.name}-${index}`} className="flex items-center gap-3 text-sm text-muted">
              {row.preview ? <img src={row.preview} alt="" className="h-11 w-11 rounded-lg border border-border object-contain" /> : null}
              <span>
                {row.name} · {row.width && row.height ? `${row.width} × ${row.height}` : "audio"} · {formatBytes(row.bytes)}
                {row.seconds != null ? ` · ${row.seconds.toFixed(1)} s` : ""}
              </span>
            </p>
          ))}
          {!busy && uploads.length > 0 && liveIssue ? <p className="text-sm text-danger">{liveIssue}</p> : null}
          {!busy && uploads.length > 0 && !liveIssue ? <p className="text-sm text-ok">In range.</p> : null}
          <label className="grid gap-1">
            <span className="font-mono text-xs text-faint">Title</span>
            <input value={title} onChange={(event) => setTitle(event.target.value)} className="h-11 rounded-lg border border-border bg-bg px-3 text-sm" />
          </label>
          <label className="grid gap-1">
            <span className="font-mono text-xs text-faint">Detail</span>
            <input value={detail} onChange={(event) => setDetail(event.target.value)} className="h-11 rounded-lg border border-border bg-bg px-3 text-sm" />
          </label>
          <label className="grid gap-1">
            <span className="font-mono text-xs text-faint">Price in coins</span>
            <input value={price} onChange={(event) => setPrice(event.target.value)} inputMode="numeric" className="h-11 rounded-lg border border-border bg-bg px-3 text-sm" />
          </label>
          {preview ? (
            <p className="text-sm text-muted">
              Buyer pays {formatCoins(priceNumber)}. You receive {formatCoins(preview.payout)}. Astro keeps {formatCoins(preview.fee)} ({preview.label}).
            </p>
          ) : (
            <p className="text-sm text-muted">Enter a price to see the fee.</p>
          )}
          {formError ? <p className="text-sm text-danger">{formError}</p> : null}
          <Button type="submit" variant="primary" className="w-full sm:w-auto">
            List on the Official shop
          </Button>
        </form>
      ) : (
        <form
          className="grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4"
          onSubmit={(event) => {
            event.preventDefault();
            openBusiness();
          }}
        >
          <h2 className="text-sm font-medium">Open a business account</h2>
          <p className="text-sm text-muted">
            {viewer.name.split(" ")[0]} is {standing.verified ? "verified" : "unverified"} and not a business yet. Players can buy. Only a business can create products. Your fee stays {fee.label}.
          </p>
          <label className="grid gap-1">
            <span className="font-mono text-xs text-faint">Business name</span>
            <input value={businessName} onChange={(event) => setBusinessName(event.target.value)} className="h-11 rounded-lg border border-border bg-bg px-3 text-sm" />
          </label>
          {businessError ? <p className="text-sm text-danger">{businessError}</p> : null}
          <Button type="submit" variant="primary" className="w-full sm:w-auto">
            Open business account
          </Button>
        </form>
      )}

      <section className="grid gap-3">
        <h2 className="text-sm font-medium">KOBA Official shop</h2>
        {products.map((product) => {
          const seller = identities.find((identity) => identity.id === product.sellerId);
          const sellerAccount = accountFor(product.sellerId, opened);
          const sale = quote(product.price, sellerAccount.verified);
          const own = product.sellerId === viewer.id;
          const short = viewer.coins < product.price;
          const listed = specFor(product.kind);
          const has = owned.includes(product.id);
          const applied = equipped === product.id;
          const cosmetic = product.kind !== "sticker-pack";
          return (
            <article key={product.id} className="rounded-3xl border border-border bg-bg-elevated p-4">
              <MotionPreview motion={product.motion} title={product.title} />
              <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-xs text-faint">
                    {listed.name} · {listed.canvas}
                  </p>
                  <h3 className="mt-1 text-base font-medium">{product.title}</h3>
                  <p className="mt-1 max-w-xl text-sm text-muted">{product.detail}</p>
                  <p className="mt-2 text-sm text-muted">
                    Minimum {sizeWindow(listed).min}. Maximum {sizeWindow(listed).max}.
                  </p>
                  {product.files?.length ? (
                    <ul className="mt-2 grid gap-1">
                      {product.files.map((file, index) => (
                        <li key={`${file.name}-${index}`} className="font-mono text-xs text-muted">
                          Uploaded {file.name}
                          {file.width && file.height ? ` · ${file.width} × ${file.height}` : " · audio"} · {formatBytes(file.bytes)}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
                <p className="font-mono text-sm tabular-nums">{formatCoins(product.price)} coins</p>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <button type="button" onClick={() => seller && onOpenPlayer(seller.id)} className="min-h-11 text-sm text-cyan">
                  {sellerAccount.businessName ?? seller?.name ?? "Seller"}
                </button>
                <VerifiedMark verified={sellerAccount.verified} />
              </div>
              <p className="mt-2 text-sm text-muted">
                You pay {formatCoins(product.price)}. Seller receives {formatCoins(sale.payout)}. Astro fee {sale.label} ({formatCoins(sale.fee)}).
              </p>
              <div className="mt-3">
                {own ? <p className="text-sm text-muted">This is your listing. Someone else buys it.</p> : null}
                {!own && short ? <p className="text-sm text-muted">You need {formatCoins(product.price - viewer.coins)} more coins.</p> : null}
                <Button
                  variant="primary"
                  className="mt-2"
                  disabled={own || short}
                  onClick={() => {
                    const error = onBuy(product, sellerAccount);
                    if (error) {
                      setResult(error);
                      return;
                    }
                    setResult(`Bought ${product.title}. You paid ${formatCoins(product.price)}.`);
                    setFlash((value) => value + 1);
                  }}
                >
                  Buy
                </Button>
                {cosmetic && has ? (
                  <Button
                    className="mt-2 ml-2"
                    disabled={!subscribed || applied}
                    onClick={() => {
                      const ok = onEquip(product.id);
                      setResult(ok ? `${product.title} is applied.` : `Start Astro (${ASTRO_PRICE}) before applying cosmetics.`);
                      if (ok) setFlash((value) => value + 1);
                    }}
                  >
                    {applied ? "Applied" : "Apply"}
                  </Button>
                ) : null}
                {has && !cosmetic ? <p className="mt-2 text-sm text-muted">This pack is in your stickers. Send them from DMs.</p> : null}
              </div>
            </article>
          );
        })}
      </section>
    </div>
  );
}
