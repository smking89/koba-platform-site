import { useMemo } from "react";
import type { Identity } from "@/platform/engine";
import { accountFor } from "@/site/astro";
import { resolveBadges, sourceFor, type BadgeResult } from "@/site/badges";
import { metaFor } from "@/site/catalog";
import { useCommunity } from "@/site/community";
import { useSite } from "@/site/ui";

export function useResolvedBadges(identities: Identity[]): Record<string, BadgeResult> {
  const opened = useSite((s) => s.opened);
  const astroPass = useCommunity((s) => s.astroPass);
  const groups = useCommunity((s) => s.groups);
  const members = useCommunity((s) => s.members);
  const roles = useCommunity((s) => s.roles);

  return useMemo(() => {
    const out: Record<string, BadgeResult> = {};
    for (const identity of identities) {
      const membership = members.filter((member) => member.identityId === identity.id);
      const groupId = membership[0]?.groupId;
      const groupMembers = groupId ? members.filter((member) => member.groupId === groupId).length : 0;
      const ownsGroup = groups.some((group) => group.ownerId === identity.id);
      const officer = membership.some((member) => {
        const role = roles.find((item) => item.id === member.roleId);
        return Boolean(role && role.rank >= 2 && role.name !== "Owner");
      });
      const marks = metaFor(identity.id, identity.score).achievements;
      out[identity.id] = resolveBadges(
        sourceFor(identity, accountFor(identity.id, opened), { subscribed: astroPass.includes(identity.id), ownsGroup, officer, groupId, groupMembers }, marks),
      );
    }
    return out;
  }, [astroPass, groups, identities, members, opened, roles]);
}
