import { useState } from "react";
import { Search } from "lucide-react";
import { Button, Chip } from "@/components/ui";
import { ServerFace } from "@/components/network/shared";
import type { Identity } from "@/platform/engine";
import { LFG, LISTINGS, PARTIES, WIPE_EVENTS, metaFor, wipeFor, type GameId, type PlayStyle, type Region } from "@/site/catalog";
import { SUPPORTED_GAMES } from "@/site/games";

const GAMES: { id: GameId; label: string }[] = [
  { id: "all", label: "All games" },
  { id: "rust", label: "Rust Console" },
  { id: "dayz", label: "DayZ" },
];

const REGIONS: { id: "all" | Region; label: string }[] = [
  { id: "all", label: "All regions" },
  { id: "NA", label: "NA" },
  { id: "EU", label: "EU" },
  { id: "OCE", label: "OCE" },
];

const STYLES: { id: "all" | PlayStyle; label: string }[] = [
  { id: "all", label: "Any style" },
  { id: "Survival", label: "Survival" },
  { id: "Tactical", label: "Tactical" },
  { id: "Social", label: "Social" },
  { id: "Hardcore", label: "Hardcore" },
];

export function DiscoverPage({
  identities,
  query,
  game,
  region,
  style,
  saved,
  onQuery,
  onGame,
  onRegion,
  onStyle,
  onSave,
  onOpenPlayer,
}: {
  identities: Identity[];
  query: string;
  game: GameId;
  region: "all" | Region;
  style: "all" | PlayStyle;
  saved: string[];
  onQuery: (value: string) => void;
  onGame: (value: GameId) => void;
  onRegion: (value: "all" | Region) => void;
  onStyle: (value: "all" | PlayStyle) => void;
  onSave: (id: string) => void;
  onOpenPlayer: (id: string) => void;
}) {
  const [openId, setOpenId] = useState<string | null>(LISTINGS[0]?.id ?? null);
  const [joined, setJoined] = useState<string[]>([]);
  const [mic, setMic] = useState<"on" | "off">("on");
  const [partySize, setPartySize] = useState("3");
  const [hours, setHours] = useState<"night" | "day">("night");
  const needle = query.trim().toLowerCase();
  const listings = LISTINGS.filter((listing) => {
    if (game !== "all" && listing.gameId !== game) return false;
    if (region !== "all" && listing.region !== region) return false;
    if (style !== "all" && listing.style !== style) return false;
    if (!needle) return true;
    return `${listing.name} ${listing.tags.join(" ")} ${listing.blurb}`.toLowerCase().includes(needle);
  });
  const people = identities.filter((identity) => {
    if (region !== "all" && metaFor(identity.id, identity.score).region !== region) return false;
    if (!needle) return true;
    return identity.name.toLowerCase().includes(needle) || identity.handle.includes(needle);
  });
  const posts = LFG.filter((post) => listings.some((listing) => listing.id === post.listingId));
  const parties = PARTIES.filter((party) => {
    if (game !== "all" && party.gameId !== game) return false;
    if (region !== "all" && party.region !== region) return false;
    if (party.mic !== mic) return false;
    if (party.size > Number(partySize)) return false;
    if (party.hours !== hours) return false;
    return true;
  }).slice(0, 3);

  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-medium tracking-tight">Discover</h1>
        <p className="mt-1 max-w-xl text-sm text-muted">Servers, players, and groups looking for one more. Filters stay put while you browse.</p>
      </div>

      <label className="flex h-11 items-center gap-2 rounded-full bg-bg-subtle px-3">
        <Search size={16} className="shrink-0 text-muted" aria-hidden />
        <input
          value={query}
          onChange={(event) => onQuery(event.target.value)}
          placeholder="Server, tag, or player"
          aria-label="Search"
          className="h-11 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-faint"
        />
      </label>

      <FilterRow label="Game" options={GAMES} value={game} onChange={onGame} />
      <FilterRow label="Region" options={REGIONS} value={region} onChange={onRegion} />
      <div className="hidden lg:block">
        <FilterRow label="Style" options={STYLES} value={style} onChange={onStyle} />
      </div>

      <section className="hidden rounded-3xl border border-border bg-bg-elevated p-4 lg:block">
        <h2 className="text-sm font-medium">Squad match</h2>
        <p className="mt-1 text-sm text-muted">Three open parties that fit the game, region, mic, hours, and group size.</p>
        <div className="mt-3 flex gap-2 overflow-x-auto">
          <Choice label="Mic on" on={mic === "on"} onClick={() => setMic("on")} />
          <Choice label="Mic off" on={mic === "off"} onClick={() => setMic("off")} />
          <Choice label="Night" on={hours === "night"} onClick={() => setHours("night")} />
          <Choice label="Day" on={hours === "day"} onClick={() => setHours("day")} />
          {["2", "3", "4"].map((size) => (
            <Choice key={size} label={`${size} max`} on={partySize === size} onClick={() => setPartySize(size)} />
          ))}
        </div>
        <ul className="mt-3 grid gap-2 sm:grid-cols-3">
          {parties.length === 0 ? <li className="text-sm text-muted">No party fits that read.</li> : null}
          {parties.map((party) => {
            const where = LISTINGS.find((listing) => listing.id === party.listingId);
            return (
              <li key={party.id} className="rounded-2xl bg-bg p-3">
                <p className="text-sm">{party.name}</p>
                <p className="mt-1 font-mono text-xs text-ok">
                  {party.filled}/{party.size} ready
                </p>
                <p className="mt-1 text-sm text-muted">
                  {where?.name} · {party.region} · {party.hours}
                </p>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="grid gap-2">
        <h2 className="font-mono text-xs tracking-widest text-faint uppercase">Wipe night</h2>
        <ul className="grid gap-2 md:grid-cols-3">
          {WIPE_EVENTS.map((event) => {
            const where = LISTINGS.find((listing) => listing.id === event.listingId);
            const inEvent = joined.includes(event.id);
            const count = event.filled + (inEvent ? 1 : 0);
            return (
              <li key={event.id} className="rounded-3xl border border-border bg-bg-elevated p-4">
                <p className="text-sm">{event.title}</p>
                <p className="mt-1 text-sm text-muted">
                  {event.when} · {where?.name}
                </p>
                <p className="mt-2 font-mono text-xs text-ok">
                  {count}/{event.cap}
                </p>
                <Button variant={inEvent ? "ghost" : "primary"} className="mt-3 w-full" onClick={() => setJoined((current) => (current.includes(event.id) ? current.filter((id) => id !== event.id) : [...current, event.id]))}>
                  {inEvent ? "Leave event" : "Join"}
                </Button>
              </li>
            );
          })}
        </ul>
      </section>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <div className="grid gap-3">
          {listings.length === 0 ? <p className="text-sm text-muted">No server matches those filters.</p> : null}
          {listings.map((listing) => {
            const open = openId === listing.id;
            const kept = saved.includes(listing.id);
            return (
              <article key={listing.id} className={`card-lift rounded-3xl border bg-bg-elevated p-3 ${open ? "border-cyan" : "border-border"}`}>
                <button type="button" onClick={() => setOpenId(open ? null : listing.id)} className="w-full text-left">
                  <ServerFace listing={listing} />
                  <div className="mt-3 flex items-baseline justify-between gap-3">
                    <p className="text-sm">{listing.name}</p>
                    <span className="font-mono text-xs tabular-nums text-ok">
                      {listing.players}/{listing.cap} online
                    </span>
                  </div>
                  <p className="mt-1 font-mono text-xs text-muted">
                    Wiped {wipeFor(listing.id).wiped} · next {wipeFor(listing.id).next} · groups {wipeFor(listing.id).groups} · {wipeFor(listing.id).gather}
                  </p>
                  <p className="mt-1 text-sm text-muted">
                    {listing.platform} · {listing.style} · {listing.rating}
                  </p>
                </button>
                {open ? (
                  <div className="mt-3 grid gap-3">
                    <p className="text-sm text-muted">{listing.blurb}</p>
                    <div className="flex flex-wrap gap-2">
                      {listing.tags.map((tag) => (
                        <Chip key={tag}>{tag}</Chip>
                      ))}
                    </div>
                    <Button variant={kept ? "primary" : "ghost"} onClick={() => onSave(listing.id)}>
                      {kept ? "Saved" : "Save listing"}
                    </Button>
                  </div>
                ) : null}
              </article>
            );
          })}
        </div>

        <div className="grid content-start gap-4">
          <section className="rounded-3xl border border-border bg-bg-elevated p-4">
            <h2 className="text-sm font-medium">Looking for group</h2>
            <ul className="mt-2 grid">
              {posts.map((post) => {
                const who = identities.find((identity) => identity.id === post.identityId);
                const where = LISTINGS.find((listing) => listing.id === post.listingId);
                if (!who || !where) return null;
                return (
                  <li key={post.id} className="border-b border-border py-3 last:border-b-0">
                    <button type="button" onClick={() => onOpenPlayer(who.id)} className="min-h-11 text-left">
                      <p className="text-sm">{who.name}</p>
                      <p className="mt-1 text-sm text-muted">{post.need}</p>
                      <p className="mt-1 font-mono text-xs text-cyan">{where.name}</p>
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
          <section className="rounded-3xl border border-border bg-bg-elevated p-4">
            <h2 className="text-sm font-medium">Players</h2>
            <ul className="mt-2 grid">
              {people.map((identity) => (
                <li key={identity.id} className="border-b border-border last:border-b-0">
                  <button type="button" onClick={() => onOpenPlayer(identity.id)} className="flex min-h-11 w-full items-baseline justify-between gap-3 text-left">
                    <span>
                      <span className="block text-sm">{identity.name}</span>
                      <span className="font-mono text-xs text-faint">{metaFor(identity.id, identity.score).region}</span>
                    </span>
                    <span className="font-mono text-xs tabular-nums">{identity.score}</span>
                  </button>
                </li>
              ))}
              {people.length === 0 ? <li className="py-2 text-sm text-muted">No players in that region.</li> : null}
            </ul>
          </section>
        </div>
      </div>
      <p className="text-sm text-muted lg:hidden">KOBA connects {SUPPORTED_GAMES.length} titles across PC, console, mobile, and web. The full list is on a computer.</p>
      <section className="hidden border border-border lg:block">
        <h2 className="border-b border-border px-3 py-2 text-sm">Supported titles</h2>
        <ul>
          {SUPPORTED_GAMES.map((game) => (
            <li key={game.id} className="grid grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_7rem_5rem] gap-3 border-b border-border px-3 py-2 text-sm last:border-b-0">
              <span>{game.name}</span>
              <span className="text-muted">{game.devices.join(" · ")}</span>
              <span className="text-muted">{game.connector}</span>
              <span>{game.reach}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function Choice({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick} className={`min-h-11 shrink-0 rounded-full px-3 text-sm ${on ? "fire-btn" : "bg-bg text-muted"}`}>
      {label}
    </button>
  );
}

export function ClipRow() {
  return null;
}

function FilterRow<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { id: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
}) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto">
      <span className="shrink-0 font-mono text-xs text-faint">{label}</span>
      {options.map((option) => {
        const on = option.id === value;
        return (
          <button
            key={option.id}
            type="button"
            aria-pressed={on}
            onClick={() => onChange(option.id)}
            className={`min-h-11 shrink-0 rounded-lg border px-3 text-sm ${on ? "border-fg bg-fg text-bg" : "border-border text-muted"}`}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
