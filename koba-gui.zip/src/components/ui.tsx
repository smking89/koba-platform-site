import { cn } from "@/lib/cn";
import { ChevronDown } from "lucide-react";
import { useEffect, useRef, useState, type ButtonHTMLAttributes, type ReactNode } from "react";

export function Button({
  variant = "ghost",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "quiet" }) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-4 text-sm font-medium transition-[opacity,transform] duration-150 ease-out active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-40 disabled:active:scale-100",
        variant === "primary" && "fire-btn",
        variant === "ghost" && "border border-border bg-bg-subtle text-fg hover:bg-bg-elevated",
        variant === "quiet" && "text-muted hover:text-fg",
        className,
      )}
      {...props}
    />
  );
}

export function Chip({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "warn" | "danger" | "ok" | "cyan";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-1 font-mono text-xs",
        tone === "neutral" && "border-border text-muted",
        tone === "warn" && "border-warn/40 text-warn",
        tone === "danger" && "border-danger/40 text-danger",
        tone === "ok" && "border-ok/40 text-ok",
        tone === "cyan" && "border-cyan/40 text-cyan",
      )}
    >
      {children}
    </span>
  );
}

export function MenuSelect({
  label,
  value,
  options,
  onChange,
  ariaLabel,
  placeholder = "Choose",
  className,
}: {
  label?: string;
  value: string;
  options: { value: string; label: string; hint?: string }[];
  onChange: (value: string) => void;
  ariaLabel: string;
  placeholder?: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const current = options.find((option) => option.value === value);

  useEffect(() => {
    if (!open) return;
    const onPointer = (event: Event) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div className={cn("relative", className)} ref={root} data-noswipe>
      {label ? <span className="mb-1 block text-xs text-muted">{label}</span> : null}
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={ariaLabel}
        onClick={() => setOpen((next) => !next)}
        className="flex h-11 w-full items-center justify-between gap-2 rounded-2xl border border-border bg-bg-subtle px-3 text-left text-sm"
      >
        <span className="truncate">{current?.label ?? placeholder}</span>
        <ChevronDown size={16} aria-hidden className={cn("shrink-0 text-muted transition-transform", open && "rotate-180")} />
      </button>
      {open ? (
        <ul role="listbox" className="menu-pop absolute z-40 mt-2 max-h-64 w-full min-w-44 overflow-y-auto rounded-2xl border border-border bg-bg-elevated p-1">
          {options.map((option) => {
            const on = option.value === value;
            return (
              <li key={option.value}>
                <button
                  type="button"
                  role="option"
                  aria-selected={on}
                  onClick={() => {
                    onChange(option.value);
                    setOpen(false);
                  }}
                  className={cn(
                    "flex min-h-11 w-full items-center justify-between gap-3 rounded-xl px-3 text-left text-sm",
                    on ? "bg-violet/25 text-fg" : "text-muted hover:bg-bg-subtle hover:text-fg",
                  )}
                >
                  <span className="truncate">{option.label}</span>
                  {option.hint ? <span className="shrink-0 font-mono text-xs text-faint">{option.hint}</span> : null}
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}

export function Meter({ label, value }: { label: string; value: number }) {
  const width = `${Math.round(Math.max(0, Math.min(1, value)) * 100)}%`;
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3 font-mono text-xs">
        <span className="text-muted">{label}</span>
        <span className="tabular-nums text-fg">{value.toFixed(2)}</span>
      </div>
      <div className="mt-1 h-1 overflow-hidden rounded-sm bg-bg-subtle">
        <div className="h-1 bg-fg" style={{ width }} />
      </div>
    </div>
  );
}

export function Panel({
  title,
  children,
  action,
}: {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <section className="rounded-3xl border border-border bg-bg-elevated p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-sm font-medium">{title}</h2>
        {action}
      </div>
      <div className="mt-3">{children}</div>
    </section>
  );
}

export function Mono({ children }: { children: ReactNode }) {
  return <span className="font-mono text-xs text-muted tabular-nums">{children}</span>;
}
