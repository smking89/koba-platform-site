import { useEffect, useRef, useState, type ReactNode } from "react";
import { Bell, ChevronDown, Home, MessageSquare, Search, Store, UserRound, Users } from "lucide-react";
import { CompetePage } from "@/components/network/compete";
import { DiscoverPage } from "@/components/network/discover";
import { DeskPage } from "@/components/network/desks";
import { GroupsPage } from "@/components/network/groups";
import { HomePage } from "@/components/network/home";
import { MessagesPage } from "@/components/network/messages";
import { ProfilePage } from "@/components/network/profile";
import { RankingsPage } from "@/components/network/rankings";
import { ShopPage } from "@/components/network/shop";
import { SocialPage } from "@/components/network/social";
import { StoriesPage } from "@/components/network/stories";
import { PlayerFace } from "@/components/network/shared";
import { BadgeRow } from "@/components/network/badges";
import { useResolvedBadges } from "@/components/network/badge-state";
import { usePlatform } from "@/platform/store";
import type { Identity } from "@/platform/engine";
import { accountFor, formatCoins, quote } from "@/site/astro";
import { LISTINGS } from "@/site/catalog";
import { useCommunity } from "@/site/community";
import { useSite, type Desk, type HomeTab, type SitePage } from "@/site/ui";
import { SiteFooter } from "@/components/site-footer";
import { AuthScreen, readAccount, saveAccount, type KobaAccount } from "@/components/network/auth-screen";

const NAV: { id: SitePage; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Home", icon: Home },
  { id: "groups", label: "Groups", icon: Users },
  { id: "messages", label: "DMs", icon: MessageSquare },
  { id: "shop", label: "Shop", icon: Store },
  { id: "profile", label: "Profile", icon: UserRound },
];

const TABS: { id: HomeTab; label: string }[] = [
  { id: "feed", label: "Feed" },
  { id: "discover", label: "Discover" },
  { id: "compete", label: "Compete" },
  { id: "rankings", label: "Rankings" },
  { id: "social", label: "Social" },
  { id: "stories", label: "Stories" },
];

export function PlatformApp() {
  const identities = usePlatform((s) => s.identities);
  const clans = usePlatform((s) => s.clans);
  const feed = usePlatform((s) => s.feed);
  const audit = usePlatform((s) => s.audit);
  const servers = usePlatform((s) => s.servers);
  const viewerId = usePlatform((s) => s.viewerId);
  const setViewer = usePlatform((s) => s.setViewer);
  const grants = usePlatform((s) => s.grants);
  const setRole = usePlatform((s) => s.setRole);
  const setHq = usePlatform((s) => s.setHq);
  const run = usePlatform((s) => s.run);
  const resetPlatform = usePlatform((s) => s.reset);
  const applySale = usePlatform((s) => s.applySale);

  const page = useSite((s) => s.page);
  const query = useSite((s) => s.query);
  const game = useSite((s) => s.game);
  const region = useSite((s) => s.region);
  const style = useSite((s) => s.style);
  const saved = useSite((s) => s.saved);
  const follows = useSite((s) => s.follows);
  const bounties = useSite((s) => s.bounties);
  const products = useSite((s) => s.products);
  const opened = useSite((s) => s.opened);
  const pulse = useSite((s) => s.pulse);
  const notice = useSite((s) => s.notice);
  const palette = useSite((s) => s.palette);
  const accountOpen = useSite((s) => s.accountOpen);
  const focusId = useSite((s) => s.focusId);
  const setPage = useSite((s) => s.setPage);
  const setQuery = useSite((s) => s.setQuery);
  const setGame = useSite((s) => s.setGame);
  const setRegion = useSite((s) => s.setRegion);
  const setStyle = useSite((s) => s.setStyle);
  const toggleSaved = useSite((s) => s.toggleSaved);
  const toggleFollow = useSite((s) => s.toggleFollow);
  const toggleBounty = useSite((s) => s.toggleBounty);
  const openBusiness = useSite((s) => s.openBusiness);
  const addProduct = useSite((s) => s.addProduct);
  const ping = useSite((s) => s.ping);
  const setPalette = useSite((s) => s.setPalette);
  const setAccountOpen = useSite((s) => s.setAccountOpen);
  const openProfile = useSite((s) => s.openProfile);
  const resetSite = useSite((s) => s.reset);
  const homeTab = useSite((s) => s.homeTab);
  const setHomeTab = useSite((s) => s.setHomeTab);
  const desk = useSite((s) => s.desk);
  const setDesk = useSite((s) => s.setDesk);
  const groups = useCommunity((s) => s.groups);

  const astroPass = useCommunity((s) => s.astroPass);
  const owned = useCommunity((s) => s.owned);
  const equipped = useCommunity((s) => s.equipped);
  const subscribe = useCommunity((s) => s.subscribe);
  const endPass = useCommunity((s) => s.endPass);
  const grantProduct = useCommunity((s) => s.grantProduct);
  const equip = useCommunity((s) => s.equip);
  const addStory = useCommunity((s) => s.addStory);
  const resetCommunity = useCommunity((s) => s.reset);
  const [session, setSession] = useState<KobaAccount | null>(null);

  const viewer = identities.find((identity) => identity.id === viewerId) ?? identities[0];
  const viewerAccount = viewer ? accountFor(viewer.id, opened) : null;
  const ranked = identities.slice().sort((a, b) => b.score - a.score);
  const rank = viewer ? ranked.findIndex((identity) => identity.id === viewer.id) + 1 : 1;
  const profile = identities.find((identity) => identity.id === (focusId ?? viewerId)) ?? viewer;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPalette(true);
      } else if (event.key === "Escape") {
        setPalette(false);
        setAccountOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setAccountOpen, setPalette]);

  useEffect(() => installTouchBridge(), []);

  useEffect(() => {
    setSession(readAccount());
  }, []);

  if (!session) {
    return (
      <AuthScreen
        onEnter={(next) => {
          saveAccount(next);
          setSession(next);
          setViewer(next.viewerId);
        }}
      />
    );
  }

  if (!viewer || !profile || !viewerAccount) return null;

  const roleGrant = grants[viewer.id] ?? "player";
  const staffDesk = roleGrant === "player" ? null : roleGrant;
  const staffOpen = staffDesk !== null && desk === staffDesk;
  const clanName = (id?: string) => clans.find((clan) => clan.id === id)?.name ?? "Unaffiliated";
  const applySeat = (next: Desk) => {
    if (next === "super") {
      setRole("developer");
      setHq(true);
    } else if (next === "mod" || next === "admin") {
      setRole("admin");
      setHq(false);
    } else {
      setRole("player");
      setHq(false);
    }
  };
  const enter = (next: Desk) => {
    setDesk(next);
    applySeat(next);
  };
  const go = (next: SitePage) => {
    applySeat("play");
    if (next === "profile") openProfile(viewer.id);
    else setPage(next);
  };

  const openTarget = (target: SitePage | HomeTab) => {
    if (target === "discover" || target === "compete" || target === "rankings" || target === "social" || target === "stories" || target === "feed") {
      applySeat("play");
      setHomeTab(target);
      return;
    }
    go(target);
  };

  const challenge = (handle: string) => {
    const embed = run(`/challenge ${handle}`);
    ping(embed.title, embed.description);
  };

  const declareWar = (name: string) => {
    const embed = run(`/war declare ${name}`);
    ping(embed.title, embed.description);
  };

  const standDown = () => {
    const embed = run("/war end");
    ping(embed.title, embed.description);
  };

  const reset = () => {
    resetPlatform();
    resetSite();
    resetCommunity();
  };

  return (
    <div className="min-h-dvh bg-bg text-fg xl:grid xl:grid-cols-[15rem_minmax(0,1fr)]">
      <aside className="hidden border-r border-border bg-bg-elevated/50 xl:flex xl:min-h-dvh xl:flex-col">
        <button type="button" onClick={() => go("home")} aria-label="KOBA home" className="px-4 pt-5">
          <img src="/brand/koba-wordmark.gif" alt="" width={435} height={226} className="h-16 w-full object-contain object-left" />
        </button>
        <p className="px-5 pt-2 text-sm text-muted">Your gaming network</p>
        <nav className="mt-6 grid gap-1 px-3" aria-label="Primary">
          {NAV.map((item) => {
            const on = desk === "play" && page === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                aria-current={on ? "page" : undefined}
                className={`flex min-h-12 items-center gap-3 rounded-2xl px-3 text-left text-sm ${on ? "nav-on" : "text-muted hover:bg-bg-subtle"}`}
              >
                <NavGlyph icon={Icon} on={on} />
                {item.label}
              </button>
            );
          })}
        </nav>
        {staffDesk ? (
          <button type="button" onClick={() => enter(staffDesk)} className="mx-3 mt-4 h-11 border border-border px-3 text-left text-sm">
            {staffDesk} desk
          </button>
        ) : null}
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-20 border-b border-border/80 bg-bg">
          <div className="mx-auto flex w-full max-w-7xl items-center gap-2 px-3 py-3 sm:gap-3 sm:px-4 lg:px-6">
            <button type="button" onClick={() => go("home")} aria-label="KOBA home" className="grid h-11 w-11 shrink-0 place-items-center xl:hidden">
              <img src="/brand/koba-mark.gif" alt="" width={264} height={264} className="h-9 w-9 object-contain" />
            </button>
            <button type="button" onClick={() => setPalette(true)} className="flex h-11 w-11 shrink-0 items-center justify-center text-muted sm:w-auto sm:flex-1 sm:justify-start sm:gap-2 sm:rounded-full sm:bg-bg-subtle sm:px-4" aria-label="Search">
              <Search size={16} aria-hidden />
              <span className="hidden truncate sm:inline">Search players, servers, pages</span>
              <span className="ml-auto hidden font-mono text-xs text-faint lg:inline">Ctrl K</span>
            </button>
            <button type="button" onClick={() => go("home")} className="relative grid h-11 w-11 shrink-0 place-items-center text-muted" aria-label="Activity">
              <Bell size={16} aria-hidden />
              {notice ? <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-ok" /> : null}
            </button>
            <AccountMenu
              viewer={viewer}
              identities={identities}
              opened={opened}
              open={accountOpen}
              onToggle={setAccountOpen}
              onPick={(id) => {
                setViewer(id);
                if (page === "profile") openProfile(id);
                setAccountOpen(false);
              }}
              onShop={() => {
                go("shop");
                setAccountOpen(false);
              }}
              onReset={() => {
                reset();
                setAccountOpen(false);
              }}
              session={session}
              onSignOut={() => {
                saveAccount(null);
                setSession(null);
                setAccountOpen(false);
              }}
            />
          </div>
          {notice ? (
            <p className="mx-auto w-full max-w-7xl px-4 pb-3 text-sm text-muted lg:px-6">
              <span className="text-fg">{notice.title}.</span> {notice.detail}
            </p>
          ) : null}
        </header>

        <main className="relative mx-auto w-full min-w-0 max-w-7xl px-3 py-4 pb-24 sm:px-4 lg:px-6 xl:pb-10">
          {staffOpen ? (
            <div className="hidden xl:block">
            <DeskPage
              desk={staffDesk ?? "admin"}
              viewer={viewer}
              identities={identities}
              groups={groups}
              servers={servers}
              feed={feed}
              audit={audit}
              products={products}
              opened={opened}
              account={viewerAccount}
              onAct={(line) => {
                const embed = run(line);
                ping(embed.title, embed.description);
                return embed;
              }}
              onOpenBusiness={(name) => {
                openBusiness(viewer.id, name);
                ping("Business opened", `${name} can list on the Official shop. Verification did not change.`);
              }}
              onOpenPlayer={(id) => {
                applySeat("play");
                openProfile(id);
              }}
              onShop={() => go("shop")}
              onReset={() => {
                reset();
              }}
            />
            </div>
          ) : null}
          <div className={staffOpen ? "xl:hidden" : ""}>
          {page === "home" ? (
            <HomeTabs tab={homeTab} onTab={setHomeTab}>
              {homeTab === "feed" ? (
                <HomePage
                  viewer={viewer}
                  identities={identities}
                  clans={clans}
                  rank={rank}
                  account={viewerAccount}
                  products={products}
                  pending={bounties.length}
                  pulse={pulse}
                  feed={feed}
                  onOpen={openTarget}
                  onOpenPlayer={openProfile}
                />
              ) : null}
              {homeTab === "discover" ? (
                <DiscoverPage
                  identities={identities}
                  query={query}
                  game={game}
                  region={region}
                  style={style}
                  saved={saved}
                  onQuery={setQuery}
                  onGame={setGame}
                  onRegion={setRegion}
                  onStyle={setStyle}
                  onSave={toggleSaved}
                  onOpenPlayer={openProfile}
                />
              ) : null}
              {homeTab === "compete" ? (
                <CompetePage
                  viewer={viewer}
                  identities={identities}
                  clans={clans}
                  bounties={bounties}
                  onChallenge={challenge}
                  onWar={declareWar}
                  onStandDown={standDown}
                  onBounty={(id) => {
                    const bounty = bounties.includes(id);
                    toggleBounty(id);
                    ping(bounty ? "Left bounty" : "Bounty entered", bounty ? "You stepped out." : "The entry is on this identity.");
                  }}
                />
              ) : null}
              {homeTab === "rankings" ? (
                <RankingsPage
                  identities={identities}
                  viewerId={viewer.id}
                  game={game}
                  region={region}
                  follows={follows}
                  clanIds={clans.find((clan) => clan.id === viewer.clanId)?.memberIds ?? []}
                  onGame={setGame}
                  onRegion={setRegion}
                  onOpen={openProfile}
                />
              ) : null}
              {homeTab === "social" ? (
                <SocialPage viewer={viewer} identities={identities} clans={clans} follows={follows} onFollow={toggleFollow} onOpen={openProfile} />
              ) : null}
              {homeTab === "stories" ? <StoriesPage viewer={viewer} identities={identities} /> : null}
            </HomeTabs>
          ) : null}
          {page === "groups" ? <GroupsPage viewer={viewer} identities={identities} /> : null}
          {page === "messages" ? (
            <MessagesPage
              viewer={viewer}
              identities={identities}
              onStory={(text, sticker) => {
                addStory(viewer.id, text, sticker);
                ping("Added to story", sticker ? `${sticker} is on your story.` : "The message is on your story.");
                setHomeTab("stories");
              }}
            />
          ) : null}
          {page === "shop" ? (
            <ShopPage
              key={viewer.id}
              viewer={viewer}
              identities={identities}
              products={products}
              opened={opened}
              subscribed={astroPass.includes(viewer.id)}
              owned={owned[viewer.id] ?? []}
              equipped={equipped[viewer.id] ?? null}
              onSubscribe={() => {
                subscribe(viewer.id);
                ping("Astro started", "150 coins land on the next renewal. One group can wear the animated banner.");
              }}
              onEndPass={() => {
                endPass(viewer.id);
                ping("Astro ended", "Applied cosmetics were cleared.");
              }}
              onEquip={(productId) => equip(viewer.id, productId)}
              onOpenBusiness={(name) => {
                openBusiness(viewer.id, name);
                ping("Business opened", `${name} can list on the Official shop. Verification did not change.`);
              }}
              onCreate={(draft) => {
                addProduct({ ...draft, sellerId: viewer.id, game: "Network" });
                const sale = quote(draft.price, viewerAccount.verified);
                ping("Product listed", `${draft.title} is on the Official shop at ${sale.label}.`);
              }}
              onBuy={(product, seller) => {
                const sale = quote(product.price, seller.verified);
                const sellerName = identities.find((identity) => identity.id === product.sellerId)?.name ?? "Seller";
                const done = applySale({
                  buyerId: viewer.id,
                  sellerId: product.sellerId,
                  price: product.price,
                  payout: sale.payout,
                  title: `${viewer.name} bought ${product.title}`,
                  detail: `${sellerName} received ${formatCoins(sale.payout)} after a ${sale.label} Astro fee.`,
                });
                if (!done.ok) {
                  ping("Purchase blocked", done.reason);
                  return done.reason;
                }
                grantProduct(
                  viewer.id,
                  product.id,
                  product.kind,
                  product.title,
                  product.files?.map((file) => file.name),
                );
                ping("Purchase complete", `You paid ${formatCoins(product.price)}. ${sellerName} received ${formatCoins(sale.payout)} after ${sale.label}.`);
                return null;
              }}
              onOpenPlayer={openProfile}
            />
          ) : null}
          {page === "profile" ? (
            <ProfilePage
              viewer={profile}
              account={accountFor(profile.id, opened)}
              rank={ranked.findIndex((identity) => identity.id === profile.id) + 1}
              clanName={clanName(profile.clanId)}
              followed={follows.includes(profile.id)}
              self={profile.id === viewer.id}
              subscribed={astroPass.includes(profile.id)}
              equippedName={(() => {
                const id = equipped[profile.id];
                return products.find((item) => item.id === id)?.title ?? null;
              })()}
              equippedMotion={(() => {
                const id = equipped[profile.id];
                return products.find((item) => item.id === id)?.motion ?? null;
              })()}
              onFollow={() => toggleFollow(profile.id)}
              onShop={() => go("shop")}
            />
          ) : null}
          </div>
          <SiteFooter className="hidden xl:block" />
        </main>
      </div>

      <nav className="dock fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-bg-elevated xl:hidden" aria-label="Primary">
        {NAV.map((item) => {
          const on = desk === "play" && page === item.id;
          const Icon = item.icon;
          return (
            <button key={item.id} type="button" onClick={() => go(item.id)} aria-current={on ? "page" : undefined} className={`flex min-h-14 min-w-0 flex-col items-center justify-center gap-1 px-1 text-xs ${on ? "text-fg" : "text-muted"}`}>
              <NavGlyph icon={Icon} on={on} />
              <span className="max-w-full truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {palette ? (
        <Palette
          identities={identities.map((identity) => ({ id: identity.id, name: identity.name, handle: identity.handle }))}
          onClose={() => setPalette(false)}
          onPage={openTarget}
          onPlayer={openProfile}
        />
      ) : null}
    </div>
  );
}

function AccountMenu({
  viewer,
  identities,
  opened,
  open,
  onToggle,
  onPick,
  onShop,
  onReset,
  session,
  onSignOut,
}: {
  viewer: Identity;
  identities: Identity[];
  opened: Record<string, string>;
  open: boolean;
  onToggle: (open: boolean) => void;
  onPick: (id: string) => void;
  onShop: () => void;
  onReset: () => void;
  session: KobaAccount;
  onSignOut: () => void;
}) {
  const root = useRef<HTMLDivElement>(null);
  const badgeMap = useResolvedBadges(identities);

  useEffect(() => {
    if (!open) return;
    const onPointer = (event: Event) => {
      if (!root.current?.contains(event.target as Node)) onToggle(false);
    };
    document.addEventListener("pointerdown", onPointer);
    return () => document.removeEventListener("pointerdown", onPointer);
  }, [open, onToggle]);

  return (
    <div className="relative" ref={root}>
      <button
        type="button"
        aria-expanded={open}
        aria-haspopup="menu"
        aria-label="Account menu"
        onClick={() => onToggle(!open)}
        className="flex h-11 items-center gap-2 rounded-full py-1 pr-2 pl-1 sm:pr-3"
      >
        <PlayerFace name={viewer.name} id={viewer.id} size="sm" />
        <span className="hidden max-w-28 truncate text-sm sm:inline">{viewer.name.split(" ")[0]}</span>
        <ChevronDown size={14} aria-hidden className={`text-muted transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open ? (
        <div role="menu" className="menu-pop absolute right-0 z-40 mt-2 w-72 max-w-[calc(100vw-1.5rem)] overflow-hidden rounded-3xl border border-border bg-bg-elevated">
          <p className="px-4 pt-3 font-mono text-xs tracking-widest text-faint uppercase">Play as</p>
          <p className="px-4 pb-1 text-xs text-muted">
            {session.name} · {session.provider}
            {session.email ? ` · ${session.email}` : ""}
          </p>
          <ul className="grid max-h-80 overflow-y-auto p-2">
            {identities.map((identity) => {
              const standing = accountFor(identity.id, opened);
              const on = identity.id === viewer.id;
              return (
                <li key={identity.id}>
                  <button
                    type="button"
                    role="menuitemradio"
                    aria-checked={on}
                    onClick={() => onPick(identity.id)}
                    className={`flex min-h-14 w-full items-center gap-3 rounded-2xl px-2 text-left ${on ? "bg-violet/25" : "hover:bg-bg-subtle"}`}
                  >
                    <PlayerFace name={identity.name} id={identity.id} size="sm" />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1">
                        <span className="truncate text-sm">{identity.name}</span>
                        <BadgeRow pins={(badgeMap[identity.id]?.earned ?? []).filter((pin) => pin.id === "verified")} size={14} />
                      </span>
                      <span className="block truncate text-xs text-muted">
                        {standing.verified ? "Verified" : "Unverified"} · {quote(100, standing.verified).label}
                        {standing.businessName ? ` · ${standing.businessName}` : ""}
                      </span>
                    </span>
                    <span className="font-mono text-xs text-cyan">{identity.score.toLocaleString("en-US")}</span>
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="grid border-t border-border p-2">
            <button type="button" role="menuitem" onClick={onShop} className="min-h-11 rounded-2xl px-3 text-left text-sm text-cyan hover:bg-bg-subtle">
              Official shop
            </button>
            <button type="button" role="menuitem" onClick={onReset} className="min-h-11 rounded-2xl px-3 text-left text-sm text-muted hover:bg-bg-subtle">
              Reset network
            </button>
            <button type="button" role="menuitem" onClick={onSignOut} className="min-h-11 rounded-2xl px-3 text-left text-sm text-muted hover:bg-bg-subtle">
              Sign out
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function NavGlyph({ icon: Icon, on }: { icon: typeof Home; on: boolean }) {
  return (
    <span className="nav-morph" aria-hidden>
      <Icon size={18} className={on ? "nav-glyph is-on" : "nav-glyph"} />
      <Icon size={18} fill="currentColor" className={on ? "nav-glyph nav-glyph-fill is-on" : "nav-glyph nav-glyph-fill"} />
    </span>
  );
}

function HomeTabs({ tab, onTab, children }: { tab: HomeTab; onTab: (tab: HomeTab) => void; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const [mark, setMark] = useState({ left: 0, top: 0, width: 0 });

  useEffect(() => {
    const list = listRef.current;
    if (!list) return;
    const place = () => {
      const active = list.querySelector<HTMLElement>('[aria-selected="true"]');
      if (!active) return;
      setMark({ left: active.offsetLeft, top: active.offsetTop + active.offsetHeight - 2, width: active.offsetWidth });
    };
    place();
    const observer = new ResizeObserver(place);
    observer.observe(list);
    return () => observer.disconnect();
  }, [tab]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("[data-noswipe], input, textarea, select, a, button")) {
        start.current = null;
        return;
      }
      start.current = { x: event.clientX, y: event.clientY };
    };
    const onPointerUp = (event: PointerEvent) => {
      if (!start.current) return;
      const dx = event.clientX - start.current.x;
      const dy = event.clientY - start.current.y;
      start.current = null;
      if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
      const index = TABS.findIndex((item) => item.id === tab);
      const next = TABS[index + (dx < 0 ? 1 : -1)];
      if (next) onTab(next.id);
    };
    el.addEventListener("pointerdown", onPointerDown);
    el.addEventListener("pointerup", onPointerUp);
    return () => {
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("pointerup", onPointerUp);
    };
  }, [onTab, tab]);

  return (
    <div ref={ref} className="touch-pan-y">
      <div ref={listRef} className="relative mb-3 flex gap-1 overflow-x-auto" data-noswipe role="tablist" aria-label="Home">
        <span className="tab-mark" style={{ left: mark.left, top: mark.top, width: mark.width, opacity: mark.width ? 1 : 0 }} />
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={tab === item.id}
            onClick={() => onTab(item.id)}
            className={`relative h-10 shrink-0 px-3 text-sm whitespace-nowrap ${tab === item.id ? "text-fg" : "text-muted"}`}
          >
            {item.label}
          </button>
        ))}
      </div>
      {children}
    </div>
  );
}

function installTouchBridge(): () => void {
  let origin: EventTarget | null = null;
  let startX = 0;
  let startY = 0;
  let armed = false;
  const controlOf = (target: EventTarget | null) => {
    if (!(target instanceof Element)) return null;
    if (target.closest("[data-badge]")) return null;
    const node = target.closest("button, a");
    if (!(node instanceof HTMLElement)) return null;
    if (node instanceof HTMLButtonElement && node.disabled) return null;
    return node;
  };
  const onDown = (event: PointerEvent) => {
    if (event.pointerType !== "touch" && event.pointerType !== "pen") {
      origin = null;
      return;
    }
    origin = event.target;
    startX = event.clientX;
    startY = event.clientY;
  };
  const onUp = (event: PointerEvent) => {
    if ((event.pointerType !== "touch" && event.pointerType !== "pen") || !origin) return;
    const from = controlOf(origin);
    origin = null;
    if (!from) return;
    if (Math.abs(event.clientX - startX) > 12 || Math.abs(event.clientY - startY) > 12) return;
    if (controlOf(event.target) !== from) return;
    armed = true;
    window.setTimeout(() => {
      armed = false;
    }, 500);
    from.click();
  };
  const onClick = (event: MouseEvent) => {
    if (!armed || !event.isTrusted) return;
    event.preventDefault();
    event.stopPropagation();
  };
  document.addEventListener("pointerdown", onDown, true);
  document.addEventListener("pointerup", onUp, true);
  document.addEventListener("click", onClick, true);
  return () => {
    document.removeEventListener("pointerdown", onDown, true);
    document.removeEventListener("pointerup", onUp, true);
    document.removeEventListener("click", onClick, true);
  };
}

function Palette({
  identities,
  onClose,
  onPage,
  onPlayer,
}: {
  identities: { id: string; name: string; handle: string }[];
  onClose: () => void;
  onPage: (page: SitePage | HomeTab) => void;
  onPlayer: (id: string) => void;
}) {
  const [q, setQ] = useState("");
  const needle = q.trim().toLowerCase();
  const pages = [...NAV, ...TABS.filter((item) => item.id !== "feed")].filter((item) => !needle || item.label.toLowerCase().includes(needle));
  const players = identities.filter((identity) => !needle || `${identity.name} ${identity.handle}`.toLowerCase().includes(needle));
  const servers = LISTINGS.filter((listing) => !needle || listing.name.toLowerCase().includes(needle)).slice(0, 6);

  return (
    <div className="fixed inset-0 z-40 grid content-start justify-center bg-bg/80 px-4 pt-16" role="dialog" aria-label="Search KOBA">
      <button type="button" className="absolute inset-0" aria-label="Close search" onClick={onClose} />
      <div className="relative z-10 max-h-[70dvh] w-full max-w-lg overflow-y-auto rounded-3xl border border-border bg-bg-elevated p-3">
        <label className="flex h-11 items-center gap-2 rounded-full bg-bg px-3">
          <Search size={16} className="shrink-0 text-muted" aria-hidden />
          <input
            autoFocus
            value={q}
            onChange={(event) => setQ(event.target.value)}
            placeholder="Players, servers, pages"
            aria-label="Search KOBA"
            className="h-11 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-faint"
          />
        </label>
        {pages.length ? <p className="px-2 pt-3 pb-1 font-mono text-xs text-faint">Pages</p> : null}
        <ul className="grid">
          {pages.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => {
                  onPage(item.id);
                  onClose();
                }}
                className="flex min-h-11 w-full items-center rounded-lg px-2 text-left text-sm hover:bg-bg-subtle"
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>
        {players.length ? <p className="px-2 pt-3 pb-1 font-mono text-xs text-faint">Players</p> : null}
        <ul className="grid">
          {players.map((identity) => (
            <li key={identity.id}>
              <button type="button" onClick={() => onPlayer(identity.id)} className="flex min-h-11 w-full items-center justify-between rounded-lg px-2 text-left text-sm hover:bg-bg-subtle">
                <span>{identity.name}</span>
                <span className="font-mono text-xs text-faint">{identity.handle}</span>
              </button>
            </li>
          ))}
        </ul>
        {servers.length ? <p className="px-2 pt-3 pb-1 font-mono text-xs text-faint">Servers</p> : null}
        <ul className="grid">
          {servers.map((listing) => (
            <li key={listing.id}>
              <button
                type="button"
                onClick={() => {
                  onPage("discover");
                  onClose();
                }}
                className="flex min-h-11 w-full items-center rounded-lg px-2 text-left text-sm hover:bg-bg-subtle"
              >
                {listing.name}
              </button>
            </li>
          ))}
        </ul>
        {pages.length + players.length + servers.length === 0 ? <p className="px-2 py-4 text-sm text-muted">Nothing matches.</p> : null}
      </div>
    </div>
  );
}
