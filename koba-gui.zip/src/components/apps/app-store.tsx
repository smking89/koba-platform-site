import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui";
import {
  dollars,
  GAME_LABEL,
  SEATS,
  TYPE_LABEL,
  type AppDraft,
  type AppListing,
  type AppType,
  type Billing,
  type GameId,
  type PublicApp,
  type Purchase,
  type Rarity,
  type StoreUser,
} from "@/site/app-store";

type Tab = "browse" | "purchases" | "develop" | "licensing";

const TABS: { id: Tab; to: "/apps" | "/apps/purchases" | "/apps/develop" | "/apps/licensing"; label: string }[] = [
  { id: "browse", to: "/apps", label: "Browse Apps" },
  { id: "purchases", to: "/apps/purchases", label: "My Purchases" },
  { id: "develop", to: "/apps/develop", label: "Submit listing" },
  { id: "licensing", to: "/apps/licensing", label: "Licensing" },
];

const TYPES: AppType[] = ["BOT", "PLUGIN", "ADAPTER"];
const GAMES: GameId[] = ["RUST", "DAYZ", "ARK", "MINECRAFT"];
const RARITIES: Rarity[] = ["COMMON", "UNCOMMON", "RARE", "EPIC", "LEGENDARY", "RELIC"];

interface Owned extends Purchase {
  app: PublicApp;
}

async function call<T>(path: string, kobaId: string, body?: unknown): Promise<T> {
  const response = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: { "content-type": "application/json", "x-koba-id": kobaId },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await response.json()) as T & { error?: string };
  if (!response.ok) throw new Error(data.error ?? "Request failed");
  return data;
}

export function AppStore({ tab }: { tab: Tab }) {
  const [kobaId, setKobaId] = useState(SEATS[0].kobaId);
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<StoreUser>(SEATS[0]);
  const [apps, setApps] = useState<PublicApp[]>([]);
  const [owned, setOwned] = useState<Owned[]>([]);
  const [queue, setQueue] = useState<AppListing[]>([]);
  const [type, setType] = useState<AppType | "">("");
  const [game, setGame] = useState<GameId | "">("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [shelf, setShelf] = useState<"featured" | "categories" | "charts" | "search">("featured");
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const stored = window.sessionStorage.getItem("koba-store-seat");
    if (stored && SEATS.some((seat) => seat.kobaId === stored)) setKobaId(stored);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    let cancel = false;
    window.sessionStorage.setItem("koba-store-seat", kobaId);
    const params = new URLSearchParams();
    if (type) params.set("type", type);
    if (game) params.set("game", game);
    Promise.all([
      call<{ apps: PublicApp[] }>(`/api/v1/apps/browse?${params.toString()}`, kobaId),
      call<{ user: StoreUser; purchases: Owned[]; queue: AppListing[] }>("/api/v1/apps/mine", kobaId),
    ])
      .then(([catalog, mine]) => {
        if (cancel) return;
        setApps(catalog.apps);
        setUser(mine.user);
        setOwned(mine.purchases);
        setQueue(mine.queue);
        setError("");
      })
      .catch((reason: unknown) => {
        if (!cancel) setError(reason instanceof Error ? reason.message : "The store did not answer.");
      });
    return () => {
      cancel = true;
    };
  }, [ready, kobaId, type, game, busy]);

  const run = async (path: string, body: unknown, done: string) => {
    setBusy(true);
    setError("");
    try {
      await call(path, kobaId, body);
      setNotice(done);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Request failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="border-b border-border">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
          <Link to="/" className="text-sm text-muted">
            KOBA
          </Link>
          <p className="text-sm">Catalog</p>
          <nav aria-label="App store" className="ml-auto hidden gap-4 lg:flex">
            {TABS.map((item) => (
              <Link key={item.id} to={item.to} aria-current={tab === item.id ? "page" : undefined} className={`text-sm ${tab === item.id ? "text-fg" : "text-muted"}`}>
                {item.label}
              </Link>
            ))}
          </nav>
          <label className="ml-auto hidden text-xs text-muted lg:ml-0 lg:grid">
            Seat
            <select value={kobaId} onChange={(event) => setKobaId(event.target.value)} className="h-9 border border-border bg-bg px-2 text-sm text-fg">
              {SEATS.map((seat) => (
                <option key={seat.kobaId} value={seat.kobaId}>
                  {seat.name}
                </option>
              ))}
            </select>
          </label>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-4 pb-28">
        {error ? <p className="mb-3 text-sm text-danger" role="alert">{error}</p> : null}
        {notice ? <p className="mb-3 text-sm">{notice}</p> : null}
        {tab === "browse" ? (
          <Browse
            apps={apps}
            owned={owned}
            shelf={shelf}
            query={query}
            picked={picked}
            type={type}
            game={game}
            busy={busy}
            onQuery={setQuery}
            onPick={setPicked}
            onType={setType}
            onGame={setGame}
            onBuy={(app) => run("/api/v1/apps/purchase", { appId: app.id }, `Licensed ${app.name}. Fee ${app.feeLabel}.`)}
          />
        ) : null}
        {tab === "purchases" ? <Purchases owned={owned} /> : null}
        {tab === "develop" ? (
          <>
            <p className="text-sm text-muted lg:hidden">Submitting a listing is a computer screen.</p>
            <div className="hidden lg:block">
              <Develop
                user={user}
                queue={queue}
                busy={busy}
                onSubmit={(draft) => run("/api/v1/apps/submit", draft, `${draft.name} is pending staff review.`)}
                onReview={(appId, decision) => run("/api/v1/apps/review", { appId, decision }, decision === "APPROVED" ? "Listing approved." : "Listing rejected.")}
              />
            </div>
          </>
        ) : null}
        {tab === "licensing" ? (
          <>
            <p className="text-sm text-muted lg:hidden">Download links are issued on a computer.</p>
            <div className="hidden lg:block">
              <Licensing kobaId={kobaId} owned={owned} />
            </div>
          </>
        ) : null}
      </main>
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-bg xl:hidden" aria-label="Catalog">
        {(
          [
            ["featured", "Featured"],
            ["categories", "Categories"],
            ["charts", "Charts"],
            ["search", "Search"],
          ] as const
        ).map(([id, label]) => (
          <Link key={id} to="/apps" onClick={() => setShelf(id)} className={`flex min-h-14 items-center justify-center text-xs ${tab === "browse" && shelf === id ? "text-fg" : "text-muted"}`}>
            {label}
          </Link>
        ))}
        <Link to="/apps/purchases" className={`flex min-h-14 items-center justify-center text-xs ${tab === "purchases" ? "text-fg" : "text-muted"}`}>
          Library
        </Link>
      </nav>
      <SiteFooter />
    </div>
  );
}

function scoreOf(app: PublicApp) {
  const tier: Record<PublicApp["rarityTier"], number> = { COMMON: 3.8, UNCOMMON: 4.1, RARE: 4.4, EPIC: 4.6, LEGENDARY: 4.8, RELIC: 4.9 };
  return tier[app.rarityTier].toFixed(1);
}

function Browse({
  apps,
  owned,
  shelf,
  query,
  picked,
  type,
  game,
  busy,
  onQuery,
  onPick,
  onType,
  onGame,
  onBuy,
}: {
  apps: PublicApp[];
  owned: Owned[];
  shelf: "featured" | "categories" | "charts" | "search";
  query: string;
  picked: string | null;
  type: AppType | "";
  game: GameId | "";
  busy: boolean;
  onQuery: (query: string) => void;
  onPick: (id: string | null) => void;
  onType: (type: AppType | "") => void;
  onGame: (game: GameId | "") => void;
  onBuy: (app: PublicApp) => void;
}) {
  const ownedIds = new Set(owned.filter((item) => item.isActive).map((item) => item.appId));
  const needle = query.trim().toLowerCase();
  let rows = apps.filter((app) => (shelf === "search" && needle ? `${app.name} ${app.developerName}`.toLowerCase().includes(needle) : true));
  if (shelf === "charts") rows = rows.slice().sort((a, b) => b.basePrice - a.basePrice);
  const open = apps.find((app) => app.id === picked) ?? null;
  return (
    <div className="grid gap-4">
      {shelf === "search" ? (
        <input value={query} onChange={(event) => onQuery(event.target.value)} placeholder="Search the catalog" className="h-11 w-full border border-border bg-bg px-3 text-sm" />
      ) : null}
      {shelf === "categories" ? (
        <div className="grid gap-2">
          <button type="button" onClick={() => onType("")} className={`min-h-11 border border-border px-3 text-left text-sm ${type === "" ? "bg-fg text-bg" : ""}`}>
            All listings
          </button>
          {TYPES.map((item) => (
            <button key={item} type="button" onClick={() => onType(item)} className={`min-h-11 border border-border px-3 text-left text-sm ${type === item ? "bg-fg text-bg" : ""}`}>
              {TYPE_LABEL[item]}
            </button>
          ))}
          <label className="hidden text-sm text-muted lg:grid">
            Game
            <select value={game} onChange={(event) => onGame(event.target.value as GameId | "")} className="h-11 border border-border bg-bg px-2 text-fg">
              <option value="">All titles</option>
              {GAMES.map((item) => (
                <option key={item} value={item}>
                  {GAME_LABEL[item]}
                </option>
              ))}
            </select>
          </label>
        </div>
      ) : null}
      <ul className="divide-y divide-border border-y border-border">
        {rows.map((app, index) => (
          <li key={app.id}>
            <div className="flex items-center gap-3 py-3">
              <button type="button" onClick={() => onPick(app.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                <span className="grid h-14 w-14 shrink-0 place-items-center border border-border text-xs">{app.name.slice(0, 2)}</span>
                <span className="min-w-0">
                  <span className="block truncate text-sm">{shelf === "charts" ? `${index + 1}  ${app.name}` : app.name}</span>
                  <span className="block truncate text-xs text-muted">{app.developerName}</span>
                  <span className="block text-xs text-faint">{scoreOf(app)}</span>
                </span>
              </button>
              <button type="button" disabled={busy || ownedIds.has(app.id)} onClick={() => onBuy(app)} className="min-h-8 shrink-0 border border-fg px-3 text-xs disabled:opacity-40">
                {ownedIds.has(app.id) ? "Owned" : "Get"}
              </button>
            </div>
          </li>
        ))}
      </ul>
      {rows.length === 0 ? <p className="text-sm text-muted">Nothing in this shelf.</p> : null}
      {open ? (
        <section className="border border-border p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-xl">{open.name}</h2>
              <p className="text-sm text-muted">{open.developerName}{open.developerVerified ? " · Verified" : ""}</p>
            </div>
            <button type="button" onClick={() => onPick(null)} className="text-sm text-muted">
              Close
            </button>
          </div>
          <div className="mt-4 flex gap-2 overflow-x-auto">
            <div className="grid h-36 w-28 shrink-0 place-items-end border border-border p-2 text-xs">{GAME_LABEL[open.game]}</div>
            <div className="grid h-36 w-28 shrink-0 place-items-end bg-fg p-2 text-xs text-bg">{open.rarityTier}</div>
          </div>
          <div className="mt-4 grid grid-cols-3 border border-border text-center text-sm">
            <p className="bg-fg py-2 text-bg">Details</p>
            <p className="py-2 text-muted">Reviews</p>
            <p className="py-2 text-muted">Related</p>
          </div>
          <p className="mt-3 text-sm text-muted">
            {TYPE_LABEL[open.type]}. {dollars(open.basePrice)}
            {open.billingModel === "SUBSCRIPTION" ? " each month" : " once"}. Platform fee {open.feeLabel}. Staff approved this listing before it could be fetched.
          </p>
          <p className="mt-2 text-sm text-muted">Rated {scoreOf(open)} from wipe-night use. Related listings stay in {TYPE_LABEL[open.type]}.</p>
        </section>
      ) : null}
    </div>
  );
}

function Purchases({ owned }: { owned: Owned[] }) {
  if (owned.length === 0) return <p className="text-sm text-muted">No licenses on this KOBAid yet. Browse the store to buy one.</p>;
  return (
    <ul className="grid gap-2">
      {owned.map((purchase) => (
        <li key={purchase.id} className="rounded-3xl border border-border bg-bg-elevated p-4">
          <p className="text-lg">{purchase.app.name}</p>
          <p className="mt-1 font-mono text-xs text-muted">License {purchase.licenseKey}</p>
          <p className="mt-1 text-sm text-muted">
            Paid {dollars(purchase.amountPaidTotal)}. Platform fee {dollars(purchase.platformFeeCharged)}. Developer received {dollars(purchase.developerPayout)}.
          </p>
          {purchase.subscriptionEnd ? <p className="text-sm text-muted">Renews through {new Date(purchase.subscriptionEnd).toLocaleDateString()}.</p> : null}
        </li>
      ))}
    </ul>
  );
}

function Develop({
  user,
  queue,
  busy,
  onSubmit,
  onReview,
}: {
  user: StoreUser;
  queue: AppListing[];
  busy: boolean;
  onSubmit: (draft: AppDraft) => void;
  onReview: (appId: string, decision: "APPROVED" | "REJECTED") => void;
}) {
  const [draft, setDraft] = useState<AppDraft>({ name: "", type: "PLUGIN", game: "RUST", rarityTier: "RARE", billingModel: "BUY_NOW", basePrice: 1000 });
  const staff = user.role === "STAFF";
  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <form
        className="grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit(draft);
        }}
      >
        <h1 className="text-2xl">Developer portal</h1>
        <p className="text-sm text-muted">KOBAbot stays closed. A listing here is a webhook and a license check. It does not run inside the bot. Staff must approve it before anyone can buy it. Verified developers pay 2.5%. Unverified pay 3.0%.</p>
        <label className="grid gap-1 text-sm">
          Name
          <input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} className="h-11 rounded-xl border border-border bg-bg px-3" />
        </label>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Type" value={draft.type} options={TYPES} labels={TYPE_LABEL} onChange={(type) => setDraft({ ...draft, type })} />
          <Field label="Game" value={draft.game} options={GAMES} labels={GAME_LABEL} onChange={(game) => setDraft({ ...draft, game })} />
          <Field label="Rarity" value={draft.rarityTier} options={RARITIES} onChange={(rarityTier) => setDraft({ ...draft, rarityTier })} />
          <Field label="Billing" value={draft.billingModel} options={["BUY_NOW", "SUBSCRIPTION"] as Billing[]} labels={{ BUY_NOW: "Buy now", SUBSCRIPTION: "Subscription" }} onChange={(billingModel) => setDraft({ ...draft, billingModel })} />
        </div>
        <label className="grid gap-1 text-sm">
          Price in cents
          <input value={draft.basePrice} onChange={(event) => setDraft({ ...draft, basePrice: Number(event.target.value) })} inputMode="numeric" className="h-11 rounded-xl border border-border bg-bg px-3" />
        </label>
        <Button variant="primary" type="submit" disabled={busy || user.role === "PLAYER"}>
          {user.role === "PLAYER" ? "Switch to a business seat" : "Submit for review"}
        </Button>
      </form>
      <section className="grid content-start gap-2">
        <h2 className="text-lg">{staff ? "Pending review" : "Your listings"}</h2>
        {queue.length === 0 ? <p className="text-sm text-muted">{staff ? "Nothing is waiting." : "You have not submitted a listing."}</p> : null}
        {queue.map((app) => (
          <article key={app.id} className="rounded-3xl border border-border bg-bg-elevated p-4">
            <p className="text-lg">{app.name}</p>
            <p className="text-sm text-muted">
              {app.developerName} · {app.status.replace("_", " ")} · {dollars(app.basePrice)}
            </p>
            {staff && app.status === "PENDING_REVIEW" ? (
              <div className="mt-3 flex gap-2">
                <Button variant="primary" disabled={busy} onClick={() => onReview(app.id, "APPROVED")}>
                  Approve
                </Button>
                <Button variant="ghost" disabled={busy} onClick={() => onReview(app.id, "REJECTED")}>
                  Reject
                </Button>
              </div>
            ) : null}
          </article>
        ))}
      </section>
    </div>
  );
}

function Field<T extends string>({ label, value, options, labels, onChange }: { label: string; value: T; options: readonly T[]; labels?: Record<string, string>; onChange: (value: T) => void }) {
  return (
    <label className="grid gap-1 text-sm">
      {label}
      <select value={value} onChange={(event) => onChange(event.target.value as T)} className="h-11 rounded-xl border border-border bg-bg px-2">
        {options.map((option) => (
          <option key={option} value={option}>
            {labels?.[option] ?? option}
          </option>
        ))}
      </select>
    </label>
  );
}

function Licensing({ kobaId, owned }: { kobaId: string; owned: Owned[] }) {
  const [token, setToken] = useState<{ appId: string; token: string; expiresAt: string } | null>(null);
  const [left, setLeft] = useState(0);
  const [file, setFile] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!token) return;
    const tick = () => setLeft(Math.max(0, Math.ceil((new Date(token.expiresAt).getTime() - Date.now()) / 1000)));
    tick();
    const timer = window.setInterval(tick, 250);
    return () => window.clearInterval(timer);
  }, [token]);

  if (owned.length === 0) return <p className="text-sm text-muted">Buy a listing first. A download link is only issued to a KOBAid with an active license.</p>;

  return (
    <ul className="grid gap-2">
      {error ? <p className="text-sm text-danger" role="alert">{error}</p> : null}
      {owned.map((purchase) => (
        <li key={purchase.id} className="rounded-3xl border border-border bg-bg-elevated p-4">
          <p className="text-lg">{purchase.app.name}</p>
          <p className="font-mono text-xs text-muted">{purchase.licenseKey}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              variant="primary"
              onClick={() => {
                setError("");
                setFile("");
                void call<{ token: string; expiresAt: string }>("/api/v1/plugins/download", kobaId, { appId: purchase.appId })
                  .then((issued) => setToken({ appId: purchase.appId, token: issued.token, expiresAt: issued.expiresAt }))
                  .catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Could not issue a link"));
              }}
            >
              Generate download link
            </Button>
            {token?.appId === purchase.appId ? (
              <Button
                variant="ghost"
                disabled={left <= 0}
                onClick={() => {
                  void call<{ file: string }>("/api/v1/plugins/download", kobaId, { token: token.token })
                    .then((redeemed) => {
                      setFile(redeemed.file);
                      setToken(null);
                    })
                    .catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Link rejected"));
                }}
              >
                Use once · {left}s
              </Button>
            ) : null}
          </div>
          {token?.appId === purchase.appId ? <p className="mt-2 break-all font-mono text-xs text-muted">{token.token}</p> : null}
          {file && token?.appId !== purchase.appId ? null : null}
        </li>
      ))}
      {file ? <p className="text-sm">Package handed off once: {file}</p> : null}
    </ul>
  );
}
