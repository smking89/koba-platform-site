import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui";
import { GAME_TYPES, SAMPLE_EVENT, type Gate } from "@/site/ingest";

type Panel = "home" | "apis" | "docs" | "keys" | "admin";

const PANELS: { id: Panel; label: string; desktop?: boolean }[] = [
  { id: "home", label: "Home" },
  { id: "apis", label: "APIs" },
  { id: "docs", label: "Documentation" },
  { id: "keys", label: "Keys" },
  { id: "admin", label: "Admin Panel", desktop: true },
];

const API_CATALOG = [
  { id: "dedicated", name: "Dedicated ingest", owner: "KOBA", note: "C# plugin. Rust, DayZ, ARK, 7 Days to Die." },
  { id: "valorant", name: "VALORANT events", owner: "KOBA", note: "Kill feed maps to COMBAT_KILL." },
  { id: "league", name: "League events", owner: "KOBA", note: "Champion kills and match end." },
  { id: "fps", name: "Apex and CS2", owner: "KOBA", note: "Same envelope. Own game_type." },
];

const SAMPLE = JSON.stringify(SAMPLE_EVENT, null, 2);
const FORGED = SAMPLE.replace("AK47_RIFLE", "<script>alert(1)</script>");

const FIELDS = [
  ["integration_metadata.koba_server_id", "Your KOBA server key. srv_ then lowercase."],
  ["integration_metadata.game_type", "RUST, DAYZ, ARK, SEVEN_DAYS, or an API title."],
  ["integration_metadata.payload_timestamp_utc", "Unix seconds. The sample clock is accepted."],
  ["event_envelope.event_type", "COMBAT_KILL, OBJECTIVE, SESSION_JOIN, MATCH_END."],
  ["event_envelope.cryptographic_signature", "0x and at least 16 hex characters. Docs abbreviate this."],
  ["event_envelope.fps_at_execution", "Frame rate when the event was built."],
  ["data_payload.actor_identity", "steam_, epic_, riot_, psn_, xbox_, or koba_."],
  ["data_payload.target_identity", "Same shape as the actor. Use koba_none for a session event."],
  ["data_payload.weapon_used", "Uppercase token. No markup."],
  ["data_payload.is_headshot", "Boolean. Not the string \"true\"."],
  ["data_payload.combat_distance_meters", "Number of meters, 0 to 2000."],
];

interface Audit {
  jti: string;
  exp: number;
  issuedAt: number;
  rotated: boolean;
  requests: number;
  dropped: number;
  live: boolean;
}

interface Series {
  ingress: number[];
  failures: number[];
  forgery: number[];
  bandwidth: number[];
}

async function post<T>(path: string, kobaId: string, body?: unknown): Promise<T> {
  const response = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: { "content-type": "application/json", "x-koba-id": kobaId },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await response.json()) as T & { error?: string };
  if (!response.ok) throw new Error(data.error ?? "Request failed");
  return data;
}

export function DeveloperPortal() {
  const [panel, setPanel] = useState<Panel>("home");
  const [kobaId, setKobaId] = useState("koba_nix");
  const [secret, setSecret] = useState("");
  const [shown, setShown] = useState<Record<string, boolean>>({ dedicated: true, valorant: true, league: true, fps: true });
  const [extra, setExtra] = useState<{ id: string; name: string; owner: string; note: string }[]>([]);
  const [subscribed, setSubscribed] = useState<string[]>([]);
  const catalog = [...API_CATALOG, ...extra];
  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="border-b border-border">
        <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center gap-3 px-3 py-3 sm:px-4">
          <Link to="/" aria-label="KOBA home">
            <img src="/brand/koba-wordmark.gif" alt="" width={435} height={226} className="h-12 w-auto object-contain" />
          </Link>
          <div className="min-w-0">
            <p className="text-sm">developers.koba.games</p>
            <p className="hidden text-xs text-muted lg:block">Register, subscribe, and try a call. Admin stays on a computer.</p>
          </div>
          <Link to="/apps" className="ml-auto text-sm text-muted">
            App store
          </Link>
        </div>
        <div className="mx-auto flex w-full max-w-7xl gap-1 overflow-x-auto px-3 pb-3 sm:px-4">
          {PANELS.map((item) => (
            <button key={item.id} type="button" aria-pressed={panel === item.id} onClick={() => setPanel(item.id)} className={`${item.desktop ? "hidden lg:inline" : ""} shrink-0 px-3 py-2 text-sm ${panel === item.id ? "bg-fg text-bg" : "text-muted"}`}>
              {item.label}
            </button>
          ))}
        </div>
      </header>
      <main className="mx-auto w-full min-w-0 max-w-7xl flex-1 px-3 py-4 pb-28 sm:px-4">
        {panel === "home" ? <Home /> : null}
        {panel === "apis" ? (
          <Apis
            catalog={catalog.filter((item) => shown[item.id] !== false)}
            subscribed={subscribed}
            onSubscribe={async (id) => {
              const minted = await post<{ token: string }>("/api/v1/developers/tokens", kobaId, { action: "issue" });
              setSecret(minted.token);
              setSubscribed((current) => (current.includes(id) ? current : [...current, id]));
            }}
          />
        ) : null}
        {panel === "docs" ? (
          <div className="grid gap-6">
            <Payload />
            <Sandbox kobaId={kobaId} secret={secret} />
          </div>
        ) : null}
        {panel === "keys" ? <Tokens kobaId={kobaId} onId={setKobaId} onIssued={setSecret} /> : null}
        {panel === "admin" ? (
          <>
            <p className="text-sm text-muted lg:hidden">The admin panel is a computer screen.</p>
            <div className="hidden lg:grid lg:gap-4">
              <Admin catalog={catalog} shown={shown} onToggle={(id) => setShown((current) => ({ ...current, [id]: current[id] === false }))} onAdd={(name) => setExtra((current) => [...current, { id: `gen_${current.length}`, name, owner: "Generic", note: "Uploaded spec. Not subscribable until displayed." }])} />
              <Status />
            </div>
          </>
        ) : null}
      </main>
      <SiteFooter />
    </div>
  );
}

function Home() {
  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-2xl">Publish an integration</h1>
        <p className="mt-2 max-w-xl text-sm text-muted">Register a KOBAid, subscribe to an API, and try a call with the key. KOBAbot does not run third-party code.</p>
      </div>
      <Tracks />
    </div>
  );
}

function Apis({
  catalog,
  subscribed,
  onSubscribe,
}: {
  catalog: { id: string; name: string; owner: string; note: string }[];
  subscribed: string[];
  onSubscribe: (id: string) => Promise<void>;
}) {
  const [busy, setBusy] = useState("");
  return (
    <ul className="divide-y divide-border border-y border-border">
      {catalog.map((api) => (
        <li key={api.id} className="flex items-center gap-3 py-3">
          <span className="grid h-12 w-12 shrink-0 place-items-center border border-border text-xs">{api.name.slice(0, 2)}</span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm">{api.name}</span>
            <span className="block truncate text-xs text-muted">{api.owner}</span>
            <span className="hidden text-xs text-faint lg:block">{api.note}</span>
          </span>
          <button
            type="button"
            disabled={busy === api.id || subscribed.includes(api.id)}
            onClick={() => {
              setBusy(api.id);
              void onSubscribe(api.id).finally(() => setBusy(""));
            }}
            className="min-h-8 border border-fg px-3 text-xs disabled:opacity-40"
          >
            {subscribed.includes(api.id) ? "Subscribed" : "Subscribe"}
          </button>
        </li>
      ))}
    </ul>
  );
}

function Admin({
  catalog,
  shown,
  onToggle,
  onAdd,
}: {
  catalog: { id: string; name: string; owner: string }[];
  shown: Record<string, boolean>;
  onToggle: (id: string) => void;
  onAdd: (name: string) => void;
}) {
  const [name, setName] = useState("");
  return (
    <div className="grid gap-4">
      <table className="w-full border border-border text-left text-sm">
        <thead className="border-b border-border text-xs text-muted">
          <tr>
            <th className="px-3 py-2 font-normal">API</th>
            <th className="px-3 py-2 font-normal">Owner</th>
            <th className="px-3 py-2 font-normal">Displayed</th>
          </tr>
        </thead>
        <tbody>
          {catalog.map((api) => (
            <tr key={api.id} className="border-b border-border last:border-b-0">
              <td className="px-3 py-2">{api.name}</td>
              <td className="px-3 py-2 text-muted">{api.owner}</td>
              <td className="px-3 py-2">
                <button type="button" onClick={() => onToggle(api.id)} className={`min-h-8 px-2 text-xs ${shown[api.id] === false ? "text-muted" : "bg-fg text-bg"}`}>
                  {shown[api.id] === false ? "Hidden" : "Shown"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <form
        className="flex flex-wrap items-end gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          if (name.trim().length < 3) return;
          onAdd(name.trim());
          setName("");
        }}
      >
        <label className="grid gap-1 text-sm">
          Generic API
          <input value={name} onChange={(event) => setName(event.target.value)} className="h-11 border border-border bg-bg px-3" />
        </label>
        <Button variant="primary" type="submit">
          Add API
        </Button>
      </form>
    </div>
  );
}

function Tracks() {
  return (
    <div className="grid gap-3 lg:grid-cols-2">
      <article className="grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4">
        <p className="font-mono text-xs tracking-widest text-faint uppercase">Dedicated server</p>
        <h1 className="text-2xl">Rust, DayZ, ARK, 7 Days to Die</h1>
        <p className="text-sm text-muted">Ship a C# plugin on the host. It keeps the tick inside a frame budget, allowlists WebRCON, and posts the normalized event. Nothing here executes inside KOBAbot.</p>
        <ul className="grid gap-1 text-sm text-muted">
          <li>Network budget steps out when a frame runs past 16 ms.</li>
          <li>WebRCON accepts status, players, and save. Chat is not a command.</li>
          <li>Strings are length-capped before they leave the host.</li>
        </ul>
        <a href="/sdk/koba-dedicated.cs" download className="fire-btn inline-flex min-h-11 items-center justify-center rounded-2xl px-4 text-sm font-medium">
          Download koba-dedicated.cs 1.4.0
        </a>
      </article>
      <article className="grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4">
        <p className="font-mono text-xs tracking-widest text-faint uppercase">API track</p>
        <h1 className="text-2xl">LoL, VALORANT, Apex, CS2</h1>
        <p className="text-sm text-muted">Do not forward the raw match log. Map it onto the normalized event, then POST that object. The schema is the contract.</p>
        <ul className="grid gap-1 text-sm text-muted">
          <li>VALORANT kill feed becomes COMBAT_KILL. Round win becomes OBJECTIVE.</li>
          <li>League champion kills use riot_ identities. Match end is MATCH_END.</li>
          <li>Apex and CS2 use the same envelope with game_type APEX or CS2.</li>
        </ul>
        <a href="/sdk/koba-event.schema.json" download className="inline-flex min-h-11 items-center justify-center rounded-2xl border border-border bg-bg-subtle px-4 text-sm">
          Download event schema
        </a>
      </article>
    </div>
  );
}

function Payload() {
  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <pre className="overflow-x-auto rounded-3xl border border-border bg-bg-elevated p-4 font-mono text-xs leading-5 text-muted">{SAMPLE}</pre>
      <ul className="grid content-start gap-2">
        {FIELDS.map(([name, detail]) => (
          <li key={name} className="rounded-2xl border border-border bg-bg-elevated px-3 py-2">
            <p className="font-mono text-xs text-fg">{name}</p>
            <p className="text-sm text-muted">{detail}</p>
          </li>
        ))}
        <li className="rounded-2xl border border-border px-3 py-2 text-sm text-muted">Accepted game types: {GAME_TYPES.join(", ")}.</li>
      </ul>
    </div>
  );
}

function Sandbox({ kobaId, secret }: { kobaId: string; secret: string }) {
  const [raw, setRaw] = useState(SAMPLE);
  const [token, setToken] = useState(secret);
  const [gates, setGates] = useState<Gate[]>([]);
  const [ok, setOk] = useState<boolean | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (secret) setToken(secret);
  }, [secret]);

  const run = async () => {
    setBusy(true);
    setError("");
    try {
      const result = await post<{ ok: boolean; gates: Gate[] }>("/api/v1/developers/ingest", kobaId, { raw, token });
      setGates(result.gates);
      setOk(result.ok);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Ingest failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <div className="grid gap-3">
        <label className="grid gap-1 text-sm">
          Integration token
          <input value={token} onChange={(event) => setToken(event.target.value)} placeholder="Issue one on the Tokens tab" className="h-11 rounded-xl border border-border bg-bg px-3 font-mono text-xs" />
        </label>
        <label className="grid gap-1 text-sm">
          Payload
          <textarea value={raw} onChange={(event) => setRaw(event.target.value)} spellCheck={false} className="min-h-72 w-full min-w-0 rounded-2xl border border-border bg-bg p-3 font-mono text-xs" />
        </label>
        <div className="flex flex-wrap gap-2">
          <Button variant="primary" disabled={busy} onClick={() => void run()}>
            {busy ? "Checking…" : "Test ingest"}
          </Button>
          <Button variant="ghost" onClick={() => setRaw(FORGED)}>
            Load a forged sample
          </Button>
        </div>
        <p className="text-sm text-muted">Every string is cleaned in an isolated layer. Markup, nulls, and template markers fail the forgery gate and are not written. A token past 6 calls in 10 seconds is dropped. Verification checks the HMAC only. It does not open a session.</p>
      </div>
      <div className="grid content-start gap-2">
        {error ? <p className="text-sm text-danger" role="alert">{error}</p> : null}
        {ok !== null ? <p className={`text-sm ${ok ? "text-ok" : "text-danger"}`}>{ok ? "Accepted. The normalized event can be stored." : "Rejected. Nothing was written."}</p> : <p className="text-sm text-muted">Run a payload to see each gate.</p>}
        {gates.map((gate) => (
          <p key={gate.id} className="rounded-2xl border border-border bg-bg-elevated px-3 py-2 text-sm">
            <span className={gate.pass ? "text-ok" : "text-danger"}>{gate.pass ? "Pass" : "Fail"}</span>
            <span className="mx-2 text-fg">{gate.name}.</span>
            <span className="text-muted">{gate.detail}</span>
          </p>
        ))}
      </div>
    </div>
  );
}

function Tokens({ kobaId, onId, onIssued }: { kobaId: string; onId: (id: string) => void; onIssued: (token: string) => void }) {
  const [rows, setRows] = useState<Audit[]>([]);
  const [secret, setSecret] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async (id = kobaId) => {
    const data = await post<{ tokens: Audit[] }>("/api/v1/developers/tokens", id);
    setRows(data.tokens);
  };

  useEffect(() => {
    let cancel = false;
    post<{ tokens: Audit[] }>("/api/v1/developers/tokens", kobaId)
      .then((data) => {
        if (!cancel) setRows(data.tokens);
      })
      .catch(() => {
        if (!cancel) setRows([]);
      });
    return () => {
      cancel = true;
    };
  }, [kobaId]);

  const act = async (body: { action: "issue" | "rotate"; jti?: string }) => {
    setBusy(true);
    setError("");
    try {
      const result = await post<{ token: string }>("/api/v1/developers/tokens", kobaId, body);
      setSecret(result.token);
      onIssued(result.token);
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Token request failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end gap-2">
        <label className="grid gap-1 text-sm">
          KOBAid
          <input value={kobaId} onChange={(event) => onId(event.target.value)} className="h-11 rounded-xl border border-border bg-bg px-3 font-mono text-sm" />
        </label>
        <Button variant="primary" disabled={busy} onClick={() => void act({ action: "issue" })}>
          Generate token
        </Button>
      </div>
      <p className="text-sm text-muted">Tokens live 15 minutes. The secret is shown once. Rotation retires the old id immediately. The gateway still checks the signature without loading an account session.</p>
      {error ? <p className="text-sm text-danger" role="alert">{error}</p> : null}
      {secret ? <pre className="overflow-x-auto rounded-2xl border border-border bg-bg-elevated p-3 font-mono text-xs">{secret}</pre> : null}
      <ul className="grid gap-2">
        {rows.length === 0 ? <li className="text-sm text-muted">No tokens for this KOBAid.</li> : null}
        {rows.map((row) => (
          <li key={row.jti} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border bg-bg-elevated px-3 py-2 text-sm">
            <div>
              <p className="font-mono text-xs">{row.jti}</p>
              <p className="text-muted">{row.live ? "Live" : row.rotated ? "Rotated" : "Expired"} · {row.requests} accepted · {row.dropped} dropped</p>
            </div>
            {row.live ? (
              <Button variant="ghost" disabled={busy} onClick={() => void act({ action: "rotate", jti: row.jti })}>
                Rotate
              </Button>
            ) : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Status() {
  const [series, setSeries] = useState<Series | null>(null);
  useEffect(() => {
    let cancel = false;
    fetch("/api/v1/developers/status")
      .then((response) => response.json())
      .then((data: Series) => {
        if (!cancel) setSeries(data);
      })
      .catch(() => {
        if (!cancel) setSeries(null);
      });
    return () => {
      cancel = true;
    };
  }, []);
  return (
    <div className="grid gap-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <Chart label="Ingress" points={series?.ingress ?? []} />
        <Chart label="Validation failures" points={series?.failures ?? []} />
        <Chart label="Forgery drops" points={series?.forgery ?? []} />
        <Chart label="Bandwidth" points={series?.bandwidth ?? []} />
      </div>
      <ul className="grid gap-2">
        {[
          ["Dedicated plugin 1.4.0", "Operational", "Rust, DayZ, ARK, 7 Days to Die"],
          ["VALORANT webhook 1.2.0", "Operational", "Kill feed to COMBAT_KILL"],
          ["League hook 1.2.0", "Operational", "Champion kills and match end"],
          ["Apex and CS2 1.1.0", "Operational", "Same envelope, own game_type"],
        ].map(([name, state, note]) => (
          <li key={name} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border bg-bg-elevated px-3 py-2 text-sm">
            <span>{name}</span>
            <span className="text-ok">{state}</span>
            <span className="w-full text-muted sm:w-auto">{note}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Chart({ label, points }: { label: string; points: number[] }) {
  const width = 280;
  const height = 72;
  const max = Math.max(...points, 1);
  const step = points.length > 1 ? width / (points.length - 1) : width;
  const line = points.map((point, index) => `${index === 0 ? "M" : "L"}${index * step},${height - 8 - (point / max) * (height - 16)}`).join(" ");
  return (
    <figure className="rounded-3xl border border-border bg-bg-elevated p-3">
      <figcaption className="text-sm text-muted">{label}</figcaption>
      <svg viewBox={`0 0 ${width} ${height}`} className="mt-2 h-20 w-full text-ok" role="img" aria-label={label}>
        <path d={line || "M0 60"} fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>
    </figure>
  );
}
