import { Link } from "@tanstack/react-router";

const LEGAL = [
  { to: "/legal/terms", label: "Terms" },
  { to: "/legal/privacy", label: "Privacy" },
  { to: "/legal/rules", label: "Rules" },
] as const;

const SOCIAL = [
  { href: "https://discord.gg/Ze9VhRqyU", label: "KOBAbot" },
  { href: "https://discord.gg/a5dNJ6Hqa", label: "koba.games" },
  { href: "https://discord.gg/NCVs2KWJ", label: "KOBA servers" },
] as const;

export function SiteFooter({ className = "" }: { className?: string }) {
  return (
    <footer className={`mt-8 border-t border-border py-6 text-xs ${className}`}>
      <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center gap-x-3 gap-y-1 text-muted">
        <p className="text-fg">© 2026 KOBA. All rights reserved.</p>
        <nav aria-label="Legal" className="flex flex-wrap items-center gap-x-3">
          {LEGAL.map((item) => (
            <Link key={item.to} to={item.to} className="inline-flex min-h-8 items-center hover:text-fg">
              {item.label}
            </Link>
          ))}
          <Link to="/apps" className="inline-flex min-h-8 items-center hover:text-fg">
            App store
          </Link>
          <Link to="/developers" className="inline-flex min-h-8 items-center hover:text-fg">
            Developer portal
          </Link>
        </nav>
        <nav aria-label="Social" className="hidden flex-wrap items-center gap-x-3 lg:flex">
          {SOCIAL.map((item) => (
            <a key={item.href} href={item.href} target="_blank" rel="noreferrer" className="inline-flex min-h-8 items-center gap-1.5 hover:text-fg">
              <img src="/brand/logo-discord.svg" alt="" width={14} height={14} className="h-3.5 w-3.5" />
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </footer>
  );
}
