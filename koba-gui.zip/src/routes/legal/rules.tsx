import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";

export const Route = createFileRoute("/legal/rules")({
  component: RulesPage,
});

function RulesPage() {
  return (
    <LegalPage title="Community rules">
      <p>Play the person in front of you, not a pile of alts. One identity, honest hours, and a trust card other players can read.</p>
      <p>No harassment, hate, sexual content involving minors, or threats. Clips and stories stay about the game. Do not post someone else's private information.</p>
      <p>Shops sell KOBA cosmetics, not stolen accounts or real-money game items. Uploads must fit the size window for that product. Do not list art you do not own.</p>
      <p>Servers you claim must post an honest wipe clock. Squad posts and wipe-night events have a cap. Do not fill them with empty seats.</p>
      <p>Mods can warn, strike, or blacklist. Super can clear a record. Repeated strikes close the shop and the events.</p>
    </LegalPage>
  );
}
