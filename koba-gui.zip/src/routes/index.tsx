import { createFileRoute } from "@tanstack/react-router";
import { PlatformApp } from "@/components/platform-app";

export const Route = createFileRoute("/")({ component: PlatformApp });
