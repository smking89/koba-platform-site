import { createFileRoute } from "@tanstack/react-router";
import { AppStore } from "@/components/apps/app-store";

export const Route = createFileRoute("/apps/develop")({
  component: function SubmitListingPage() {
    return <AppStore tab="develop" />;
  },
});
