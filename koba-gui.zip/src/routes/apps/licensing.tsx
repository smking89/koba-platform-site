import { createFileRoute } from "@tanstack/react-router";
import { AppStore } from "@/components/apps/app-store";

export const Route = createFileRoute("/apps/licensing")({
  component: function LicensingPage() {
    return <AppStore tab="licensing" />;
  },
});
