import { createFileRoute } from "@tanstack/react-router";
import { AppStore } from "@/components/apps/app-store";

export const Route = createFileRoute("/apps/purchases")({
  component: function PurchasesPage() {
    return <AppStore tab="purchases" />;
  },
});
