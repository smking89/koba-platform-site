import { createFileRoute } from "@tanstack/react-router";
import { AppStore } from "@/components/apps/app-store";

export const Route = createFileRoute("/apps")({
  component: function AppsPage() {
    return <AppStore tab="browse" />;
  },
});
