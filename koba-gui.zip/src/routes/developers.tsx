import { createFileRoute } from "@tanstack/react-router";
import { DeveloperPortal } from "@/components/developers/portal";

export const Route = createFileRoute("/developers")({
  component: DeveloperPortal,
});
