//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CpnYg3az.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/developers",
			"/legal/privacy",
			"/legal/rules",
			"/legal/terms"
		],
		preloads: ["/assets/index-BQxE1ayH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BQxE1ayH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BWq46bzo.js", "/assets/site-footer-J0W3ulzt.js"]
	},
	"/developers": {
		filePath: "/workspace/src/routes/developers.tsx",
		children: void 0,
		preloads: ["/assets/developers-glxtKZJY.js", "/assets/legal-page-KdP2nz0i.js"]
	},
	"/legal/privacy": {
		filePath: "/workspace/src/routes/legal/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-CsWFCqPc.js", "/assets/legal-page-KdP2nz0i.js"]
	},
	"/legal/rules": {
		filePath: "/workspace/src/routes/legal/rules.tsx",
		children: void 0,
		preloads: ["/assets/rules-4IH9U84m.js", "/assets/legal-page-KdP2nz0i.js"]
	},
	"/legal/terms": {
		filePath: "/workspace/src/routes/legal/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-7O7k5x3q.js", "/assets/legal-page-KdP2nz0i.js"]
	}
} });
//#endregion
export { tsrStartManifest };
