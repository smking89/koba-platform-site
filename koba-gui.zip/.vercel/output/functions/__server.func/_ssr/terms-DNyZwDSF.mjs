import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as LegalPage } from "./legal-page-BRjvhB7A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-DNyZwDSF.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Terms",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KOBA is the gaming network at koba.games. Using the site means you agree to these terms and the community rules." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accounts are yours. You are responsible for what you list, bid, upload, and say. Business listings must be cosmetics you have the right to sell. KOBA does not take ownership of your art." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Official shop charges the seller 2.5% when the account is verified and 3.5% when it is not. The buyer pays the listed price. Astro is a monthly cosmetic pass. Ending it stops applied cosmetics. Preview purchases are not card charges." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KOBA can remove a listing, close an event, or limit an account that breaks the rules. These terms can change. The date on this page is the one that applies." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Last updated October 16, 2026." })
		]
	});
}
//#endregion
export { TermsPage as component };
