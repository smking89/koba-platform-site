import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as LegalPage } from "./legal-page-BRjvhB7A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/developers-CQMVYNyD.js
var import_jsx_runtime = require_jsx_runtime();
function DevelopersPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Developer portal",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This portal is for people building on koba.games: business accounts, server listings, and the KOBAbot community. The site is the product. There is no desktop plugin here." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Open a business from the shop, then list a cosmetic between the minimum and maximum size for that type. Verified businesses pay a 2.5% seller fee. Unverified businesses pay 3.5%. Players need an active Astro pass to apply what they buy." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Server pages carry a wipe clock: players online, last wipe, next wipe, group cap, and gather rate. Claim the listing from the business desk and keep the next wipe honest. Wipe-night events sit on the same page." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"KOBAbot discussion lives on",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://discord.gg/Ze9VhRqyU",
					target: "_blank",
					rel: "noreferrer",
					className: "text-fg underline",
					children: "the KOBAbot Discord"
				}),
				". The network itself is on",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://discord.gg/a5dNJ6Hqa",
					target: "_blank",
					rel: "noreferrer",
					className: "text-fg underline",
					children: "koba.games"
				}),
				". Every KOBA-owned server shares",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://discord.gg/NCVs2KWJ",
					target: "_blank",
					rel: "noreferrer",
					className: "text-fg underline",
					children: "one Discord"
				}),
				"."
			] })
		]
	});
}
//#endregion
export { DevelopersPage as component };
