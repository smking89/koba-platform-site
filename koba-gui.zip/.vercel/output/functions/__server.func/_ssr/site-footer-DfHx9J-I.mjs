import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-footer-DfHx9J-I.js
var import_jsx_runtime = require_jsx_runtime();
var LEGAL = [
	{
		to: "/legal/terms",
		label: "Terms"
	},
	{
		to: "/legal/privacy",
		label: "Privacy"
	},
	{
		to: "/legal/rules",
		label: "Rules"
	}
];
var SOCIAL = [
	{
		href: "https://discord.gg/Ze9VhRqyU",
		label: "KOBAbot"
	},
	{
		href: "https://discord.gg/a5dNJ6Hqa",
		label: "koba.games"
	},
	{
		href: "https://discord.gg/NCVs2KWJ",
		label: "KOBA servers"
	}
];
function SiteFooter({ dock = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: `fixed inset-x-0 z-20 border-t border-border bg-bg/95 px-3 py-2 text-xs backdrop-blur ${dock ? "bottom-[4.85rem] xl:bottom-0" : "bottom-0"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-7xl flex-wrap items-center gap-x-3 gap-y-1 text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-fg",
					children: "© 2026 KOBA. All rights reserved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": "Legal",
					className: "flex flex-wrap items-center gap-x-3",
					children: [LEGAL.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "inline-flex min-h-8 items-center hover:text-fg",
						children: item.label
					}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/developers",
						className: "inline-flex min-h-8 items-center hover:text-fg",
						children: "Developer portal"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Social",
					className: "flex flex-wrap items-center gap-x-3",
					children: SOCIAL.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: item.href,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex min-h-8 items-center gap-1.5 hover:text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/brand/logo-discord.svg",
							alt: "",
							width: 14,
							height: 14,
							className: "h-3.5 w-3.5"
						}), item.label]
					}, item.href))
				})
			]
		})
	});
}
//#endregion
export { SiteFooter as t };
