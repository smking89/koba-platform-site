import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as LegalPage } from "./legal-page-BRjvhB7A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-D2JNuBjU.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Privacy",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KOBA collects the account details you give it: name, email, and the platform you use to sign in. Steam, Xbox, and Discord authorize only the scopes shown on the sign-in screen. KOBA does not ask those platforms for your password." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Profile play, shop purchases, bids, group membership, and discipline notes stay on your KOBA identity so other players can read the trust card. Email is not shown on the public profile." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KOBA does not sell personal information. Discord links in the footer leave this site. Those servers have their own privacy practices." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can sign out from the account menu. To ask for a correction or a deletion, use the koba.games Discord linked in the footer." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Last updated October 16, 2026." })
		]
	});
}
//#endregion
export { PrivacyPage as component };
