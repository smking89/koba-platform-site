import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as SiteFooter } from "./site-footer-DfHx9J-I.mjs";
import { a as Search, c as MessageSquare, d as ChevronDown, f as Bell, i as Store, l as House, n as UserRound, o as Plus, p as BadgeCheck, s as Mic, t as Users, u as Hash } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BxJIMauG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Button({ variant = "ghost", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-4 text-sm font-medium transition-[opacity,transform] duration-150 ease-out active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-40 disabled:active:scale-100", variant === "primary" && "fire-btn", variant === "ghost" && "border border-border bg-bg-subtle text-fg hover:bg-bg-elevated", variant === "quiet" && "text-muted hover:text-fg", className),
		...props
	});
}
function Chip({ children, tone = "neutral" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border px-2 py-1 font-mono text-xs", tone === "neutral" && "border-border text-muted", tone === "warn" && "border-warn/40 text-warn", tone === "danger" && "border-danger/40 text-danger", tone === "ok" && "border-ok/40 text-ok", tone === "cyan" && "border-cyan/40 text-cyan"),
		children
	});
}
function MenuSelect({ label, value, options, onChange, ariaLabel, placeholder = "Choose", className }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const root = (0, import_react.useRef)(null);
	const current = options.find((option) => option.value === value);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onPointer = (event) => {
			if (!root.current?.contains(event.target)) setOpen(false);
		};
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.addEventListener("pointerdown", onPointer);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("pointerdown", onPointer);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative", className),
		ref: root,
		"data-noswipe": true,
		children: [
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1 block text-xs text-muted",
				children: label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-haspopup": "listbox",
				"aria-expanded": open,
				"aria-label": ariaLabel,
				onClick: () => setOpen((next) => !next),
				className: "flex h-11 w-full items-center justify-between gap-2 rounded-2xl border border-border bg-bg-subtle px-3 text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: current?.label ?? placeholder
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					size: 16,
					"aria-hidden": true,
					className: cn("shrink-0 text-muted transition-transform", open && "rotate-180")
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				role: "listbox",
				className: "menu-pop absolute z-40 mt-2 max-h-64 w-full min-w-44 overflow-y-auto rounded-2xl border border-border bg-bg-elevated p-1",
				children: options.map((option) => {
					const on = option.value === value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "option",
						"aria-selected": on,
						onClick: () => {
							onChange(option.value);
							setOpen(false);
						},
						className: cn("flex min-h-11 w-full items-center justify-between gap-3 rounded-xl px-3 text-left text-sm", on ? "bg-violet/25 text-fg" : "text-muted hover:bg-bg-subtle hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: option.label
						}), option.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 font-mono text-xs text-faint",
							children: option.hint
						}) : null]
					}) }, option.value);
				})
			}) : null
		]
	});
}
async function hmacSha256(key, body) {
	const enc = new TextEncoder();
	const cryptoKey = await crypto.subtle.importKey("raw", enc.encode(key), {
		name: "HMAC",
		hash: "SHA-256"
	}, false, ["sign"]);
	const raw = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(body));
	return [...new Uint8Array(raw)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
var RAID_SURFACES = /* @__PURE__ */ new Set(["cupboard.tool", "wall.external.high.stone"]);
function clanTier(size) {
	if (size <= 4) return "SQUAD";
	if (size <= 8) return "STANDARD_CLAN";
	return "ZERG";
}
function canonicalBody(packet) {
	return JSON.stringify({
		at: packet.at,
		attackerName: packet.attackerName,
		attackerSteam: packet.attackerSteam,
		damage: packet.damage ?? null,
		distance: packet.distance ?? null,
		entity: packet.entity ?? null,
		hitZone: packet.hitZone ?? null,
		kind: packet.kind,
		ownerSteam: packet.ownerSteam ?? null,
		pve: packet.pve ?? false,
		serverId: packet.serverId,
		victimName: packet.victimName ?? null,
		victimSteam: packet.victimSteam ?? null,
		weapon: packet.weapon ?? null
	});
}
async function signPacket(pluginKey, packet) {
	return hmacSha256(pluginKey, canonicalBody(packet));
}
function nextId$1(data, prefix) {
	const seq = data.seq + 1;
	return {
		id: `${prefix}-${seq}`,
		data: {
			...data,
			seq
		}
	};
}
function identityBySteam(data, steamId) {
	if (!steamId) return void 0;
	return data.identities.find((identity) => identity.steamId === steamId);
}
function identityById(data, id) {
	return data.identities.find((identity) => identity.id === id);
}
function replaceIdentity(data, next) {
	return {
		...data,
		identities: data.identities.map((identity) => identity.id === next.id ? next : identity)
	};
}
async function ingest(data, packet, now) {
	const server = data.servers.find((item) => item.id === packet.serverId);
	const hostPass = Boolean(server && server.license === "active" && server.hostKey === packet.hostKey);
	const gates = [{
		gate: "host",
		pass: hostPass,
		note: !server ? "Unknown server id." : server.license !== "active" ? "License is not active." : hostPass ? "Host key matches." : "Host key rejected."
	}];
	const expected = server ? await hmacSha256(server.pluginKey, canonicalBody(packet)) : "";
	const signaturePass = Boolean(server) && expected === packet.plugin_signature && packet.plugin_signature.length > 0;
	gates.push({
		gate: "signature",
		pass: signaturePass,
		note: !server ? "No plugin key on file." : signaturePass ? "HMAC-SHA256 matches the plugin key." : "Signature failed. Dropped as a forgery."
	});
	const recent = data.attempts.filter((attempt) => attempt.serverId === packet.serverId && now - attempt.at < 1e4);
	let sanityPass = true;
	let sanityNote = "Fields and rate are inside bounds.";
	if (packet.kind === "combat") {
		if (!packet.victimSteam || !packet.weapon) {
			sanityPass = false;
			sanityNote = "Combat rows need a victim and a weapon.";
		} else if ((packet.distance ?? 0) < 0 || (packet.distance ?? 0) > 350) {
			sanityPass = false;
			sanityNote = "Distance is outside the combat envelope.";
		}
	} else if (!packet.entity || !RAID_SURFACES.has(packet.entity)) {
		sanityPass = false;
		sanityNote = "Raid hook only accepts tool cupboards and external walls.";
	}
	if (sanityPass && recent.length >= 8) {
		sanityPass = false;
		sanityNote = "Rate gate: more than 8 packets in 10 seconds.";
	}
	gates.push({
		gate: "sanity",
		pass: sanityPass,
		note: sanityNote
	});
	const actor = identityBySteam(data, packet.attackerSteam);
	const identityPass = Boolean(actor);
	gates.push({
		gate: "identity",
		pass: identityPass,
		note: identityPass ? `Mapped to ${actor.name}.` : "No KOBAid for this SteamID. Held for back-dating."
	});
	const attempts = [...data.attempts, {
		serverId: packet.serverId,
		at: now
	}].slice(-80);
	let next = {
		...data,
		attempts
	};
	if (!hostPass || !signaturePass || !sanityPass) return {
		data: next,
		result: {
			disposition: "drop",
			gates
		}
	};
	const issued = nextId$1(next, "evt");
	next = issued.data;
	const stored = {
		...packet,
		id: issued.id,
		provisional: !identityPass
	};
	if (!identityPass) {
		next = {
			...next,
			provisional: [stored, ...next.provisional].slice(0, 40)
		};
		return {
			data: next,
			result: {
				disposition: "provisional",
				gates,
				eventId: stored.id
			}
		};
	}
	const feedIssued = nextId$1(next, "feed");
	next = feedIssued.data;
	const title = packet.kind === "combat" ? `${packet.attackerName} downed ${packet.victimName ?? "someone"}` : `${packet.attackerName} hit ${packet.entity}`;
	const detail = packet.kind === "combat" ? `${packet.weapon} · ${packet.distance ?? 0}m · ${packet.hitZone ?? "body"}` : `${packet.damage ?? 0} damage · ${server?.name ?? packet.serverId}`;
	const tone = packet.kind === "raid" ? "danger" : "cyan";
	next = {
		...next,
		events: [stored, ...next.events].slice(0, 60),
		feed: [{
			id: feedIssued.id,
			at: packet.at,
			tone,
			title,
			detail
		}, ...next.feed].slice(0, 40)
	};
	return {
		data: next,
		result: {
			disposition: "commit",
			gates,
			eventId: stored.id
		}
	};
}
function embed(title, description, color, fields = []) {
	return {
		title,
		description,
		color,
		fields
	};
}
function findPerson(data, token) {
	const key = token.toLowerCase();
	return data.identities.find((identity) => identity.handle === key || identity.name.toLowerCase() === key || identity.id === key);
}
function findClan(data, token) {
	const key = token.toLowerCase();
	return data.clans.find((clan) => clan.id === key || clan.name.toLowerCase() === key);
}
function blocked(data, actor, line) {
	if (actor.status !== "blacklisted") return null;
	if (line.startsWith("/support")) return null;
	return {
		embed: embed("Profile locked", "This KOBAid is on the permanent blacklist. Only /support still answers.", "danger"),
		data
	};
}
function requireStaff(role, need) {
	const rank = [
		"player",
		"admin",
		"owner",
		"developer"
	];
	return rank.indexOf(role) >= rank.indexOf(need);
}
function routeCommand(data, line, role, hq, game, now) {
	const actor = identityById(data, data.viewerId);
	if (!actor) return {
		embed: embed("No identity", "Pick a profile first.", "danger"),
		data
	};
	const text = line.trim();
	const denied = blocked(data, actor, text.toLowerCase());
	if (denied) return denied;
	const parts = text.replace(/^\//, "").split(/\s+/).filter(Boolean);
	const name = (parts[0] ?? "").toLowerCase();
	const args = parts.slice(1);
	if (!name) return {
		embed: embed("Empty", "Start with a slash command.", "danger"),
		data
	};
	const unlinked = !actor.steamId;
	if ([
		"claim",
		"shop",
		"play",
		"war",
		"clan"
	].includes(name) && unlinked) return {
		embed: embed("Link required", "This command waits on a verified game account. Use /link steam <SteamID64>.", "danger"),
		data
	};
	if (name === "coins") {
		const sub = (args[0] ?? "balance").toLowerCase();
		if (sub === "balance") return {
			embed: embed("Coins", `${actor.name} holds ${actor.coins}.`, "gold", [{
				name: "KOBAid",
				value: actor.id
			}]),
			data
		};
		if (sub === "send") {
			const target = findPerson(data, args[1] ?? "");
			const amount = Number(args[2]);
			if (!target || target.id === actor.id || !Number.isInteger(amount) || amount <= 0) return {
				embed: embed("Send failed", "Use /coins send <handle> <amount>.", "danger"),
				data
			};
			if (actor.coins < amount) return {
				embed: embed("Send failed", "Not enough coins.", "danger"),
				data
			};
			let next = replaceIdentity(data, {
				...actor,
				coins: actor.coins - amount
			});
			const fresh = identityById(next, target.id);
			next = replaceIdentity(next, {
				...fresh,
				coins: fresh.coins + amount
			});
			const issued = nextId$1(next, "feed");
			const row = {
				id: issued.id,
				at: now,
				tone: "gold",
				title: `${actor.name} sent ${amount} coins`,
				detail: `To ${target.name}`
			};
			next = {
				...issued.data,
				feed: [row, ...issued.data.feed].slice(0, 40)
			};
			return {
				embed: embed("Transfer", `${amount} moved to ${target.name}.`, "gold"),
				data: next
			};
		}
	}
	if (name === "claim") {
		if (actor.claimed) return {
			embed: embed("Already claimed", "The daily claim is spent.", "gold"),
			data
		};
		const next = replaceIdentity(data, {
			...actor,
			claimed: true,
			coins: actor.coins + 25
		});
		return {
			embed: embed("Claim", "+25 coins.", "gold", [{
				name: "Balance",
				value: String(actor.coins + 25)
			}]),
			data: next
		};
	}
	if (name === "shop") {
		if (game === "DAYZ") return {
			embed: embed("Shop · DayZ", "Medical supplies for the Cherno run.", "cyan", [{
				name: "Bandage pack",
				value: "15 coins"
			}, {
				name: "Blood bag",
				value: "40 coins"
			}]),
			data
		};
		return {
			embed: embed("Shop · Rust Console", "Kits and a dial-a-ride off the beach.", "green", [{
				name: "Harbor kit",
				value: "30 coins"
			}, {
				name: "Minicopter ride",
				value: "20 coins"
			}]),
			data
		};
	}
	if (name === "play") {
		if (actor.coins < 10) return {
			embed: embed("Can't queue", "Play costs 10 coins.", "danger"),
			data
		};
		const next = replaceIdentity(data, {
			...actor,
			coins: actor.coins - 10
		});
		return {
			embed: embed(game === "DAYZ" ? "Clinic run queued" : "Recycler roulette queued", "10 coins staked. The core will settle the round.", game === "DAYZ" ? "cyan" : "green"),
			data: next
		};
	}
	if (name === "clan" && (args[0] ?? "").toLowerCase() === "create") {
		if (actor.clanId) return {
			embed: embed("Already in a clan", "Leave first.", "danger"),
			data
		};
		const clanName = args.slice(1).join(" ").trim();
		if (clanName.length < 3) return {
			embed: embed("Name too short", "Use /clan create <name>.", "danger"),
			data
		};
		const issued = nextId$1(data, "clan");
		const clan = {
			id: issued.id,
			name: clanName,
			memberIds: [actor.id]
		};
		const next = replaceIdentity({
			...issued.data,
			clans: [...issued.data.clans, clan]
		}, {
			...actor,
			clanId: clan.id
		});
		return {
			embed: embed("Clan opened", `${clanName} is a SQUAD.`, "cyan"),
			data: next
		};
	}
	if (name === "clan" && (args[0] ?? "").toLowerCase() === "leave") {
		if (!actor.clanId) return {
			embed: embed("No clan", "Nothing to leave.", "danger"),
			data
		};
		const next = replaceIdentity({
			...data,
			clans: data.clans.map((clan) => clan.id === actor.clanId ? {
				...clan,
				memberIds: clan.memberIds.filter((id) => id !== actor.id)
			} : clan)
		}, {
			...actor,
			clanId: void 0
		});
		return {
			embed: embed("Left clan", "Roster updated.", "cyan"),
			data: next
		};
	}
	if (name === "clan") return {
		embed: embed("Clan", "Use /clan create <name> or /clan leave.", "cyan"),
		data
	};
	if (name === "war") {
		const sub = (args[0] ?? "").toLowerCase();
		const clan = actor.clanId ? data.clans.find((item) => item.id === actor.clanId) : void 0;
		if (!clan) return {
			embed: embed("No clan", "Wars are clan actions.", "danger"),
			data
		};
		if (sub === "end") {
			const next = {
				...data,
				clans: data.clans.map((item) => item.id === clan.id ? {
					...item,
					atWarWith: void 0
				} : item)
			};
			return {
				embed: embed("War ended", `${clan.name} stands down.`, "cyan"),
				data: next
			};
		}
		if (sub === "declare") {
			const target = findClan(data, args.slice(1).join(" "));
			if (!target || target.id === clan.id) return {
				embed: embed("Declare failed", "Use /war declare <clan>.", "danger"),
				data
			};
			const issued = nextId$1({
				...data,
				clans: data.clans.map((item) => item.id === clan.id ? {
					...item,
					atWarWith: target.id
				} : item)
			}, "feed");
			return {
				embed: embed("War declared", `${clan.name} against ${target.name}.`, "danger"),
				data: {
					...issued.data,
					feed: [{
						id: issued.id,
						at: now,
						tone: "danger",
						title: `${clan.name} declared war`,
						detail: target.name
					}, ...issued.data.feed]
				}
			};
		}
		return {
			embed: embed("War", "Use /war declare <clan> or /war end.", "danger"),
			data
		};
	}
	if (name === "link" && (args[0] ?? "").toLowerCase() === "steam") {
		const steamId = args[1] ?? "";
		if (!/^7656\d{13}$/.test(steamId)) return {
			embed: embed("Bad SteamID64", "Expected 17 digits starting with 7656.", "danger"),
			data
		};
		if (data.identities.some((identity) => identity.steamId === steamId && identity.id !== actor.id)) return {
			embed: embed("Already linked", "That SteamID belongs to another KOBAid.", "danger"),
			data
		};
		let next = replaceIdentity(data, {
			...actor,
			steamId
		});
		const moved = next.provisional.filter((event) => event.attackerSteam === steamId || event.victimSteam === steamId);
		const stay = next.provisional.filter((event) => event.attackerSteam !== steamId && event.victimSteam !== steamId);
		next = {
			...next,
			provisional: stay,
			events: [...moved.map((event) => ({
				...event,
				provisional: false
			})), ...next.events].slice(0, 60)
		};
		if (moved.length) {
			const issued = nextId$1(next, "feed");
			next = {
				...issued.data,
				feed: [{
					id: issued.id,
					at: now,
					tone: "ok",
					title: `Back-dated ${moved.length} packet${moved.length === 1 ? "" : "s"}`,
					detail: steamId
				}, ...issued.data.feed]
			};
		}
		return {
			embed: embed("Linked", `Steam ${steamId} is on ${actor.name}.`, "green", [{
				name: "Back-dated",
				value: String(moved.length)
			}]),
			data: next
		};
	}
	if (name === "unlink" && (args[0] ?? "").toLowerCase() === "steam") return {
		embed: embed("Unlinked", "The Steam footprint is clear. History stays.", "cyan"),
		data: replaceIdentity(data, {
			...actor,
			steamId: void 0
		})
	};
	if (name === "support") return {
		embed: embed("Support", "Ticket opened against this KOBAid. A staff seat can read the audit.", "cyan"),
		data
	};
	if (name === "mod") {
		if (!requireStaff(role, "admin")) return {
			embed: embed("Staff only", "Warnings and strikes need an admin seat.", "danger"),
			data
		};
		const sub = (args[0] ?? "").toLowerCase();
		const target = findPerson(data, args[1] ?? "");
		if (!target) return {
			embed: embed("No player", "Use /mod warning|strike|clear <handle>.", "danger"),
			data
		};
		if (sub === "warning") {
			if (target.warnings >= 1) return {
				embed: embed("Warning cap", "Level 1 already used the one warning.", "danger"),
				data
			};
			const status = target.strikes > 0 ? target.status : "warned";
			let next = replaceIdentity(data, {
				...target,
				warnings: 1,
				status
			});
			const audit = nextId$1(next, "audit");
			next = {
				...audit.data,
				audit: [{
					id: audit.id,
					at: now,
					actor: actor.name,
					action: "warning",
					detail: target.name
				}, ...audit.data.audit]
			};
			return {
				embed: embed("Warning filed", `${target.name} is on one warning.`, "danger"),
				data: next
			};
		}
		if (sub === "strike") {
			if (target.status === "blacklisted" || target.strikes >= 3) return {
				embed: embed("No further strikes", "The profile is already at the cap.", "danger"),
				data
			};
			const strikes = target.strikes + 1;
			const status = strikes >= 3 ? "under_review" : "struck";
			let next = replaceIdentity(data, {
				...target,
				strikes,
				status
			});
			const audit = nextId$1(next, "audit");
			next = {
				...audit.data,
				audit: [{
					id: audit.id,
					at: now,
					actor: actor.name,
					action: "strike",
					detail: `${target.name} · ${strikes}/3`
				}, ...audit.data.audit]
			};
			return {
				embed: embed(strikes >= 3 ? "Profile under review" : "Strike filed", `${target.name} is at ${strikes}/3.`, "danger"),
				data: next
			};
		}
		if (sub === "clear") {
			if (!requireStaff(role, "developer")) return {
				embed: embed("Master only", "Removing a strike is a developer action.", "danger"),
				data
			};
			if (target.strikes <= 0) return {
				embed: embed("Nothing to clear", "No strikes on file.", "cyan"),
				data
			};
			const strikes = target.strikes - 1;
			const status = target.status === "blacklisted" ? "blacklisted" : strikes > 0 ? "struck" : target.warnings ? "warned" : "clear";
			let next = replaceIdentity(data, {
				...target,
				strikes,
				status
			});
			const audit = nextId$1(next, "audit");
			next = {
				...audit.data,
				audit: [{
					id: audit.id,
					at: now,
					actor: actor.name,
					action: "clear-strike",
					detail: target.name
				}, ...audit.data.audit]
			};
			return {
				embed: embed("Strike removed", "History stays. The count went down by one.", "cyan"),
				data: next
			};
		}
	}
	if (name === "globalban" || name === "globalunban") {
		if (!hq || !requireStaff(role, "developer")) return {
			embed: embed("HQ only", "Global bans only exist on the official KOBA server, from a developer seat.", "danger"),
			data
		};
		const target = findPerson(data, args[0] ?? "");
		if (!target) return {
			embed: embed("No player", `Use /${name} <handle>.`, "danger"),
			data
		};
		const status = name === "globalban" ? "blacklisted" : target.strikes >= 3 ? "under_review" : target.strikes > 0 ? "struck" : target.warnings ? "warned" : "clear";
		let next = replaceIdentity(data, {
			...target,
			status
		});
		const audit = nextId$1(next, "audit");
		next = {
			...audit.data,
			audit: [{
				id: audit.id,
				at: now,
				actor: actor.name,
				action: name,
				detail: target.name
			}, ...audit.data.audit]
		};
		return {
			embed: embed(name === "globalban" ? "Blacklisted" : "Ban lifted", target.name, name === "globalban" ? "danger" : "green"),
			data: next
		};
	}
	if (name === "license") {
		if (!hq || !requireStaff(role, "developer")) return {
			embed: embed("HQ only", "License tools stay on the official server.", "danger"),
			data
		};
		return {
			embed: embed("Licenses", "Guild adapters currently on file.", "cyan", data.servers.map((server) => ({
				name: server.name,
				value: `${server.game} · ${server.license}`
			}))),
			data
		};
	}
	if (name === "nuke") {
		if (!requireStaff(role, "owner")) return {
			embed: embed("Owner only", "/nuke is the server owner's absolute reset.", "danger"),
			data
		};
		if ((args[0] ?? "").toLowerCase() !== "confirm") return {
			embed: embed("Confirm nuke", "This clears coins, claims, and wars. Identities and the audit stay. Run /nuke confirm.", "danger"),
			data
		};
		const issued = nextId$1(data, "audit");
		const next = {
			...issued.data,
			identities: data.identities.map((identity) => ({
				...identity,
				coins: 0,
				claimed: false
			})),
			clans: data.clans.map((clan) => ({
				...clan,
				atWarWith: void 0
			})),
			audit: [{
				id: issued.id,
				at: now,
				actor: actor.name,
				action: "nuke",
				detail: "Coins, claims, and wars reset."
			}, ...issued.data.audit]
		};
		return {
			embed: embed("Nuke complete", "Wallets are zero. The audit was not touched.", "danger"),
			data: next
		};
	}
	if (name === "progression") return {
		embed: embed("Progression", `${actor.name} is ${actor.form}.`, game === "DAYZ" ? "cyan" : "green", [
			{
				name: "Score",
				value: String(actor.score)
			},
			{
				name: "Session",
				value: `${actor.scoreDelta >= 0 ? "+" : ""}${actor.scoreDelta}`
			},
			{
				name: "Homes",
				value: `${actor.homes.length}/3`
			}
		]),
		data
	};
	if (name === "lfg") {
		const issued = nextId$1(data, "feed");
		const where = game === "DAYZ" ? "DayZ" : "Rust Console";
		const row = {
			id: issued.id,
			at: now,
			tone: "gold",
			title: `${actor.name} posted LFG`,
			detail: where
		};
		return {
			embed: embed("LFG posted", `${actor.name} is looking for a group on ${where}.`, "gold"),
			data: {
				...issued.data,
				feed: [row, ...issued.data.feed].slice(0, 40)
			}
		};
	}
	if (name === "challenge") {
		const target = findPerson(data, args[0] ?? "");
		if (!target || target.id === actor.id) return {
			embed: embed("No rival", "Use /challenge <handle>.", "danger"),
			data
		};
		const gap = target.score - actor.score;
		const issued = nextId$1(data, "feed");
		const gapLabel = gap === 0 ? "Even" : gap > 0 ? `${target.name} leads by ${gap}` : `${actor.name} leads by ${-gap}`;
		const row = {
			id: issued.id,
			at: now,
			tone: "gold",
			title: `${actor.name} challenged ${target.name}`,
			detail: gapLabel
		};
		return {
			embed: embed("Challenge open", `${actor.name} against ${target.name}.`, "gold", [
				{
					name: actor.handle,
					value: String(actor.score)
				},
				{
					name: target.handle,
					value: String(target.score)
				},
				{
					name: "Gap",
					value: gapLabel
				}
			]),
			data: {
				...issued.data,
				feed: [row, ...issued.data.feed].slice(0, 40)
			}
		};
	}
	if (name === "commands") return {
		embed: embed("Commands", "Player, clan, and staff trees.", game === "DAYZ" ? "cyan" : "green", [
			{
				name: "Player",
				value: "/claim /shop /play /coins /progression /challenge /lfg /link /support"
			},
			{
				name: "Clan",
				value: "/clan create /clan leave /war declare /war end"
			},
			{
				name: "Staff",
				value: "/mod warning /mod strike /nuke"
			}
		]),
		data
	};
	return {
		embed: embed("Unknown", "Try /commands.", "danger"),
		data
	};
}
function nextCapacity(fps, prev) {
	if (prev === "nominal") {
		if (fps < 25) return "critical";
		if (fps < 45) return "strained";
		return "nominal";
	}
	if (prev === "strained") {
		if (fps < 25) return "critical";
		if (fps > 55) return "nominal";
		return "strained";
	}
	if (fps > 55) return "nominal";
	if (fps > 35) return "strained";
	return "critical";
}
function formSeries(identity) {
	let h = 2166136261;
	for (let i = 0; i < identity.id.length; i++) {
		h ^= identity.id.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	const points = [];
	let value = 40 + h % 25;
	for (let i = 7; i >= 0; i--) {
		h = Math.imul(h ^ i + 1, 16777619);
		const step = h % 9 - 4;
		value = Math.max(8, Math.min(96, value + step));
		points.push({
			label: i === 0 ? "now" : `-${i}`,
			form: i === 0 ? value + Math.sign(identity.scoreDelta) * 6 : value
		});
	}
	return points;
}
function seedPlatform() {
	return {
		identities: [
			{
				id: "koba_mara",
				name: "Mara Vale",
				handle: "mara",
				score: 1840,
				form: "rising",
				scoreDelta: 18,
				badges: ["Astro"],
				discordId: "1001840",
				steamId: "76561198000001840",
				coins: 240,
				claimed: false,
				warnings: 0,
				strikes: 0,
				status: "clear",
				clanId: "ironwake",
				homes: [{
					name: "Harbor bag",
					x: 142.2,
					y: 18.4,
					z: -88.1
				}, {
					name: "Rig closet",
					x: 12,
					y: 41.5,
					z: 6.4
				}],
				rivals: ["koba_dex", "koba_ysolde"]
			},
			{
				id: "koba_harrow",
				name: "Harrow Quinn",
				handle: "harrow",
				score: 1764,
				form: "steady",
				scoreDelta: 2,
				badges: ["Clan lead"],
				discordId: "1001764",
				steamId: "76561198000001764",
				coins: 410,
				claimed: true,
				warnings: 0,
				strikes: 0,
				status: "clear",
				clanId: "ironwake",
				homes: [{
					name: "HQ",
					x: 140.1,
					y: 19,
					z: -90.4
				}],
				rivals: ["koba_ysolde"]
			},
			{
				id: "koba_dex",
				name: "Dex Hollow",
				handle: "dex",
				score: 1896,
				form: "rising",
				scoreDelta: 11,
				badges: [],
				discordId: "1001896",
				steamId: "76561198000001896",
				coins: 90,
				claimed: false,
				warnings: 1,
				strikes: 0,
				status: "warned",
				clanId: "ironwake",
				homes: [],
				rivals: ["koba_mara"]
			},
			{
				id: "koba_nora",
				name: "Nora Keel",
				handle: "nora",
				score: 2144,
				form: "steady",
				scoreDelta: 4,
				badges: ["Ranked"],
				discordId: "1002144",
				steamId: "76561198000002144",
				coins: 60,
				claimed: false,
				warnings: 0,
				strikes: 0,
				status: "clear",
				homes: [],
				rivals: []
			},
			{
				id: "koba_ysolde",
				name: "Ysolde Voss",
				handle: "ysolde",
				score: 1912,
				form: "falling",
				scoreDelta: -9,
				badges: ["Clan lead"],
				discordId: "1001912",
				steamId: "76561198000001912",
				coins: 150,
				claimed: false,
				warnings: 0,
				strikes: 1,
				status: "struck",
				clanId: "northline",
				homes: [{
					name: "Ops",
					x: -420,
					y: 22,
					z: 1180.5
				}],
				rivals: ["koba_mara"]
			}
		],
		clans: [{
			id: "ironwake",
			name: "IRONWAKE",
			memberIds: [
				"koba_mara",
				"koba_harrow",
				"koba_dex"
			]
		}, {
			id: "northline",
			name: "NORTHLINE",
			memberIds: ["koba_ysolde"]
		}],
		servers: [{
			id: "srv-iron",
			name: "IRONWAKE Harbor",
			game: "RUST_CONSOLE",
			guildId: "guild-iron",
			license: "active",
			hostKey: "hk_harbor_9f",
			pluginKey: "vk_harbor_3c"
		}, {
			id: "srv-cherno",
			name: "Cherno Line",
			game: "DAYZ",
			guildId: "guild-cherno",
			license: "active",
			hostKey: "hk_cherno_2a",
			pluginKey: "vk_cherno_8d"
		}],
		events: [],
		provisional: [],
		attempts: [],
		feed: [{
			id: "feed-0",
			at: 17e11,
			tone: "ok",
			title: "Mara Vale form is rising",
			detail: "+18 this session"
		}, {
			id: "feed-1",
			at: 1699999e6,
			tone: "cyan",
			title: "IRONWAKE roster holds",
			detail: "SQUAD · 3 members"
		}],
		audit: [{
			id: "audit-0",
			at: 1699e9,
			actor: "System",
			action: "seed",
			detail: "Discipline matrix opened."
		}],
		viewerId: "koba_mara",
		seq: 10
	};
}
var LISTINGS = [
	{
		id: "srv-iron",
		name: "IRONWAKE Harbor",
		game: "Rust Console",
		gameId: "rust",
		platform: "Console",
		region: "NA",
		players: 84,
		cap: 100,
		tags: [
			"Monthly wipe",
			"Vanilla+",
			"Active admins"
		],
		style: "Survival",
		blurb: "Harbor monuments, a quiet south road, and a clan that actually answers LFG.",
		rating: "4.6"
	},
	{
		id: "srv-rig",
		name: "Rig 19",
		game: "Rust Console",
		gameId: "rust",
		platform: "Console",
		region: "NA",
		players: 67,
		cap: 100,
		tags: ["Monuments", "No offline raid"],
		style: "Tactical",
		blurb: "Oil and rig cycles on a timer. Teams that show up late lose the puzzle.",
		rating: "4.5"
	},
	{
		id: "srv-north",
		name: "Northline Ice",
		game: "Rust Console",
		gameId: "rust",
		platform: "Console",
		region: "EU",
		players: 41,
		cap: 80,
		tags: ["Hardcore", "No team cap"],
		style: "Hardcore",
		blurb: "Cold north, thin loot, and wars that last the whole wipe.",
		rating: "4.2"
	},
	{
		id: "srv-salt",
		name: "Saltflat",
		game: "Rust Console",
		gameId: "rust",
		platform: "Console",
		region: "OCE",
		players: 12,
		cap: 50,
		tags: ["Builders", "Low pop"],
		style: "Social",
		blurb: "A smaller map for crews who would rather build than snowball.",
		rating: "4.0"
	},
	{
		id: "srv-cherno",
		name: "Cherno Line",
		game: "DayZ",
		gameId: "dayz",
		platform: "PC",
		region: "EU",
		players: 36,
		cap: 60,
		tags: ["Fresh spawns", "Medical trade"],
		style: "Tactical",
		blurb: "Coastal runs with a clinic at the north end of the line.",
		rating: "4.4"
	},
	{
		id: "srv-black",
		name: "Black Coast",
		game: "DayZ",
		gameId: "dayz",
		platform: "PC",
		region: "NA",
		players: 58,
		cap: 70,
		tags: ["Low loot", "Night raids"],
		style: "Hardcore",
		blurb: "The coast is loud. The inland stashes are why people stay.",
		rating: "4.7"
	}
];
var LFG = [
	{
		id: "lfg-1",
		identityId: "koba_mara",
		listingId: "srv-iron",
		need: "Duo for the harbor puzzle. Mics on, no random door camp."
	},
	{
		id: "lfg-2",
		identityId: "koba_dex",
		listingId: "srv-rig",
		need: "Three for oil. Bring satchels, not a speech."
	},
	{
		id: "lfg-3",
		identityId: "koba_ysolde",
		listingId: "srv-north",
		need: "NORTHLINE is recruiting one more for the ice war."
	},
	{
		id: "lfg-4",
		identityId: "koba_nora",
		listingId: "srv-black",
		need: "Quiet inland run. I have the route, I need a second rifle."
	}
];
var BOUNTIES = [
	{
		id: "b-harbor",
		title: "Harbor headshots",
		game: "Rust Console",
		reward: 40,
		window: "Ends this wipe",
		detail: "Five headshots on IRONWAKE Harbor."
	},
	{
		id: "b-night",
		title: "Cherno night",
		game: "DayZ",
		reward: 25,
		window: "Ends in 6 days",
		detail: "Survive one full night on Cherno Line without a clinic."
	},
	{
		id: "b-blood",
		title: "First blood",
		game: "Clan war",
		reward: 60,
		window: "While a war is live",
		detail: "Your clan draws first blood in a declared war."
	}
];
var PLAYER_META = {
	koba_mara: {
		region: "NA",
		dayzScore: 1720,
		achievements: [{
			id: "a1",
			name: "Harbor regular",
			detail: "Thirty sessions on IRONWAKE.",
			rare: false
		}, {
			id: "a2",
			name: "Astro",
			detail: "Season mark for form that kept rising.",
			rare: true
		}]
	},
	koba_harrow: {
		region: "NA",
		dayzScore: 1804,
		achievements: [{
			id: "a3",
			name: "Clan lead",
			detail: "IRONWAKE roster held through a wipe.",
			rare: false
		}]
	},
	koba_dex: {
		region: "EU",
		dayzScore: 1696,
		achievements: [{
			id: "a4",
			name: "Warned, still queued",
			detail: "One warning on file. Still on the ladder.",
			rare: false
		}]
	},
	koba_nora: {
		region: "NA",
		dayzScore: 2174,
		achievements: [{
			id: "a5",
			name: "Ranked",
			detail: "Top of the current board.",
			rare: true
		}, {
			id: "a6",
			name: "Unattached",
			detail: "No clan. Still the score to beat.",
			rare: false
		}]
	},
	koba_ysolde: {
		region: "EU",
		dayzScore: 1992,
		achievements: [{
			id: "a7",
			name: "Ice lead",
			detail: "NORTHLINE still answers.",
			rare: false
		}]
	}
};
function metaFor(id, fallbackScore) {
	return PLAYER_META[id] ?? {
		region: "NA",
		dayzScore: fallbackScore,
		achievements: []
	};
}
function scoreFor(id, base, game) {
	if (game === "dayz") return metaFor(id, base).dayzScore;
	return base;
}
var WIPE = {
	"srv-iron": {
		wiped: "14h ago",
		next: "6d",
		groups: "8",
		gather: "1.5x"
	},
	"srv-rig": {
		wiped: "2d ago",
		next: "5d",
		groups: "4",
		gather: "2x"
	},
	"srv-north": {
		wiped: "6h ago",
		next: "13d",
		groups: "No cap",
		gather: "1x"
	},
	"srv-salt": {
		wiped: "9d ago",
		next: "21d",
		groups: "4",
		gather: "1x"
	},
	"srv-cherno": {
		wiped: "1d ago",
		next: "Tonight",
		groups: "3",
		gather: "1x"
	},
	"srv-black": {
		wiped: "4h ago",
		next: "2d",
		groups: "2",
		gather: "Low"
	}
};
function wipeFor(id) {
	return WIPE[id] ?? {
		wiped: "Unknown",
		next: "Unposted",
		groups: "Any",
		gather: "1x"
	};
}
var WIPE_EVENTS = [
	{
		id: "ev-iron",
		listingId: "srv-iron",
		title: "IRONWAKE wipe night",
		when: "Fri 20:00 NA",
		cap: 40,
		filled: 28
	},
	{
		id: "ev-rig",
		listingId: "srv-rig",
		title: "Rig 19 puzzle hour",
		when: "Sat 18:00 NA",
		cap: 12,
		filled: 9
	},
	{
		id: "ev-cherno",
		listingId: "srv-cherno",
		title: "Cherno night run",
		when: "Sun 21:00 EU",
		cap: 8,
		filled: 5
	}
];
var CLIPS = [
	{
		id: "clip-harbor",
		listingId: "srv-iron",
		identityId: "koba_mara",
		title: "Harbor door camp",
		length: "0:18"
	},
	{
		id: "clip-rig",
		listingId: "srv-rig",
		identityId: "koba_harrow",
		title: "Oil timer",
		length: "0:12"
	},
	{
		id: "clip-coast",
		listingId: "srv-black",
		identityId: "koba_nora",
		title: "Coast shot",
		length: "0:21"
	},
	{
		id: "clip-ice",
		listingId: "srv-north",
		identityId: "koba_ysolde",
		title: "Ice push",
		length: "0:16"
	}
];
var PARTIES = [
	{
		id: "pty-1",
		name: "Harbor duo",
		gameId: "rust",
		region: "NA",
		mic: "on",
		size: 2,
		filled: 1,
		hours: "night",
		listingId: "srv-iron"
	},
	{
		id: "pty-2",
		name: "Rig quad",
		gameId: "rust",
		region: "NA",
		mic: "on",
		size: 4,
		filled: 3,
		hours: "night",
		listingId: "srv-rig"
	},
	{
		id: "pty-3",
		name: "Ice line",
		gameId: "rust",
		region: "EU",
		mic: "on",
		size: 3,
		filled: 2,
		hours: "day",
		listingId: "srv-north"
	},
	{
		id: "pty-4",
		name: "Salt builders",
		gameId: "rust",
		region: "OCE",
		mic: "off",
		size: 4,
		filled: 2,
		hours: "day",
		listingId: "srv-salt"
	},
	{
		id: "pty-5",
		name: "Cherno clinic",
		gameId: "dayz",
		region: "EU",
		mic: "on",
		size: 2,
		filled: 1,
		hours: "night",
		listingId: "srv-cherno"
	},
	{
		id: "pty-6",
		name: "Black coast",
		gameId: "dayz",
		region: "NA",
		mic: "on",
		size: 3,
		filled: 2,
		hours: "night",
		listingId: "srv-black"
	}
];
function CompetePage({ viewer, identities, clans, bounties, onChallenge, onWar, onStandDown, onBounty }) {
	const rivals = viewer.rivals.map((id) => identities.find((identity) => identity.id === id)).filter((identity) => Boolean(identity));
	const mine = clans.find((clan) => clan.id === viewer.clanId);
	const foe = mine?.atWarWith ? clans.find((clan) => clan.id === mine.atWarWith) : void 0;
	const others = clans.filter((clan) => clan.id !== mine?.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "Compete"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "Rivals, bounties, and clan wars. A confirmed action shows up on your activity feed."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-bg-elevated p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Rivals"
						}),
						rivals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "No rivals on this identity."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 grid gap-4",
							children: rivals.map((rival) => {
								const gap = rival.score - viewer.score;
								const span = Math.max(viewer.score, rival.score, 1);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "border-b border-border pb-4 last:border-b-0 last:pb-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-baseline justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm",
												children: rival.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-xs tabular-nums text-muted",
												children: gap > 0 ? `ahead ${gap}` : gap < 0 ? `behind ${-gap}` : "even"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 grid gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												label: "You",
												value: viewer.score / span
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												label: rival.handle,
												value: rival.score / span
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-muted",
											children: gap > 0 ? `${gap} points closes it.` : gap < 0 ? `You lead by ${-gap}.` : "Scores are level."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											className: "mt-2",
											variant: "primary",
											onClick: () => onChallenge(rival.handle),
											children: ["Challenge ", rival.handle]
										})
									]
								}, rival.id);
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-bg-elevated p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: "Clan war"
							}), mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								tone: "cyan",
								children: clanTier(mine.memberIds.length)
							}) : null]
						}),
						!mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "This identity is not on a roster."
						}) : null,
						mine && !foe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [mine.name, " is not at war."]
						}) : null,
						mine && foe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									mine.name,
									" against ",
									foe.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-3",
								onClick: onStandDown,
								children: "Stand down"
							})]
						}) : null,
						mine && !foe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 grid gap-2",
							children: others.map((clan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => onWar(clan.name),
								children: ["Declare on ", clan.name]
							}) }, clan.id))
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium",
				children: "Bounties"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-3 lg:grid-cols-3",
				children: BOUNTIES.map((bounty) => {
					const on = bounties.includes(bounty.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-3xl border border-border bg-bg-elevated p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: bounty.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Chip, {
									tone: "warn",
									children: [bounty.reward, " coins"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: bounty.detail
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-mono text-xs text-faint",
								children: [
									bounty.game,
									" · ",
									bounty.window
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-3",
								variant: on ? "primary" : "ghost",
								onClick: () => onBounty(bounty.id),
								children: on ? "Entered" : "Enter bounty"
							})
						]
					}, bounty.id);
				})
			})] })
		]
	});
}
function Bar({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[4.5rem_minmax(0,1fr)] items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "h-1 overflow-hidden rounded-sm bg-bg-subtle",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block h-1 bg-ok",
				style: { width: `${Math.round(Math.max(0, Math.min(1, value)) * 100)}%` }
			})
		})]
	});
}
function CountUp({ value, from }) {
	const origin = from ?? value;
	const [n, setN] = (0, import_react.useState)(origin);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || origin === value) {
			setN(value);
			return;
		}
		const started = performance.now();
		let frame = 0;
		const tick = (now) => {
			const p = Math.min(1, (now - started) / 420);
			const eased = 1 - (1 - p) ** 3;
			setN(Math.round(origin + (value - origin) * eased));
			if (p < 1) frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [origin, value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: n.toLocaleString("en-US") });
}
function PulseFrame({ live, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pulse-frame rounded-3xl", live && "is-live", className),
		children
	});
}
function ServerFace({ listing }) {
	const wash = listing.gameId === "dayz" ? "color-mix(in oklab, var(--color-cyan) 16%, var(--color-bg-subtle))" : listing.style === "Hardcore" ? "color-mix(in oklab, var(--color-danger) 14%, var(--color-bg-subtle))" : "color-mix(in oklab, var(--color-ok) 14%, var(--color-bg-subtle))";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-16 items-end rounded-lg border border-border px-3 py-2",
		style: { background: wash },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs text-faint",
			children: listing.game
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: listing.region
		})] })
	});
}
var FACE = [
	"color-mix(in oklab, var(--color-violet) 72%, var(--color-bg))",
	"color-mix(in oklab, var(--color-cyan) 48%, var(--color-bg))",
	"color-mix(in oklab, var(--color-magenta) 58%, var(--color-bg))",
	"color-mix(in oklab, var(--color-ok) 42%, var(--color-bg))",
	"color-mix(in oklab, var(--color-gold) 46%, var(--color-bg))"
];
function PlayerFace({ name, id, size = "md" }) {
	const initials = name.split(" ").filter(Boolean).map((part) => part[0]).slice(0, 2).join("").toUpperCase();
	let hash = 0;
	for (const char of id) hash += char.charCodeAt(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `grid shrink-0 place-items-center rounded-full font-medium text-fg ${size === "lg" ? "h-16 w-16 text-lg" : size === "sm" ? "h-9 w-9 text-xs" : "h-11 w-11 text-sm"}`,
		style: { background: FACE[hash % FACE.length] },
		"aria-hidden": true,
		children: initials
	});
}
var GAMES = [
	{
		id: "all",
		label: "All games"
	},
	{
		id: "rust",
		label: "Rust Console"
	},
	{
		id: "dayz",
		label: "DayZ"
	}
];
var REGIONS = [
	{
		id: "all",
		label: "All regions"
	},
	{
		id: "NA",
		label: "NA"
	},
	{
		id: "EU",
		label: "EU"
	},
	{
		id: "OCE",
		label: "OCE"
	}
];
var STYLES = [
	{
		id: "all",
		label: "Any style"
	},
	{
		id: "Survival",
		label: "Survival"
	},
	{
		id: "Tactical",
		label: "Tactical"
	},
	{
		id: "Social",
		label: "Social"
	},
	{
		id: "Hardcore",
		label: "Hardcore"
	}
];
function DiscoverPage({ identities, query, game, region, style, saved, onQuery, onGame, onRegion, onStyle, onSave, onOpenPlayer }) {
	const [openId, setOpenId] = (0, import_react.useState)(LISTINGS[0]?.id ?? null);
	const [joined, setJoined] = (0, import_react.useState)([]);
	const [playing, setPlaying] = (0, import_react.useState)(null);
	const [mic, setMic] = (0, import_react.useState)("on");
	const [partySize, setPartySize] = (0, import_react.useState)("3");
	const [hours, setHours] = (0, import_react.useState)("night");
	const needle = query.trim().toLowerCase();
	const listings = LISTINGS.filter((listing) => {
		if (game !== "all" && listing.gameId !== game) return false;
		if (region !== "all" && listing.region !== region) return false;
		if (style !== "all" && listing.style !== style) return false;
		if (!needle) return true;
		return `${listing.name} ${listing.tags.join(" ")} ${listing.blurb}`.toLowerCase().includes(needle);
	});
	const people = identities.filter((identity) => {
		if (region !== "all" && metaFor(identity.id, identity.score).region !== region) return false;
		if (!needle) return true;
		return identity.name.toLowerCase().includes(needle) || identity.handle.includes(needle);
	});
	const posts = LFG.filter((post) => listings.some((listing) => listing.id === post.listingId));
	const parties = PARTIES.filter((party) => {
		if (game !== "all" && party.gameId !== game) return false;
		if (region !== "all" && party.region !== region) return false;
		if (party.mic !== mic) return false;
		if (party.size > Number(partySize)) return false;
		if (party.hours !== hours) return false;
		return true;
	}).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "Discover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "Servers, players, and groups looking for one more. Filters stay put while you browse."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-faint",
					children: "Search"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => onQuery(event.target.value),
					placeholder: "Server, tag, or player",
					className: "h-11 rounded-lg border border-border bg-bg-elevated px-3 text-sm placeholder:text-faint"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterRow, {
				label: "Game",
				options: GAMES,
				value: game,
				onChange: onGame
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterRow, {
				label: "Region",
				options: REGIONS,
				value: region,
				onChange: onRegion
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterRow, {
				label: "Style",
				options: STYLES,
				value: style,
				onChange: onStyle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Squad match"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Three open parties that fit the game, region, mic, hours, and group size."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2 overflow-x-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Mic on",
								on: mic === "on",
								onClick: () => setMic("on")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Mic off",
								on: mic === "off",
								onClick: () => setMic("off")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Night",
								on: hours === "night",
								onClick: () => setHours("night")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Day",
								on: hours === "day",
								onClick: () => setHours("day")
							}),
							[
								"2",
								"3",
								"4"
							].map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: `${size} max`,
								on: partySize === size,
								onClick: () => setPartySize(size)
							}, size))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 grid gap-2 sm:grid-cols-3",
						children: [parties.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No party fits that read."
						}) : null, parties.map((party) => {
							const where = LISTINGS.find((listing) => listing.id === party.listingId);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-2xl bg-bg p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm",
										children: party.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-xs text-ok",
										children: [
											party.filled,
											"/",
											party.size,
											" ready"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted",
										children: [
											where?.name,
											" · ",
											party.region,
											" · ",
											party.hours
										]
									})
								]
							}, party.id);
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-mono text-xs tracking-widest text-faint uppercase",
					children: "Wipe night"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 md:grid-cols-3",
					children: WIPE_EVENTS.map((event) => {
						const where = LISTINGS.find((listing) => listing.id === event.listingId);
						const inEvent = joined.includes(event.id);
						const count = event.filled + (inEvent ? 1 : 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-3xl border border-border bg-bg-elevated p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: event.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										event.when,
										" · ",
										where?.name
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-mono text-xs text-ok",
									children: [
										count,
										"/",
										event.cap
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: inEvent ? "ghost" : "primary",
									className: "mt-3 w-full",
									onClick: () => setJoined((current) => current.includes(event.id) ? current.filter((id) => id !== event.id) : [...current, event.id]),
									children: inEvent ? "Leave event" : "Join"
								})
							]
						}, event.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [listings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No server matches those filters."
					}) : null, listings.map((listing) => {
						const open = openId === listing.id;
						const kept = saved.includes(listing.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: `card-lift rounded-3xl border bg-bg-elevated p-3 ${open ? "border-cyan" : "border-border"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOpenId(open ? null : listing.id),
								className: "w-full text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServerFace, { listing }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: listing.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-xs tabular-nums text-ok",
											children: [
												listing.players,
												"/",
												listing.cap,
												" online"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-xs text-muted",
										children: [
											"Wiped ",
											wipeFor(listing.id).wiped,
											" · next ",
											wipeFor(listing.id).next,
											" · groups ",
											wipeFor(listing.id).groups,
											" · ",
											wipeFor(listing.id).gather
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted",
										children: [
											listing.platform,
											" · ",
											listing.style,
											" · ",
											listing.rating
										]
									})
								]
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: listing.blurb
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-2",
										children: listing.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: tag }, tag))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: kept ? "primary" : "ghost",
										onClick: () => onSave(listing.id),
										children: kept ? "Saved" : "Save listing"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipRow, {
										listingId: listing.id,
										identities,
										playing,
										onPlay: setPlaying
									})
								]
							}) : null]
						}, listing.id);
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid content-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-3xl border border-border bg-bg-elevated p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Looking for group"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 grid",
							children: posts.map((post) => {
								const who = identities.find((identity) => identity.id === post.identityId);
								const where = LISTINGS.find((listing) => listing.id === post.listingId);
								if (!who || !where) return null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-b border-border py-3 last:border-b-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onOpenPlayer(who.id),
										className: "min-h-11 text-left",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm",
												children: who.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted",
												children: post.need
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 font-mono text-xs text-cyan",
												children: where.name
											})
										]
									})
								}, post.id);
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-3xl border border-border bg-bg-elevated p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Players"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-2 grid",
							children: [people.map((identity) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-border last:border-b-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => onOpenPlayer(identity.id),
									className: "flex min-h-11 w-full items-baseline justify-between gap-3 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm",
										children: identity.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-faint",
										children: metaFor(identity.id, identity.score).region
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs tabular-nums",
										children: identity.score
									})]
								})
							}, identity.id)), people.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "py-2 text-sm text-muted",
								children: "No players in that region."
							}) : null]
						})]
					})]
				})]
			})
		]
	});
}
function Choice({ label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `min-h-11 shrink-0 rounded-full px-3 text-sm ${on ? "fire-btn" : "bg-bg text-muted"}`,
		children: label
	});
}
function ClipRow({ listingId, identityId, identities, playing, onPlay }) {
	const clips = CLIPS.filter((clip) => listingId ? clip.listingId === listingId : clip.identityId === identityId);
	if (clips.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-2",
		children: clips.map((clip) => {
			const who = identities.find((identity) => identity.id === clip.identityId);
			const on = playing === clip.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onPlay(on ? null : clip.id),
				className: `clip-play relative flex min-h-16 w-full items-center justify-between overflow-hidden rounded-2xl px-3 text-left ${on ? "is-on" : ""}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm",
					children: clip.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-xs text-muted",
					children: [
						who?.name,
						" · ",
						clip.length
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-ok",
					children: on ? "Playing" : "Play"
				})]
			}) }, clip.id);
		})
	});
}
function FilterRow({ label, options, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 overflow-x-auto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 font-mono text-xs text-faint",
			children: label
		}), options.map((option) => {
			const on = option.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => onChange(option.id),
				className: `min-h-11 shrink-0 rounded-lg border px-3 text-sm ${on ? "border-fg bg-fg text-bg" : "border-border text-muted"}`,
				children: option.label
			}, option.id);
		})]
	});
}
var KB = 1024;
var MB = 1048576;
var TYPE_LABEL = {
	"image/png": "PNG",
	"image/gif": "GIF",
	"image/jpeg": "JPG",
	"video/webm": "WebM",
	"video/mp4": "MP4",
	"audio/mpeg": "MP3",
	"audio/ogg": "OGG"
};
var TYPE_EXT = {
	"image/png": ".png",
	"image/gif": ".gif",
	"image/jpeg": ".jpg,.jpeg",
	"video/webm": ".webm",
	"video/mp4": ".mp4",
	"audio/mpeg": ".mp3",
	"audio/ogg": ".ogg"
};
function acceptFor(types) {
	const extras = types.flatMap((type) => (TYPE_EXT[type] ?? "").split(",").filter(Boolean));
	return [...types, ...extras].join(",");
}
function slot(input) {
	const square = input.square ?? false;
	return {
		id: input.id,
		label: input.label,
		accept: acceptFor(input.types),
		types: input.types,
		media: input.media ?? "image",
		minWidth: input.minWidth ?? null,
		maxWidth: input.maxWidth ?? null,
		minHeight: input.minHeight ?? null,
		maxHeight: input.maxHeight ?? null,
		minBytes: input.minBytes,
		maxBytes: input.maxBytes,
		minSeconds: input.minSeconds ?? null,
		maxSeconds: input.maxSeconds ?? null,
		square,
		aspect: square ? 1 : input.aspect ?? null
	};
}
var PNG_GIF = ["image/png", "image/gif"];
var ASTRO_SPECS = [
	{
		id: "avatar-frame",
		group: "decoration",
		groupLabel: "Profile decoration",
		name: "Avatar frame",
		where: "Draws on top of the profile photo wherever that photo shows.",
		width: 288,
		height: 288,
		canvas: "288 × 288",
		formats: "PNG or GIF, transparent",
		limit: "Square. Center hole about 148 px stays empty.",
		make: "Draw the frame in the outer ring. The photo is a circle in the center, about 148 px across. Leave that hole empty.",
		avoid: "Do not fill the center, and do not run type across the face.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "frame",
			label: "Frame",
			types: PNG_GIF,
			minWidth: 256,
			maxWidth: 288,
			minHeight: 256,
			maxHeight: 288,
			minBytes: 2 * KB,
			maxBytes: MB,
			square: true
		})]
	},
	{
		id: "profile-effect",
		group: "decoration",
		groupLabel: "Profile decoration",
		name: "Profile effect",
		where: "Plays once across the whole profile card when someone opens it.",
		width: 960,
		height: 540,
		canvas: "960 × 540",
		formats: "GIF or WebM",
		limit: "16:9. Plays once. No audio.",
		make: "Animate the full card. Keep the middle band light so the name and bio stay readable.",
		avoid: "No endless loop, no solid shape over the name, no audio.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "effect",
			label: "Effect",
			types: ["image/gif", "video/webm"],
			media: "visual",
			minWidth: 960,
			maxWidth: 1920,
			minHeight: 540,
			maxHeight: 1080,
			minBytes: 8 * KB,
			maxBytes: 8 * MB,
			minSeconds: .5,
			maxSeconds: 6,
			aspect: 16 / 9
		})]
	},
	{
		id: "nameplate",
		group: "decoration",
		groupLabel: "Profile decoration",
		name: "Nameplate",
		where: "Sits behind the display name in member lists, DMs, and voice.",
		width: 320,
		height: 96,
		canvas: "320 × 96",
		formats: "PNG or GIF",
		limit: "Same shape as 320 × 96. GIF loop under 4 seconds.",
		make: "Art goes behind the name. Keep the left 72 px quieter so the avatar still reads.",
		avoid: "No tiny type. It also shows about 32 px tall.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "plate",
			label: "Nameplate",
			types: PNG_GIF,
			minWidth: 320,
			maxWidth: 640,
			minHeight: 96,
			maxHeight: 192,
			minBytes: KB,
			maxBytes: 500 * KB,
			aspect: 320 / 96
		})]
	},
	{
		id: "animated-avatar",
		group: "profile",
		groupLabel: "Profile and client",
		name: "Animated avatar",
		where: "The profile photo itself. Astro players can equip a GIF.",
		width: 512,
		height: 512,
		canvas: "512 × 512",
		formats: "GIF",
		limit: "Square. Subject stays inside the center 80%.",
		make: "KOBA crops a circle. Keep the subject inside the center 80%.",
		avoid: "Corners get cut off. JPG will not animate.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "avatar",
			label: "Avatar",
			types: ["image/gif"],
			minWidth: 256,
			maxWidth: 512,
			minHeight: 256,
			maxHeight: 512,
			minBytes: 4 * KB,
			maxBytes: 8 * MB,
			square: true
		})]
	},
	{
		id: "profile-banner",
		group: "profile",
		groupLabel: "Profile and client",
		name: "Profile banner",
		where: "Wide image at the top of the profile card.",
		width: 680,
		height: 240,
		canvas: "680 × 240",
		formats: "PNG, JPG, or GIF",
		limit: "Same shape as 680 × 240. Avatar covers the bottom-left.",
		make: "Keep the subject in the upper two-thirds. The avatar covers the bottom-left.",
		avoid: "Do not put type or a face along the bottom edge.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "banner",
			label: "Banner",
			types: [
				"image/png",
				"image/jpeg",
				"image/gif"
			],
			minWidth: 680,
			maxWidth: 1360,
			minHeight: 240,
			maxHeight: 480,
			minBytes: 4 * KB,
			maxBytes: 8 * MB,
			aspect: 680 / 240
		})]
	},
	{
		id: "profile-theme",
		group: "profile",
		groupLabel: "Profile and client",
		name: "Profile theme",
		where: "Recolors the profile card behind the banner and bio.",
		width: null,
		height: null,
		canvas: "Two hex colors",
		formats: "No image",
		limit: "Two 6-digit hex colors in the detail.",
		make: "KOBA paints a left-to-right gradient. List both hex codes in the detail.",
		avoid: "Both colors must stay readable under light text (#e8edf2).",
		minCount: 0,
		maxCount: 0,
		slots: []
	},
	{
		id: "client-theme",
		group: "profile",
		groupLabel: "Profile and client",
		name: "Client theme",
		where: "Recolors the app for that player: accent on actions, surface on cards.",
		width: null,
		height: null,
		canvas: "Accent + surface",
		formats: "Two hex colors",
		limit: "No image. Two 6-digit hex colors in the detail.",
		make: "Accent is buttons and the active tab. Surface is cards. List both hex codes.",
		avoid: "Accent has to show on near-black (#07080b).",
		minCount: 0,
		maxCount: 0,
		slots: []
	},
	{
		id: "home-icon",
		group: "profile",
		groupLabel: "Profile and client",
		name: "Home icon",
		where: "Replaces the app icon on a phone home screen for that player.",
		width: 1024,
		height: 1024,
		canvas: "1024 × 1024",
		formats: "PNG",
		limit: "Square. KOBA masks a squircle.",
		make: "KOBA masks a squircle. Keep the mark inside the center 80%.",
		avoid: "No thin lines, no edge transparency, no type smaller than 80 px.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "icon",
			label: "Icon",
			types: ["image/png"],
			minWidth: 512,
			maxWidth: 1024,
			minHeight: 512,
			maxHeight: 1024,
			minBytes: 4 * KB,
			maxBytes: 2 * MB,
			square: true
		})]
	},
	{
		id: "server-look",
		group: "profile",
		groupLabel: "Profile and client",
		name: "Server look",
		where: "A second avatar, banner, and bio used in one server only.",
		width: null,
		height: null,
		canvas: "512² + 680 × 240",
		formats: "PNG or GIF, plus a bio",
		limit: "Avatar and banner are separate files. Bio stays in the detail, 190 characters or less.",
		make: "Ship both files. Avatar follows the animated-avatar rules. Banner follows the profile-banner rules.",
		avoid: "One square cannot be both the avatar and the banner.",
		minCount: 2,
		maxCount: 2,
		slots: [slot({
			id: "server-avatar",
			label: "Avatar",
			types: PNG_GIF,
			minWidth: 256,
			maxWidth: 512,
			minHeight: 256,
			maxHeight: 512,
			minBytes: 2 * KB,
			maxBytes: 8 * MB,
			square: true
		}), slot({
			id: "server-banner",
			label: "Banner",
			types: [
				"image/png",
				"image/jpeg",
				"image/gif"
			],
			minWidth: 680,
			maxWidth: 1360,
			minHeight: 240,
			maxHeight: 480,
			minBytes: 4 * KB,
			maxBytes: 8 * MB,
			aspect: 680 / 240
		})]
	},
	{
		id: "entrance-sound",
		group: "chat",
		groupLabel: "Chat and voice",
		name: "Entrance sound",
		where: "Plays once in the voice channel when the player joins.",
		width: null,
		height: null,
		canvas: "Audio · 0.5–5 s",
		formats: "MP3 or OGG",
		limit: "256 kbps. A short sting, not a music bed.",
		make: "A short sting. It should finish as the player lands in the channel.",
		avoid: "No music beds, no clipping, nothing past 5 seconds.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "sting",
			label: "Sound",
			types: ["audio/mpeg", "audio/ogg"],
			media: "audio",
			minBytes: 4 * KB,
			maxBytes: 512 * KB,
			minSeconds: .5,
			maxSeconds: 5
		})]
	},
	{
		id: "burst-reaction",
		group: "chat",
		groupLabel: "Chat and voice",
		name: "Burst reaction",
		where: "An oversized reaction that plays across a message.",
		width: 128,
		height: 128,
		canvas: "128 × 128",
		formats: "GIF, transparent",
		limit: "Square. Loop between 1.2 and 2.0 seconds. Must read at 32 px.",
		make: "It also has to read at 32 px in the reaction row. Use a bold silhouette.",
		avoid: "No fine detail and no opaque background.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "burst",
			label: "Reaction",
			types: ["image/gif"],
			minWidth: 96,
			maxWidth: 128,
			minHeight: 96,
			maxHeight: 128,
			minBytes: KB,
			maxBytes: 256 * KB,
			square: true
		})]
	},
	{
		id: "call-background",
		group: "chat",
		groupLabel: "Chat and voice",
		name: "Call background",
		where: "Replaces the room behind the player on a camera call.",
		width: 1920,
		height: 1080,
		canvas: "1920 × 1080",
		formats: "PNG, JPG, or MP4 (H.264)",
		limit: "16:9. Video is 1–10 seconds. Leave the center third clear.",
		make: "Put scenery at the edges. The face sits in the center third.",
		avoid: "No vertical video and no type in the center.",
		minCount: 1,
		maxCount: 1,
		slots: [slot({
			id: "room",
			label: "Background",
			types: [
				"image/png",
				"image/jpeg",
				"video/mp4"
			],
			media: "visual",
			minWidth: 1280,
			maxWidth: 1920,
			minHeight: 720,
			maxHeight: 1080,
			minBytes: 8 * KB,
			maxBytes: 8 * MB,
			minSeconds: 1,
			maxSeconds: 10,
			aspect: 16 / 9
		})]
	},
	{
		id: "sticker-pack",
		group: "chat",
		groupLabel: "Chat and voice",
		name: "Sticker pack",
		where: "Sent inside a DM. Each sticker is its own file in the pack.",
		width: 320,
		height: 320,
		canvas: "320 × 320",
		formats: "PNG or GIF, transparent",
		limit: "4 to 8 stickers. Each must read at 32 px.",
		make: "One file per sticker. Use a bold shape that still reads at 32 px in the picker. Put the sticker names in the detail.",
		avoid: "No opaque backgrounds and no type smaller than 40 px.",
		minCount: 4,
		maxCount: 8,
		slots: [slot({
			id: "sticker",
			label: "Sticker",
			types: PNG_GIF,
			minWidth: 160,
			maxWidth: 320,
			minHeight: 160,
			maxHeight: 320,
			minBytes: KB,
			maxBytes: 512 * KB,
			square: true
		})]
	}
];
var SPEC_BY_ID = Object.fromEntries(ASTRO_SPECS.map((spec) => [spec.id, spec]));
function specFor(id) {
	return SPEC_BY_ID[id];
}
var ASTRO_PRICE = "$5.95";
function formatBytes(bytes) {
	if (bytes >= MB) return `${trimNumber(bytes / MB)} MB`;
	if (bytes >= KB) return `${trimNumber(bytes / KB)} KB`;
	return `${bytes} B`;
}
function trimNumber(value) {
	if (value >= 10) return String(Math.round(value));
	const rounded = Math.round(value * 10) / 10;
	return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
}
function formatSeconds(value) {
	return Number.isInteger(value) ? `${value} s` : `${value.toFixed(1)} s`;
}
function edgeSize(slotSpec, edge) {
	const width = edge === "min" ? slotSpec.minWidth : slotSpec.maxWidth;
	const height = edge === "min" ? slotSpec.minHeight : slotSpec.maxHeight;
	const bytes = formatBytes(edge === "min" ? slotSpec.minBytes : slotSpec.maxBytes);
	const seconds = edge === "min" ? slotSpec.minSeconds : slotSpec.maxSeconds;
	return `${width == null || height == null ? "audio" : slotSpec.square ? `${width} px square` : `${width} × ${height}`} · ${bytes}${seconds == null ? "" : slotSpec.media === "audio" ? ` · ${formatSeconds(seconds)}` : ` · video ${formatSeconds(seconds)}`}`;
}
function sizeWindow(spec) {
	if (spec.slots.length === 0) return {
		min: "Two hex colors",
		max: "Two hex colors, no image"
	};
	if (spec.slots.length === 1 && spec.maxCount > 1) {
		const only = spec.slots[0];
		return {
			min: `${spec.minCount} files · ${edgeSize(only, "min")} each`,
			max: `${spec.maxCount} files · ${edgeSize(only, "max")} each`
		};
	}
	if (spec.slots.length === 1) return {
		min: edgeSize(spec.slots[0], "min"),
		max: edgeSize(spec.slots[0], "max")
	};
	return {
		min: spec.slots.map((item) => `${item.label} ${edgeSize(item, "min")}`).join(" · "),
		max: spec.slots.map((item) => `${item.label} ${edgeSize(item, "max")}`).join(" · ")
	};
}
var EXT_TYPE = {
	png: "image/png",
	gif: "image/gif",
	jpg: "image/jpeg",
	jpeg: "image/jpeg",
	webm: "video/webm",
	mp4: "video/mp4",
	mp3: "audio/mpeg",
	ogg: "audio/ogg"
};
function fileType(file) {
	if (file.type) return file.type;
	return EXT_TYPE[file.name.split(".").pop()?.toLowerCase() ?? ""] ?? "";
}
function typeLabel(type) {
	return TYPE_LABEL[type] ?? type;
}
function auditOne(slotSpec, file) {
	if (!slotSpec.types.includes(file.type)) {
		const accepted = slotSpec.types.map(typeLabel).join(" or ");
		return `${file.name} is not an accepted file. Use ${accepted}.`;
	}
	if (slotSpec.minWidth != null && slotSpec.maxWidth != null && slotSpec.minHeight != null && slotSpec.maxHeight != null) {
		if (file.width == null || file.height == null) return `${file.name} has no pixel size.`;
		if (slotSpec.square && file.width !== file.height) return `${file.name} is ${file.width} × ${file.height}. It must be square.`;
		if (file.width < slotSpec.minWidth || file.height < slotSpec.minHeight) return `${file.name} is ${file.width} × ${file.height}. Minimum is ${edgeSize(slotSpec, "min")}.`;
		if (file.width > slotSpec.maxWidth || file.height > slotSpec.maxHeight) return `${file.name} is ${file.width} × ${file.height}. Maximum is ${edgeSize(slotSpec, "max")}.`;
		if (slotSpec.aspect && !slotSpec.square) {
			const got = file.width / file.height;
			if (Math.abs(got - slotSpec.aspect) / slotSpec.aspect > .04) return `${file.name} is ${file.width} × ${file.height}. Keep the same shape as ${slotSpec.maxWidth} × ${slotSpec.maxHeight}.`;
		}
	}
	if (file.bytes < slotSpec.minBytes) return `${file.name} is ${formatBytes(file.bytes)}. Minimum is ${formatBytes(slotSpec.minBytes)}.`;
	if (file.bytes > slotSpec.maxBytes) return `${file.name} is ${formatBytes(file.bytes)}. Maximum is ${formatBytes(slotSpec.maxBytes)}.`;
	if ((slotSpec.media === "audio" || slotSpec.media === "video" || slotSpec.media === "visual" && file.type.startsWith("video/")) && slotSpec.minSeconds != null && slotSpec.maxSeconds != null) {
		if (file.seconds == null || Number.isNaN(file.seconds)) return `${file.name} has no duration.`;
		if (file.seconds < slotSpec.minSeconds) return `${file.name} is ${formatSeconds(file.seconds)}. Minimum is ${formatSeconds(slotSpec.minSeconds)}.`;
		if (file.seconds > slotSpec.maxSeconds) return `${file.name} is ${formatSeconds(file.seconds)}. Maximum is ${formatSeconds(slotSpec.maxSeconds)}.`;
	}
	return null;
}
function auditUploads(spec, files) {
	if (spec.slots.length === 0) return null;
	const min = spec.slots.length === 1 ? spec.minCount : spec.slots.length;
	const max = spec.slots.length === 1 ? spec.maxCount : spec.slots.length;
	if (files.length < min || files.length > max) {
		if (min === 1 && max === 1) return "Upload 1 file inside the minimum and maximum.";
		if (min === max) return `Upload ${min} files. You added ${files.length}.`;
		return `Upload ${min} to ${max} files. You added ${files.length}.`;
	}
	if (spec.slots.length === 1) {
		for (const file of files) {
			const issue = auditOne(spec.slots[0], file);
			if (issue) return issue;
		}
		return null;
	}
	for (let index = 0; index < spec.slots.length; index += 1) {
		const issue = auditOne(spec.slots[index], files[index]);
		if (issue) return `${spec.slots[index].label}: ${issue}`;
	}
	return null;
}
function themeError(spec, detail) {
	if (spec.slots.length > 0) return null;
	if ((detail.match(/#(?:[0-9a-fA-F]{6})\b/g) ?? []).length < 2) return "List two hex colors in the detail, like #7CFF4F and #101614.";
	return null;
}
var SEED_ACCOUNTS = {
	koba_mara: {
		verified: true,
		business: true,
		businessName: "Harbor Supply"
	},
	koba_harrow: {
		verified: true,
		business: false
	},
	koba_dex: {
		verified: false,
		business: true,
		businessName: "Hollow Kits"
	},
	koba_nora: {
		verified: true,
		business: false
	},
	koba_ysolde: {
		verified: false,
		business: false
	}
};
var SEED_PRODUCTS = [
	{
		id: "prd-harbor",
		sellerId: "koba_mara",
		title: "Harbor ring",
		detail: "A thin wake around the photo. Center hole left empty.",
		price: 30,
		game: "Network",
		kind: "avatar-frame",
		motion: "ring"
	},
	{
		id: "prd-plate",
		sellerId: "koba_mara",
		title: "South road plate",
		detail: "Fire wash behind the name. Left edge stays quiet for the avatar.",
		price: 25,
		game: "Network",
		kind: "nameplate",
		motion: "plate"
	},
	{
		id: "prd-hollow",
		sellerId: "koba_dex",
		title: "Hollow burst",
		detail: "A short loop that reads at reaction size.",
		price: 15,
		game: "Network",
		kind: "burst-reaction",
		motion: "burst"
	},
	{
		id: "prd-clinic",
		sellerId: "koba_dex",
		title: "Clinic wash",
		detail: "A 16:9 room. Scenery stays off the center third.",
		price: 40,
		game: "Network",
		kind: "call-background",
		motion: "banner"
	},
	{
		id: "prd-marks",
		sellerId: "koba_mara",
		title: "Harbor marks",
		detail: "Four marks: Mark, Lane, Hold, Clear. Each is 320 × 320 and readable at 32 px.",
		price: 20,
		game: "Network",
		kind: "sticker-pack",
		motion: "stickers"
	},
	{
		id: "prd-ember",
		sellerId: "koba_mara",
		title: "Ember crown",
		detail: "A looping ring of fire around the portrait. The center stays empty for the photo.",
		price: 45,
		game: "Network",
		kind: "avatar-frame",
		motion: "ring"
	},
	{
		id: "prd-relic",
		sellerId: "koba_dex",
		title: "Relic plate",
		detail: "An orange wash that sweeps the name once a second. The avatar edge stays clear.",
		price: 35,
		game: "Network",
		kind: "nameplate",
		motion: "plate"
	}
];
function money(value) {
	return Math.round(value * 100) / 100;
}
function formatCoins(value) {
	const rounded = money(value);
	return rounded.toLocaleString("en-US", {
		minimumFractionDigits: Number.isInteger(rounded) ? 0 : 2,
		maximumFractionDigits: 2
	});
}
function quote(price, verified) {
	const rate = verified ? .025 : .035;
	const fee = money(price * rate);
	return {
		rate,
		fee,
		payout: money(price - fee),
		label: verified ? "2.5%" : "3.5%"
	};
}
function accountFor(id, opened) {
	const base = SEED_ACCOUNTS[id] ?? {
		verified: false,
		business: false
	};
	const openedName = opened[id];
	if (!openedName) return base;
	return {
		...base,
		business: true,
		businessName: openedName
	};
}
function readMedia(file, kind) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const element = document.createElement(kind);
		const finish = (ok, value) => {
			URL.revokeObjectURL(url);
			element.removeAttribute("src");
			element.load();
			if (ok && value) resolve(value);
			else reject(/* @__PURE__ */ new Error("unreadable"));
		};
		element.preload = "metadata";
		element.onloadedmetadata = () => {
			const video = element;
			finish(true, {
				width: kind === "video" ? video.videoWidth : null,
				height: kind === "video" ? video.videoHeight : null,
				seconds: element.duration
			});
		};
		element.onerror = () => finish(false);
		element.src = url;
	});
}
async function measureFile(file) {
	const type = fileType(file);
	const base = {
		name: file.name,
		bytes: file.size,
		width: null,
		height: null,
		seconds: null,
		type
	};
	if (type.startsWith("audio/")) {
		const media = await readMedia(file, "audio");
		return {
			...base,
			seconds: media.seconds
		};
	}
	if (type.startsWith("video/")) {
		const media = await readMedia(file, "video");
		return {
			...base,
			width: media.width,
			height: media.height,
			seconds: media.seconds
		};
	}
	if (type.startsWith("image/")) {
		const bitmap = await createImageBitmap(file);
		const width = bitmap.width;
		const height = bitmap.height;
		bitmap.close();
		return {
			...base,
			width,
			height
		};
	}
	throw new Error("unsupported");
}
var GROUPS = [
	{
		id: "all",
		label: "All sizes"
	},
	{
		id: "decoration",
		label: "Profile decoration"
	},
	{
		id: "profile",
		label: "Profile and client"
	},
	{
		id: "chat",
		label: "Chat and voice"
	}
];
function release(rows) {
	for (const row of rows) if (row?.preview) URL.revokeObjectURL(row.preview);
}
function CanvasMark({ spec }) {
	const slot = spec.slots.length === 1 ? spec.slots[0] : null;
	if (!slot?.maxWidth || !slot.maxHeight || !slot.minWidth || !slot.minHeight) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-16 place-items-center rounded-lg border border-dashed border-border bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs text-muted",
			children: spec.canvas
		})
	});
	const scale = Math.min(220 / slot.maxWidth, 64 / slot.maxHeight);
	const maxWidth = Math.max(16, Math.round(slot.maxWidth * scale));
	const maxHeight = Math.max(12, Math.round(slot.maxHeight * scale));
	const minWidth = Math.max(8, Math.round(slot.minWidth * scale));
	const minHeight = Math.max(8, Math.round(slot.minHeight * scale));
	const ranged = slot.minWidth !== slot.maxWidth || slot.minHeight !== slot.maxHeight;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-16 place-items-center rounded-lg bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative border border-ok/50 bg-ok/10",
			style: {
				width: maxWidth,
				height: maxHeight
			},
			children: ranged ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border border-cyan/70",
				style: {
					width: minWidth,
					height: minHeight
				}
			}) : null
		})
	});
}
function MotionPreview({ motion, title }) {
	if (motion === "ring") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "astro-stage",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "astro-ring" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "astro-face",
			children: title.slice(0, 1)
		})]
	});
	if (motion === "plate") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "astro-stage",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "astro-plate flex items-center gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-bg text-xs",
				children: title.slice(0, 1)
			}), title]
		})
	});
	if (motion === "burst") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "astro-stage",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "astro-burst" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative z-10 text-sm",
			children: title
		})]
	});
	if (motion === "banner") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "astro-stage",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "astro-banner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative z-10 text-sm",
			children: title
		})]
	});
	if (motion === "stickers") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "astro-stage",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex gap-2",
			children: [
				"Mk",
				"Ln",
				"Hd",
				"Cl"
			].map((mark, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "astro-sticker",
				style: { animationDelay: `${index * 120}ms` },
				children: mark
			}, mark))
		})
	});
	return null;
}
function VerifiedMark({ verified }) {
	if (verified) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1 rounded-sm border border-cyan/40 px-2 py-1 font-mono text-xs text-cyan",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
			size: 12,
			"aria-hidden": true
		}), "Verified"]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex items-center rounded-sm border border-border px-2 py-1 font-mono text-xs text-muted",
		children: "Unverified"
	});
}
function ShopPage({ viewer, identities, products, opened, onOpenBusiness, onCreate, onBuy, onOpenPlayer, subscribed, owned, equipped, onSubscribe, onEndPass, onEquip }) {
	const standing = accountFor(viewer.id, opened);
	const fee = quote(100, standing.verified);
	const [businessName, setBusinessName] = (0, import_react.useState)("");
	const [businessError, setBusinessError] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("25");
	const [kind, setKind] = (0, import_react.useState)("avatar-frame");
	const [group, setGroup] = (0, import_react.useState)("all");
	const [formError, setFormError] = (0, import_react.useState)("");
	const [flash, setFlash] = (0, import_react.useState)(0);
	const [result, setResult] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [fileEpoch, setFileEpoch] = (0, import_react.useState)(0);
	const rowsRef = (0, import_react.useRef)([]);
	const gen = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		rowsRef.current = rows;
	}, [rows]);
	(0, import_react.useEffect)(() => {
		gen.current += 1;
		setRows([]);
		setBusy(false);
		return () => release(rowsRef.current);
	}, [kind]);
	const priceNumber = Number(price);
	const preview = Number.isFinite(priceNumber) && priceNumber > 0 ? quote(priceNumber, standing.verified) : null;
	const openBusiness = () => {
		const name = businessName.trim();
		if (name.length < 2 || name.length > 32) {
			setBusinessError("Use 2–32 characters.");
			return;
		}
		setBusinessError("");
		onOpenBusiness(name);
		setResult(`${name} can list on the Official shop. Verification did not change.`);
		setFlash((value) => value + 1);
	};
	const spec = specFor(kind);
	const visible = ASTRO_SPECS.filter((item) => group === "all" || item.group === group);
	const bounds = sizeWindow(spec);
	const uploads = rows.filter((row) => row != null);
	const liveIssue = spec.slots.length === 0 ? null : auditUploads(spec, uploads);
	const ingest = async (list, index) => {
		const token = gen.current + 1;
		gen.current = token;
		setBusy(true);
		setFormError("");
		try {
			const measured = await Promise.all(list.map(async (file) => {
				const row = await measureFile(file);
				const preview = row.type.startsWith("image/") ? URL.createObjectURL(file) : null;
				return {
					...row,
					preview
				};
			}));
			if (gen.current !== token) {
				release(measured);
				return;
			}
			setRows((current) => {
				if (index === null) {
					release(current);
					return measured;
				}
				const next = [...current];
				if (next[index]?.preview) URL.revokeObjectURL(next[index].preview);
				next[index] = measured[0];
				return next;
			});
		} catch {
			if (gen.current !== token) return;
			setFormError("That file could not be read. Check the format and export it again.");
		} finally {
			if (gen.current === token) setBusy(false);
		}
	};
	const create = () => {
		const nextTitle = title.trim();
		const nextDetail = detail.trim();
		if (nextTitle.length < 3 || nextTitle.length > 48) {
			setFormError("Title needs 3–48 characters.");
			return;
		}
		if (nextDetail.length < 8 || nextDetail.length > 140) {
			setFormError("Detail needs 8–140 characters.");
			return;
		}
		if (!Number.isInteger(priceNumber) || priceNumber < 1 || priceNumber > 500) {
			setFormError("Price is a whole number of coins, from 1 to 500.");
			return;
		}
		const colors = themeError(spec, nextDetail);
		if (colors) {
			setFormError(colors);
			return;
		}
		if (spec.slots.length > 0) {
			if (busy) {
				setFormError("Still checking the file size.");
				return;
			}
			const issue = auditUploads(spec, uploads);
			if (issue) {
				setFormError(issue);
				return;
			}
		}
		const files = uploads.map((row) => ({
			name: row.name,
			bytes: row.bytes,
			width: row.width,
			height: row.height,
			seconds: row.seconds
		}));
		setFormError("");
		onCreate({
			title: nextTitle,
			detail: nextDetail,
			price: priceNumber,
			kind,
			files
		});
		setTitle("");
		setDetail("");
		release(rows);
		setRows([]);
		setFileEpoch((value) => value + 1);
		setResult(`${nextTitle} is listed. Buyers pay ${formatCoins(priceNumber)}. You receive ${formatCoins(quote(priceNumber, standing.verified).payout)} after the ${fee.label} Astro fee.`);
		setFlash((value) => value + 1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-cyan",
					children: "Official shop"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: "KOBA Astro"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm text-muted",
					children: "Astro is the cosmetic pass. Players equip what they buy. Businesses upload a file between the minimum and the maximum. KOBA does not rescale art."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PulseFrame, {
				live: flash > 0,
				className: "border border-border bg-bg-elevated p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "How a sale works"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 grid gap-3 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Verified accounts get a blue badge. The shop takes 2.5% from the seller." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Unverified accounts have no badge. The shop takes 3.5% from the seller." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The buyer pays the listed price. The fee follows the seller, not the buyer." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Listing is not a verified-player perk. Any business account can create a product, verified or not." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Upload between the minimum and the maximum for that type, then list. The fee is still 2.5% verified or 3.5% unverified." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Astro is ",
							ASTRO_PRICE,
							" a month. Cosmetics can be bought without it. Applying one needs an active pass."
						] })
					]
				})]
			}, flash),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-faint",
							children: "This identity"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm",
							children: [viewer.name, standing.business && standing.businessName ? ` · ${standing.businessName}` : ""]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifiedMark, { verified: standing.verified })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid gap-2 text-sm sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Astro fee"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-mono text-xs",
								children: fee.label
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Can list"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-mono text-xs",
								children: standing.business ? "Yes" : "No"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Coins"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-mono text-xs",
								children: formatCoins(viewer.coins)
							})] })
						]
					}),
					result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-fg",
						role: "status",
						children: result
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-bg-elevated p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Astro pass"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [ASTRO_PRICE, " a month. Each renewal drops 150 coins and unlocks an animated banner for one group. Applying a cosmetic still needs the pass."]
					})] }), subscribed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onEndPass,
						className: "min-h-11 text-sm text-muted",
						children: "End Astro"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "primary",
						onClick: onSubscribe,
						children: ["Start Astro · ", ASTRO_PRICE]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm",
					role: "status",
					children: subscribed ? "Astro is active. The stipend and group banner are armed." : "Astro is not active. Apply stays locked."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "File sizes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Product types for the Official shop. The canvas is the file you export. Select one to build it."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto",
						children: GROUPS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": group === item.id,
							onClick: () => {
								setGroup(item.id);
								const matched = ASTRO_SPECS.filter((specRow) => item.id === "all" || specRow.group === item.id);
								if (!matched.some((specRow) => specRow.id === kind)) setKind(matched[0].id);
							},
							className: `min-h-11 shrink-0 rounded-lg border px-3 text-sm ${group === item.id ? "border-ok text-ok" : "border-border text-muted"}`,
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": kind === item.id,
							onClick: () => setKind(item.id),
							className: `rounded-3xl border p-4 text-left ${kind === item.id ? "border-ok bg-bg-elevated" : "border-border bg-bg-elevated"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-faint",
									children: item.groupLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: item.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 font-mono text-lg text-ok",
									children: item.canvas
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: item.formats
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-mono text-xs text-muted",
									children: ["Min ", sizeWindow(item).min]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: ["Max ", sizeWindow(item).max]
								})
							]
						}, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-faint",
							children: spec.groupLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-base font-medium",
							children: spec.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-2xl text-ok",
							children: spec.canvas
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								spec.formats,
								". ",
								spec.limit,
								"."
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasMark, { spec }),
					spec.slots.length === 1 && spec.slots[0].minWidth !== spec.slots[0].maxWidth ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Outer line is the maximum. Inner line is the minimum."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid gap-3 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Where it shows"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: spec.where
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Minimum"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: bounds.min
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Maximum"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: bounds.max
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "How to make it"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: spec.make
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Do not"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: spec.avoid
							})] })
						]
					})
				]
			}),
			standing.business ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4",
				onSubmit: (event) => {
					event.preventDefault();
					create();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-sm font-medium",
						children: ["List this ", spec.name.toLowerCase()]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							standing.businessName,
							" lists at ",
							fee.label,
							".",
							" ",
							spec.slots.length > 0 ? "The file has to land between the minimum and the maximum. KOBA does not rescale." : "This type has no image. Put two hex colors in the detail.",
							" ",
							standing.verified ? "The blue badge is already on this account." : "This business is unverified, so the higher fee applies."
						]
					}),
					spec.slots.length === 0 ? null : spec.slots.length === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: spec.maxCount > 1 ? `Upload ${spec.minCount} to ${spec.maxCount} files` : "Upload"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: spec.slots[0].accept,
							multiple: spec.maxCount > 1,
							"aria-label": spec.maxCount > 1 ? "Upload sticker files" : "Upload cosmetic file",
							onChange: (event) => {
								const list = event.target.files;
								if (!list?.length) return;
								ingest(Array.from(list), null);
							},
							className: "block w-full text-sm file:mr-3 file:h-11 file:rounded-lg file:border file:border-border file:bg-bg file:px-3 file:text-sm file:text-fg"
						}, `${kind}-${fileEpoch}`)]
					}) : spec.slots.map((slot, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-xs text-faint",
							children: [
								slot.label,
								" · min ",
								slot.minWidth,
								"×",
								slot.minHeight,
								" · max ",
								slot.maxWidth,
								"×",
								slot.maxHeight
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: slot.accept,
							"aria-label": `Upload ${slot.label}`,
							onChange: (event) => {
								const list = event.target.files;
								if (!list?.length) return;
								ingest([list[0]], index);
							},
							className: "block w-full text-sm file:mr-3 file:h-11 file:rounded-lg file:border file:border-border file:bg-bg file:px-3 file:text-sm file:text-fg"
						}, `${kind}-${slot.id}-${fileEpoch}`)]
					}, slot.id)),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Checking size…"
					}) : null,
					uploads.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-3 text-sm text-muted",
						children: [row.preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: row.preview,
							alt: "",
							className: "h-11 w-11 rounded-lg border border-border object-contain"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							row.name,
							" · ",
							row.width && row.height ? `${row.width} × ${row.height}` : "audio",
							" · ",
							formatBytes(row.bytes),
							row.seconds != null ? ` · ${row.seconds.toFixed(1)} s` : ""
						] })]
					}, `${row.name}-${index}`)),
					!busy && uploads.length > 0 && liveIssue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: liveIssue
					}) : null,
					!busy && uploads.length > 0 && !liveIssue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ok",
						children: "In range."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: "Title"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: title,
							onChange: (event) => setTitle(event.target.value),
							className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: "Detail"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: detail,
							onChange: (event) => setDetail(event.target.value),
							className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: "Price in coins"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: price,
							onChange: (event) => setPrice(event.target.value),
							inputMode: "numeric",
							className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm"
						})]
					}),
					preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Buyer pays ",
							formatCoins(priceNumber),
							". You receive ",
							formatCoins(preview.payout),
							". Astro keeps ",
							formatCoins(preview.fee),
							" (",
							preview.label,
							")."
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Enter a price to see the fee."
					}),
					formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: formError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						className: "w-full sm:w-auto",
						children: "List on the Official shop"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 rounded-3xl border border-border bg-bg-elevated p-4",
				onSubmit: (event) => {
					event.preventDefault();
					openBusiness();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Open a business account"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							viewer.name.split(" ")[0],
							" is ",
							standing.verified ? "verified" : "unverified",
							" and not a business yet. Players can buy. Only a business can create products. Your fee stays ",
							fee.label,
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: "Business name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: businessName,
							onChange: (event) => setBusinessName(event.target.value),
							className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm"
						})]
					}),
					businessError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: businessError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						className: "w-full sm:w-auto",
						children: "Open business account"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "KOBA Official shop"
				}), products.map((product) => {
					const seller = identities.find((identity) => identity.id === product.sellerId);
					const sellerAccount = accountFor(product.sellerId, opened);
					const sale = quote(product.price, sellerAccount.verified);
					const own = product.sellerId === viewer.id;
					const short = viewer.coins < product.price;
					const listed = specFor(product.kind);
					const has = owned.includes(product.id);
					const applied = equipped === product.id;
					const cosmetic = product.kind !== "sticker-pack";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-3xl border border-border bg-bg-elevated p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotionPreview, {
								motion: product.motion,
								title: product.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-xs text-faint",
										children: [
											listed.name,
											" · ",
											listed.canvas
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-1 text-base font-medium",
										children: product.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 max-w-xl text-sm text-muted",
										children: product.detail
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-sm text-muted",
										children: [
											"Minimum ",
											sizeWindow(listed).min,
											". Maximum ",
											sizeWindow(listed).max,
											"."
										]
									}),
									product.files?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-2 grid gap-1",
										children: product.files.map((file, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "font-mono text-xs text-muted",
											children: [
												"Uploaded ",
												file.name,
												file.width && file.height ? ` · ${file.width} × ${file.height}` : " · audio",
												" · ",
												formatBytes(file.bytes)
											]
										}, `${file.name}-${index}`))
									}) : null
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-sm tabular-nums",
									children: [formatCoins(product.price), " coins"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => seller && onOpenPlayer(seller.id),
									className: "min-h-11 text-sm text-cyan",
									children: sellerAccount.businessName ?? seller?.name ?? "Seller"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifiedMark, { verified: sellerAccount.verified })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-muted",
								children: [
									"You pay ",
									formatCoins(product.price),
									". Seller receives ",
									formatCoins(sale.payout),
									". Astro fee ",
									sale.label,
									" (",
									formatCoins(sale.fee),
									")."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [
									own ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "This is your listing. Someone else buys it."
									}) : null,
									!own && short ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											"You need ",
											formatCoins(product.price - viewer.coins),
											" more coins."
										]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "primary",
										className: "mt-2",
										disabled: own || short,
										onClick: () => {
											const error = onBuy(product, sellerAccount);
											if (error) {
												setResult(error);
												return;
											}
											setResult(`Bought ${product.title}. You paid ${formatCoins(product.price)}.`);
											setFlash((value) => value + 1);
										},
										children: "Buy"
									}),
									cosmetic && has ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "mt-2 ml-2",
										disabled: !subscribed || applied,
										onClick: () => {
											const ok = onEquip(product.id);
											setResult(ok ? `${product.title} is applied.` : `Start Astro (${ASTRO_PRICE}) before applying cosmetics.`);
											if (ok) setFlash((value) => value + 1);
										},
										children: applied ? "Applied" : "Apply"
									}) : null,
									has && !cosmetic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted",
										children: "This pack is in your stickers. Send them from DMs."
									}) : null
								]
							})
						]
					}, product.id);
				})]
			})
		]
	});
}
var STATUS$1 = {
	clear: "Clear",
	warned: "Warned",
	struck: "Struck",
	under_review: "Review",
	blacklisted: "Banned"
};
function DeskPage({ desk, viewer, identities, groups, servers, feed, audit, products, opened, account, onAct, onOpenBusiness, onOpenPlayer, onShop, onReset }) {
	if (desk === "business") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessDesk, {
		viewer,
		account,
		products: products.filter((product) => product.sellerId === viewer.id),
		feed,
		onOpenBusiness,
		onShop
	});
	if (desk === "mod") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModDesk, {
		identities,
		onAct,
		onOpenPlayer
	});
	if (desk === "admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminDesk, {
		identities,
		groups,
		servers,
		products,
		feed,
		onAct,
		onOpenPlayer
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuperDesk, {
		identities,
		opened,
		audit,
		onAct,
		onOpenPlayer,
		onReset
	});
}
function BusinessDesk({ viewer, account, products, feed, onOpenBusiness, onShop }) {
	const [name, setName] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const fee = quote(100, account.verified);
	const once = products.reduce((sum, product) => sum + quote(product.price, account.verified).payout, 0);
	const sales = feed.filter((row) => row.title.includes("bought") && row.detail.startsWith(viewer.name));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskIntro, {
				kicker: "Business",
				title: account.business ? account.businessName || "Business" : "No business yet",
				body: "Buyers pay the listed price. You receive that price minus the Astro fee. Opening a business does not verify the account.",
				className: "xl:col-span-7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 xl:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Seller fee"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifiedMark, { verified: account.verified })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-3xl font-medium tabular-nums text-ok",
						children: fee.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Verified sellers pay 2.5%. Unverified sellers pay 3.5%."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-xs text-cyan",
						children: [formatCoins(viewer.coins), " coins on hand"]
					})
				]
			}),
			account.business ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 md:col-span-2 xl:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-mono text-xs tracking-widest text-faint uppercase",
							children: "Listings"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onShop,
							className: "min-h-11 rounded-full px-2 text-sm text-cyan",
							children: "Official shop"
						})]
					}),
					products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Nothing listed under this business yet."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid gap-2",
						children: products.map((product) => {
							const sale = quote(product.price, account.verified);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid min-h-16 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl bg-bg-subtle px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm",
										children: product.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-mono text-xs text-faint",
										children: specFor(product.kind).name
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-mono text-xs text-fg",
										children: formatCoins(product.price)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block font-mono text-xs text-ok",
										children: ["You ", formatCoins(sale.payout)]
									})]
								})]
							}, product.id);
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "dash-card grid min-w-0 gap-3 p-4 md:col-span-2 xl:col-span-7",
				onSubmit: (event) => {
					event.preventDefault();
					const trimmed = name.trim();
					if (trimmed.length < 2 || trimmed.length > 32) {
						setError("Use 2–32 characters.");
						return;
					}
					setError("");
					onOpenBusiness(trimmed);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Open a business"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Any account can list. The fee stays ",
							fee.label,
							" because this identity is ",
							account.verified ? "verified" : "unverified",
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: "Business name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							className: "h-11 rounded-2xl border border-border bg-bg px-3 text-sm"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						className: "w-full sm:w-auto",
						children: "Open business account"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 xl:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Payout"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-3xl font-medium tabular-nums",
						children: formatCoins(once)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"If every current listing sold once, after the ",
							fee.label,
							" fee."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3",
						children: [sales.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No sales on this identity yet."
						}) : null, sales.slice(0, 4).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-b border-border/70 py-3 last:border-b-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: row.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: row.detail
							})]
						}, row.id))]
					})
				]
			})
		]
	});
}
function ModDesk({ identities, onAct, onOpenPlayer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskIntro, {
			kicker: "Admin mod",
			title: "Discipline queue",
			body: "Preview seat. Warn and strike write on this fixture. A player can hold one warning. Three strikes puts the profile under review."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Discipline, {
			identities,
			canClear: false,
			canBan: false,
			onAct,
			onOpenPlayer
		})]
	});
}
function AdminDesk({ identities, groups, servers, products, feed, onAct, onOpenPlayer }) {
	const open = identities.filter((identity) => identity.status !== "clear").length;
	const coins = identities.reduce((sum, identity) => sum + identity.coins, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskIntro, {
				kicker: "Admin",
				title: "Network overview",
				body: "Players, groups, servers, and the Official shop. Mod tools on this seat can warn and strike. Clearing a strike stays with superadmin.",
				className: "xl:col-span-12"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Players",
				value: String(identities.length),
				className: "xl:col-span-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Open cases",
				value: String(open),
				className: "xl:col-span-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Servers",
				value: String(servers.length),
				className: "xl:col-span-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Coins",
				value: formatCoins(coins),
				className: "xl:col-span-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 xl:col-span-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-mono text-xs tracking-widest text-faint uppercase",
					children: "Groups"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2",
					children: groups.map((group) => {
						const owner = identities.find((identity) => identity.id === group.ownerId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-h-12 items-center justify-between gap-3 border-b border-border/70 last:border-b-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm",
									children: group.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-faint",
									children: group.tag
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm text-muted",
								children: owner?.name ?? "Unowned"
							})]
						}, group.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 xl:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Servers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2",
						children: servers.map((server) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-h-12 items-center justify-between gap-3 border-b border-border/70 last:border-b-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm",
									children: server.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-faint",
									children: server.game === "DAYZ" ? "DayZ" : "Rust Console"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								tone: server.license === "active" ? "ok" : "danger",
								children: server.license
							})]
						}, server.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-xs text-muted",
						children: [
							products.length,
							" shop listings · ",
							feed.length,
							" feed notes"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-2 xl:col-span-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Discipline, {
					identities,
					canClear: false,
					canBan: false,
					onAct,
					onOpenPlayer
				})
			})
		]
	});
}
function SuperDesk({ identities, opened, audit, onAct, onOpenPlayer, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-1 gap-3 xl:grid-cols-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskIntro, {
				kicker: "Superadmin",
				title: "Fixture control",
				body: "Developer preview seat. Clear a strike, ban, or reset this network. Nothing here leaves the preview.",
				className: "xl:col-span-8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card flex min-w-0 flex-col justify-between gap-3 p-4 xl:col-span-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-widest text-faint uppercase",
					children: "Reset"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Restores identities, the shop, groups, and desks to the fixture."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onReset,
					children: "Reset network"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 xl:col-span-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-mono text-xs tracking-widest text-faint uppercase",
					children: "Fees"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2",
					children: identities.map((identity) => {
						const standing = accountFor(identity.id, opened);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpenPlayer(identity.id),
							className: "flex min-h-12 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
									name: identity.name,
									id: identity.id,
									size: "sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm",
										children: identity.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-faint",
										children: standing.businessName ?? (standing.verified ? "Verified player" : "Unverified player")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-mono text-xs text-ok",
										children: quote(100, standing.verified).label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-mono text-xs text-cyan",
										children: formatCoins(identity.coins)
									})]
								})
							]
						}) }, identity.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "dash-card min-w-0 p-4 xl:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-mono text-xs tracking-widest text-faint uppercase",
					children: "Audit"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2",
					children: audit.slice(0, 8).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-border/70 py-3 last:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: row.action
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								row.actor,
								" · ",
								row.detail
							]
						})]
					}, row.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "xl:col-span-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Discipline, {
					identities,
					canClear: true,
					canBan: true,
					onAct,
					onOpenPlayer
				})
			})
		]
	});
}
function Discipline({ identities, canClear, canBan, onAct, onOpenPlayer }) {
	const [note, setNote] = (0, import_react.useState)("");
	const act = (line) => {
		const embed = onAct(line);
		setNote(`${embed.title}. ${embed.description}`);
	};
	const rows = identities.slice().sort((a, b) => rankStatus(b.status) - rankStatus(a.status) || b.strikes - a.strikes);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "dash-card min-w-0 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-mono text-xs tracking-widest text-faint uppercase",
				children: "Players"
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-2xl bg-bg-subtle px-3 py-3 text-sm",
				children: note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 grid gap-2",
				children: rows.map((identity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-bg-subtle p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpenPlayer(identity.id),
								className: "flex min-h-11 min-w-0 flex-1 items-center gap-3 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
									name: identity.name,
									id: identity.id,
									size: "sm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm",
										children: identity.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-faint",
										children: ["@", identity.handle]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								tone: identity.status === "clear" ? "ok" : identity.status === "warned" ? "warn" : "danger",
								children: STATUS$1[identity.status]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 font-mono text-xs text-muted",
							children: [
								identity.warnings,
								" warning · ",
								identity.strikes,
								"/3 strikes"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									disabled: identity.warnings >= 1,
									onClick: () => act(`/mod warning ${identity.handle}`),
									children: "Warn"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									disabled: identity.strikes >= 3 || identity.status === "blacklisted",
									onClick: () => act(`/mod strike ${identity.handle}`),
									children: "Strike"
								}),
								canClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									disabled: identity.strikes <= 0,
									onClick: () => act(`/mod clear ${identity.handle}`),
									children: "Clear strike"
								}) : null,
								canBan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => act(identity.status === "blacklisted" ? `/globalunban ${identity.handle}` : `/globalban ${identity.handle}`),
									children: identity.status === "blacklisted" ? "Lift ban" : "Ban"
								}) : null
							]
						})
					]
				}, identity.id))
			})
		]
	});
}
function DeskIntro({ kicker, title, body, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("dash-card min-w-0 p-4", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-faint uppercase",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-medium tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: body
			})
		]
	});
}
function Stat({ label, value, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("dash-card min-w-0 p-4", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-widest text-faint uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-2xl font-medium tabular-nums",
			children: value
		})]
	});
}
function rankStatus(status) {
	if (status === "blacklisted") return 5;
	if (status === "under_review") return 4;
	if (status === "struck") return 3;
	if (status === "warned") return 2;
	return 1;
}
var SEED_PACK = {
	id: "pack-harbor",
	productId: "prd-marks",
	title: "Harbor marks",
	stickers: [
		{
			id: "stk-mark",
			name: "Mark",
			tone: "ok"
		},
		{
			id: "stk-lane",
			name: "Lane",
			tone: "cyan"
		},
		{
			id: "stk-hold",
			name: "Hold",
			tone: "gold"
		},
		{
			id: "stk-clear",
			name: "Clear",
			tone: "ok"
		}
	]
};
function seed() {
	return {
		groups: [{
			id: "grp-iron",
			name: "IRONWAKE",
			tag: "IRN",
			ownerId: "koba_harrow"
		}, {
			id: "grp-north",
			name: "NORTHLINE",
			tag: "NTH",
			ownerId: "koba_ysolde"
		}],
		roles: [
			{
				id: "role-iron-owner",
				groupId: "grp-iron",
				name: "Owner",
				rank: 3
			},
			{
				id: "role-iron-officer",
				groupId: "grp-iron",
				name: "Officer",
				rank: 2
			},
			{
				id: "role-iron-member",
				groupId: "grp-iron",
				name: "Member",
				rank: 1
			},
			{
				id: "role-north-owner",
				groupId: "grp-north",
				name: "Owner",
				rank: 3
			},
			{
				id: "role-north-member",
				groupId: "grp-north",
				name: "Member",
				rank: 1
			}
		],
		members: [
			{
				groupId: "grp-iron",
				identityId: "koba_harrow",
				roleId: "role-iron-owner"
			},
			{
				groupId: "grp-iron",
				identityId: "koba_mara",
				roleId: "role-iron-officer"
			},
			{
				groupId: "grp-iron",
				identityId: "koba_nora",
				roleId: "role-iron-member"
			},
			{
				groupId: "grp-north",
				identityId: "koba_ysolde",
				roleId: "role-north-owner"
			},
			{
				groupId: "grp-north",
				identityId: "koba_dex",
				roleId: "role-north-member"
			}
		],
		categories: [
			{
				id: "cat-iron-text",
				groupId: "grp-iron",
				name: "Text",
				rank: 1
			},
			{
				id: "cat-iron-voice",
				groupId: "grp-iron",
				name: "Voice",
				rank: 2
			},
			{
				id: "cat-north-text",
				groupId: "grp-north",
				name: "Text",
				rank: 1
			}
		],
		channels: [
			{
				id: "ch-general",
				groupId: "grp-iron",
				categoryId: "cat-iron-text",
				name: "general",
				kind: "text",
				rank: 1
			},
			{
				id: "ch-lfg",
				groupId: "grp-iron",
				categoryId: "cat-iron-text",
				name: "lfg",
				kind: "text",
				rank: 2
			},
			{
				id: "ch-harbor",
				groupId: "grp-iron",
				categoryId: "cat-iron-voice",
				name: "harbor",
				kind: "voice",
				rank: 1
			},
			{
				id: "ch-ops",
				groupId: "grp-iron",
				categoryId: "cat-iron-voice",
				name: "ops",
				kind: "voice",
				rank: 2
			},
			{
				id: "ch-north",
				groupId: "grp-north",
				categoryId: "cat-north-text",
				name: "line",
				kind: "text",
				rank: 1
			}
		],
		rooms: {
			"ch-general": [{
				id: "rm-1",
				authorId: "koba_harrow",
				text: "Harbor window is open until 22:00. Bring a kit."
			}, {
				id: "rm-2",
				authorId: "koba_mara",
				text: "Supply drop is listed. Don't stack the same call."
			}],
			"ch-lfg": [{
				id: "rm-3",
				authorId: "koba_nora",
				text: "Duo for a short scrap run. No hero plays."
			}],
			"ch-north": [{
				id: "rm-4",
				authorId: "koba_ysolde",
				text: "North road is quiet. Stay off the ridge."
			}]
		},
		directs: [{
			id: "dm-mara-harrow",
			a: "koba_mara",
			b: "koba_harrow",
			messages: [{
				id: "dm-1",
				authorId: "koba_harrow",
				text: "You still running harbor tonight?"
			}, {
				id: "dm-2",
				authorId: "koba_mara",
				text: "Yes. Take this.",
				sticker: "Hold",
				packTitle: "Harbor marks"
			}]
		}],
		stories: [{
			id: "story-1",
			authorId: "koba_mara",
			text: "Harbor window is live.",
			sticker: "Mark"
		}, {
			id: "story-2",
			authorId: "koba_nora",
			text: "Looking for one more on the south road."
		}],
		astroPass: ["koba_mara"],
		owned: { koba_mara: ["prd-harbor"] },
		equipped: { koba_mara: "prd-harbor" },
		packs: [SEED_PACK],
		ownedPacks: { koba_mara: ["pack-harbor"] },
		seq: 40,
		activeGroup: "grp-iron",
		activeChannel: "ch-general",
		activeThread: "dm-mara-harrow"
	};
}
function nextId(seq, prefix) {
	return `${prefix}-${seq}`;
}
var useCommunity = create((set, get) => ({
	...seed(),
	setActiveGroup: (id) => {
		set({
			activeGroup: id,
			activeChannel: get().channels.find((item) => item.groupId === id)?.id ?? get().activeChannel
		});
	},
	setActiveChannel: (id) => set({ activeChannel: id }),
	setActiveThread: (id) => set({ activeThread: id }),
	canManage: (groupId, identityId) => {
		const group = get().groups.find((item) => item.id === groupId);
		if (!group) return false;
		if (group.ownerId === identityId) return true;
		const member = get().members.find((item) => item.groupId === groupId && item.identityId === identityId);
		if (!member) return false;
		return (get().roles.find((item) => item.id === member.roleId)?.rank ?? 0) >= 2;
	},
	createGroup: (ownerId, name) => set((state) => {
		const trimmed = name.trim();
		if (trimmed.length < 2) return state;
		const seq = state.seq + 1;
		const id = nextId(seq, "grp");
		const roleId = nextId(seq, "role");
		const categoryId = nextId(seq, "cat");
		const channelId = nextId(seq, "ch");
		return {
			seq,
			groups: [...state.groups, {
				id,
				name: trimmed.slice(0, 24),
				tag: trimmed.slice(0, 3).toUpperCase(),
				ownerId
			}],
			roles: [...state.roles, {
				id: roleId,
				groupId: id,
				name: "Owner",
				rank: 3
			}],
			members: [...state.members, {
				groupId: id,
				identityId: ownerId,
				roleId
			}],
			categories: [...state.categories, {
				id: categoryId,
				groupId: id,
				name: "Text",
				rank: 1
			}],
			channels: [...state.channels, {
				id: channelId,
				groupId: id,
				categoryId,
				name: "general",
				kind: "text",
				rank: 1
			}],
			rooms: {
				...state.rooms,
				[channelId]: []
			},
			activeGroup: id,
			activeChannel: channelId
		};
	}),
	joinGroup: (groupId, identityId) => set((state) => {
		if (state.members.some((item) => item.groupId === groupId && item.identityId === identityId)) return state;
		const role = state.roles.filter((item) => item.groupId === groupId).sort((a, b) => a.rank - b.rank)[0];
		if (!role) return state;
		return { members: [...state.members, {
			groupId,
			identityId,
			roleId: role.id
		}] };
	}),
	addCategory: (groupId, identityId, name) => {
		if (!get().canManage(groupId, identityId)) return null;
		const trimmed = name.trim();
		if (trimmed.length < 2) return null;
		const seq = get().seq + 1;
		const id = nextId(seq, "cat");
		const rank = get().categories.filter((item) => item.groupId === groupId).length + 1;
		set((state) => ({
			seq,
			categories: [...state.categories, {
				id,
				groupId,
				name: trimmed.slice(0, 24),
				rank
			}]
		}));
		return id;
	},
	addChannel: (groupId, identityId, categoryId, name, kind) => {
		if (!get().canManage(groupId, identityId)) return null;
		const trimmed = name.trim().toLowerCase().replace(/\s+/g, "-");
		if (trimmed.length < 2) return null;
		const seq = get().seq + 1;
		const id = nextId(seq, "ch");
		const rank = get().channels.filter((item) => item.categoryId === categoryId).length + 1;
		set((state) => ({
			seq,
			channels: [...state.channels, {
				id,
				groupId,
				categoryId,
				name: trimmed.slice(0, 24),
				kind,
				rank
			}],
			rooms: {
				...state.rooms,
				[id]: []
			},
			activeChannel: id
		}));
		return id;
	},
	addRole: (groupId, identityId, name) => {
		if (!get().canManage(groupId, identityId)) return null;
		const trimmed = name.trim();
		if (trimmed.length < 2) return null;
		const seq = get().seq + 1;
		const id = nextId(seq, "role");
		const lowest = get().roles.filter((item) => item.groupId === groupId && item.name !== "Owner").reduce((min, role) => Math.min(min, role.rank), 2);
		set((state) => ({
			seq,
			roles: [...state.roles, {
				id,
				groupId,
				name: trimmed.slice(0, 24),
				rank: Math.max(1, lowest)
			}]
		}));
		return id;
	},
	moveRole: (groupId, identityId, roleId, direction) => set((state) => {
		if (!state.canManage(groupId, identityId)) return state;
		const group = state.groups.find((item) => item.id === groupId);
		const role = state.roles.find((item) => item.id === roleId);
		if (!group || !role || role.groupId !== groupId) return state;
		if (role.name === "Owner") return state;
		const sibling = state.roles.filter((item) => item.groupId === groupId && item.id !== roleId && item.name !== "Owner").filter((item) => direction < 0 ? item.rank > role.rank : item.rank < role.rank).sort((a, b) => direction < 0 ? a.rank - b.rank : b.rank - a.rank)[0];
		if (!sibling) return state;
		return { roles: state.roles.map((item) => {
			if (item.id === role.id) return {
				...item,
				rank: sibling.rank
			};
			if (item.id === sibling.id) return {
				...item,
				rank: role.rank
			};
			return item;
		}) };
	}),
	postRoom: (channelId, authorId, text) => set((state) => {
		const trimmed = text.trim();
		if (!trimmed) return state;
		const seq = state.seq + 1;
		const current = state.rooms[channelId] ?? [];
		return {
			seq,
			rooms: {
				...state.rooms,
				[channelId]: [...current, {
					id: nextId(seq, "rm"),
					authorId,
					text: trimmed.slice(0, 240)
				}]
			}
		};
	}),
	openThread: (selfId, otherId) => {
		const existing = get().directs.find((thread) => thread.a === selfId && thread.b === otherId || thread.a === otherId && thread.b === selfId);
		if (existing) {
			set({ activeThread: existing.id });
			return existing.id;
		}
		const seq = get().seq + 1;
		const id = nextId(seq, "dm");
		set((state) => ({
			seq,
			directs: [...state.directs, {
				id,
				a: selfId,
				b: otherId,
				messages: []
			}],
			activeThread: id
		}));
		return id;
	},
	sendDirect: (threadId, authorId, text, sticker) => set((state) => {
		const trimmed = text.trim();
		if (!trimmed && !sticker) return state;
		const seq = state.seq + 1;
		return {
			seq,
			directs: state.directs.map((thread) => thread.id === threadId ? {
				...thread,
				messages: [...thread.messages, {
					id: nextId(seq, "dmmsg"),
					authorId,
					text: trimmed.slice(0, 240),
					sticker: sticker?.name,
					packTitle: sticker?.packTitle
				}]
			} : thread)
		};
	}),
	addStory: (authorId, text, sticker) => set((state) => {
		const trimmed = text.trim();
		if (!trimmed && !sticker) return state;
		const seq = state.seq + 1;
		return {
			seq,
			stories: [{
				id: nextId(seq, "story"),
				authorId,
				text: trimmed.slice(0, 140) || "Sticker",
				sticker
			}, ...state.stories]
		};
	}),
	subscribe: (identityId) => set((state) => ({ astroPass: state.astroPass.includes(identityId) ? state.astroPass : [...state.astroPass, identityId] })),
	endPass: (identityId) => set((state) => ({
		astroPass: state.astroPass.filter((id) => id !== identityId),
		equipped: {
			...state.equipped,
			[identityId]: null
		}
	})),
	grantProduct: (identityId, productId, kind, title, stickerNames) => set((state) => {
		if (kind === "sticker-pack") {
			const existing = state.packs.find((pack) => pack.productId === productId);
			const seq = state.seq + 1;
			const source = stickerNames && stickerNames.length >= 4 ? stickerNames : [
				"Mark",
				"Lane",
				"Hold",
				"Clear"
			];
			const tones = [
				"ok",
				"cyan",
				"gold",
				"ok"
			];
			const pack = existing ?? {
				id: nextId(seq, "pack"),
				productId,
				title,
				stickers: source.slice(0, 8).map((name, index) => ({
					id: `${nextId(seq, "stk")}-${index}`,
					name: name.replace(/\.[a-z0-9]+$/i, "").slice(0, 16) || `Sticker ${index + 1}`,
					tone: tones[index % tones.length]
				}))
			};
			const mine = state.ownedPacks[identityId] ?? [];
			return {
				seq: existing ? state.seq : seq,
				packs: existing ? state.packs : [...state.packs, pack],
				ownedPacks: {
					...state.ownedPacks,
					[identityId]: mine.includes(pack.id) ? mine : [...mine, pack.id]
				}
			};
		}
		const mine = state.owned[identityId] ?? [];
		if (mine.includes(productId)) return state;
		return { owned: {
			...state.owned,
			[identityId]: [...mine, productId]
		} };
	}),
	equip: (identityId, productId) => {
		const state = get();
		if (!state.astroPass.includes(identityId)) return false;
		if (!(state.owned[identityId] ?? []).includes(productId)) return false;
		set({ equipped: {
			...state.equipped,
			[identityId]: productId
		} });
		return true;
	},
	clearEquip: (identityId) => set((state) => ({ equipped: {
		...state.equipped,
		[identityId]: null
	} })),
	reset: () => set(seed())
}));
function GroupsPage({ viewer, identities }) {
	const groups = useCommunity((s) => s.groups);
	const roles = useCommunity((s) => s.roles);
	const members = useCommunity((s) => s.members);
	const categories = useCommunity((s) => s.categories);
	const channels = useCommunity((s) => s.channels);
	const rooms = useCommunity((s) => s.rooms);
	const activeGroup = useCommunity((s) => s.activeGroup);
	const activeChannel = useCommunity((s) => s.activeChannel);
	const setActiveGroup = useCommunity((s) => s.setActiveGroup);
	const setActiveChannel = useCommunity((s) => s.setActiveChannel);
	const createGroup = useCommunity((s) => s.createGroup);
	const joinGroup = useCommunity((s) => s.joinGroup);
	const addCategory = useCommunity((s) => s.addCategory);
	const addChannel = useCommunity((s) => s.addChannel);
	const addRole = useCommunity((s) => s.addRole);
	const moveRole = useCommunity((s) => s.moveRole);
	const postRoom = useCommunity((s) => s.postRoom);
	const canManage = useCommunity((s) => s.canManage);
	const [groupName, setGroupName] = (0, import_react.useState)("");
	const [categoryName, setCategoryName] = (0, import_react.useState)("");
	const [channelName, setChannelName] = (0, import_react.useState)("");
	const [channelKind, setChannelKind] = (0, import_react.useState)("text");
	const [categoryId, setCategoryId] = (0, import_react.useState)("");
	const [roleName, setRoleName] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const group = groups.find((item) => item.id === activeGroup) ?? groups[0];
	const member = members.find((item) => item.groupId === group?.id && item.identityId === viewer.id);
	const manage = group ? canManage(group.id, viewer.id) : false;
	const groupRoles = roles.filter((item) => item.groupId === group?.id).slice().sort((a, b) => b.rank - a.rank);
	const groupCategories = categories.filter((item) => item.groupId === group?.id).slice().sort((a, b) => a.rank - b.rank);
	const channel = channels.find((item) => item.id === activeChannel && item.groupId === group?.id) ?? channels.find((item) => item.groupId === group?.id);
	const lines = channel ? rooms[channel.id] ?? [] : [];
	const nameFor = (id) => identities.find((identity) => identity.id === id)?.name ?? id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 xl:grid-cols-[16rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid content-start gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					"data-noswipe": true,
					children: groups.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveGroup(item.id),
						className: `grid h-12 w-12 shrink-0 place-items-center rounded-2xl font-mono text-xs ${item.id === group?.id ? "bg-ok/15 text-ok" : "text-muted"}`,
						"aria-label": item.name,
						children: item.tag
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						createGroup(viewer.id, groupName);
						setGroupName("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: groupName,
						onChange: (event) => setGroupName(event.target.value),
						placeholder: "New group",
						className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Create"
					})]
				}),
				group ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-bg-elevated p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: group.name
							}), member ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] text-ok",
								children: "Joined"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 text-xs text-cyan",
								onClick: () => joinGroup(group.id, viewer.id),
								children: "Join"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								"Owner ",
								nameFor(group.ownerId),
								". Higher roles sit above lower ones."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid gap-3",
							children: groupCategories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-[10px] tracking-[0.14em] text-faint uppercase",
								children: category.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 grid",
								children: channels.filter((item) => item.categoryId === category.id).slice().sort((a, b) => a.rank - b.rank).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setActiveChannel(item.id),
									className: `flex min-h-11 items-center gap-2 rounded-lg px-2 text-left text-sm ${item.id === channel?.id ? "bg-ok/10 text-ok" : "text-muted"}`,
									children: [item.kind === "voice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, { size: 14 }), item.name]
								}, item.id))
							})] }, category.id))
						}),
						manage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-2 border-t border-border pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "flex gap-2",
								onSubmit: (event) => {
									event.preventDefault();
									const id = addCategory(group.id, viewer.id, categoryName);
									setNote(id ? "Category added." : "Could not add category.");
									setCategoryName("");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: categoryName,
									onChange: (event) => setCategoryName(event.target.value),
									placeholder: "Category",
									className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 text-sm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									variant: "quiet",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " Add"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "grid gap-2",
								onSubmit: (event) => {
									event.preventDefault();
									const chosen = categoryId || groupCategories[0]?.id;
									if (!chosen) return;
									const id = addChannel(group.id, viewer.id, chosen, channelName, channelKind);
									setNote(id ? "Channel added." : "Could not add channel.");
									setChannelName("");
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: channelName,
											onChange: (event) => setChannelName(event.target.value),
											placeholder: "Channel",
											className: "h-11 min-w-0 flex-1 rounded-2xl border border-border bg-bg px-3 text-sm"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSelect, {
											className: "w-32 shrink-0",
											ariaLabel: "Channel type",
											value: channelKind,
											options: [{
												value: "text",
												label: "Text"
											}, {
												value: "voice",
												label: "Voice"
											}],
											onChange: (value) => setChannelKind(value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSelect, {
										ariaLabel: "Category",
										value: categoryId || groupCategories[0]?.id || "",
										options: groupCategories.map((category) => ({
											value: category.id,
											label: category.name
										})),
										onChange: setCategoryId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										children: "Add channel"
									})
								]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-muted",
							children: "Owner and officer roles can add channels, categories, and roles."
						})
					]
				}) : null,
				group ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-bg-elevated p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Roles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-2 grid gap-1",
							children: groupRoles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex min-h-11 items-center justify-between gap-2 rounded-lg border border-border px-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm",
									children: [
										role.name,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-[10px] text-faint",
											children: ["rank ", role.rank]
										})
									]
								}), manage && role.name !== "Owner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 px-2 text-xs",
										onClick: () => moveRole(group.id, viewer.id, role.id, -1),
										"aria-label": `Move ${role.name} up`,
										children: "Up"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 px-2 text-xs",
										onClick: () => moveRole(group.id, viewer.id, role.id, 1),
										"aria-label": `Move ${role.name} down`,
										children: "Down"
									})]
								}) : null]
							}, role.id))
						}),
						manage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-2 flex gap-2",
							onSubmit: (event) => {
								event.preventDefault();
								const id = addRole(group.id, viewer.id, roleName);
								setNote(id ? "Role added under the current ranks." : "Could not add role.");
								setRoleName("");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: roleName,
								onChange: (event) => setRoleName(event.target.value),
								placeholder: "New role",
								className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 text-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								children: "Add"
							})]
						}) : null,
						note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-ok",
							children: note
						}) : null
					]
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "grid min-h-[24rem] content-start gap-3 rounded-2xl border border-border bg-bg-elevated p-4",
			children: channel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[10px] tracking-[0.16em] text-faint uppercase",
					children: channel.kind
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: channel.name
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-border bg-bg p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-cyan",
							children: nameFor(line.authorId)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: line.text
						})]
					}, line.id)), lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No messages in this channel yet."
					}) : null]
				}),
				channel.kind === "text" && member ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-auto flex gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						postRoom(channel.id, viewer.id, draft);
						setDraft("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: draft,
						onChange: (event) => setDraft(event.target.value),
						placeholder: `Message ${channel.name}`,
						className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Send"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: channel.kind === "voice" ? "Voice channels are listed here. Join the group to talk in text." : "Join the group to post."
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Pick a group."
			})
		})]
	});
}
var TONE = {
	ok: "var(--color-ok)",
	cyan: "var(--color-cyan)",
	violet: "var(--color-violet)",
	gold: "var(--color-gold)",
	magenta: "var(--color-magenta)",
	muted: "var(--color-faint)"
};
function BadgeIcon({ glyph, tone, size = 22 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 32 32",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "15",
				fill: TONE[tone]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "12",
				r: "8",
				fill: "var(--color-fg)",
				opacity: "0.18"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glyph, {
				glyph,
				ink: "var(--color-bg)"
			})
		]
	});
}
function Glyph({ glyph, ink }) {
	const common = {
		fill: "none",
		stroke: ink,
		strokeWidth: 2.2,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	};
	if (glyph === "seal") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M10 16.5 14 20.5 22 12"
	});
	if (glyph === "comet") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M16 8.5a7.5 7.5 0 1 0 6 3M22 10.5 24 7"
	});
	if (glyph === "diamond") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M16 8 23 16 16 24 9 16Z"
	});
	if (glyph === "crown") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M9 21h14M10 21 8 12l6 5 2-7 2 7 6-5-2 9"
	});
	if (glyph === "laurel") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M12 22c-4-2-5-7-3-11M20 22c4-2 5-7 3-11M13 14h6M13 18h6"
	});
	if (glyph === "wave") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M7 18c2 0 2-3 4-3s2 3 4 3 2-3 4-3 2 3 4 3"
	});
	if (glyph === "hex") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M16 8 23 12.5v7L16 24l-7-4.5v-7Z"
	});
	if (glyph === "peak") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M6 22 16 8l10 14M12 22l4-6 4 6"
	});
	if (glyph === "spark") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M16 7v18M7 16h18M10 10l12 12M22 10 10 22"
	});
	if (glyph === "gift") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M10 14h12v8H10zM8 14h16M16 14v8M16 14c-2 0-4-2-3-3.5S16 12 16 14s2-3.5 3.5-2.5S18 14 16 14"
	});
	if (glyph === "clock") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M16 9a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM16 12v5l3 2"
	});
	if (glyph === "maps") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M8 11h6v10H8zM14 9h6v10h-6zM20 12h4v9h-4"
	});
	if (glyph === "chevron") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M10 19 16 13l6 6M10 14l6-6 6 6"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		...common,
		d: "M11 8 21 24M21 8 11 24"
	});
}
function BadgeRow({ pins, size = 18, enter = false }) {
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [heldId, setHeldId] = (0, import_react.useState)(null);
	const timer = (0, import_react.useRef)(null);
	const held = (0, import_react.useRef)(false);
	if (pins.length === 0) return null;
	const clearTimer = () => {
		if (timer.current != null) window.clearTimeout(timer.current);
		timer.current = null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex flex-wrap items-center gap-0.5 align-middle",
		"aria-label": "Badges",
		children: pins.map((pin, index) => {
			const open = openId === pin.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative",
				"data-badge": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `badge-pin grid min-h-7 min-w-7 place-items-center ${enter ? "badge-enter" : ""} ${heldId === pin.id ? "is-held" : ""}`,
					style: enter ? { animationDelay: `${index * 70}ms` } : void 0,
					role: "img",
					"aria-label": `${pin.name}. ${pin.detail}`,
					onMouseEnter: () => setOpenId(pin.id),
					onMouseLeave: () => setOpenId((current) => current === pin.id ? null : current),
					onPointerDown: (event) => {
						event.stopPropagation();
						held.current = false;
						clearTimer();
						timer.current = window.setTimeout(() => {
							held.current = true;
							setHeldId(pin.id);
							setOpenId(pin.id);
						}, 380);
					},
					onPointerUp: () => {
						clearTimer();
						window.setTimeout(() => setHeldId(null), 420);
					},
					onPointerCancel: () => {
						clearTimer();
						setHeldId(null);
					},
					onClick: (event) => {
						event.stopPropagation();
						event.preventDefault();
						if (held.current) return;
						setOpenId((current) => current === pin.id ? null : pin.id);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeIcon, {
						glyph: pin.glyph,
						tone: pin.tone,
						size
					})
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					role: "tooltip",
					className: "badge-tip text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium text-fg",
						children: pin.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-muted",
						children: pin.detail
					})]
				}) : null]
			}, pin.id);
		})
	});
}
function BadgeBoard({ result }) {
	const [activeId, setActiveId] = (0, import_react.useState)(result.featured[0]?.id ?? result.earned[0]?.id ?? null);
	const active = result.earned.find((pin) => pin.id === activeId) ?? result.featured[0] ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-1",
			"data-noswipe": true,
			children: result.earned.map((pin) => {
				const on = pin.id === active?.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": on,
					"aria-label": pin.name,
					onClick: () => setActiveId(pin.id),
					className: `grid h-11 w-11 place-items-center rounded-2xl ${on ? "bg-violet/20" : ""}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeIcon, {
						glyph: pin.glyph,
						tone: pin.tone,
						size: 26
					})
				}, pin.id);
			})
		}), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm",
			role: "status",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-medium",
					children: [active.name, "."]
				}),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: active.detail
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "No badges on this identity yet."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-3 sm:grid-cols-2",
			children: result.ladders.map((ladder) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-bg-subtle p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [ladder.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeIcon, {
							glyph: ladder.current.glyph,
							tone: ladder.current.tone,
							size: 28
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-7 w-7 place-items-center rounded-full bg-bg text-xs text-faint",
							children: "–"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs tracking-widest text-faint uppercase",
								children: ladder.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm",
								children: ladder.current?.name ?? "Not started"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							ladder.value.toLocaleString("en-US"),
							" ",
							ladder.unit,
							ladder.next && ladder.nextAt != null ? `. Next is ${ladder.next.name} at ${ladder.nextAt.toLocaleString("en-US")}.` : ". Top mark."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-1.5 overflow-hidden rounded-full bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-violet",
							style: { width: ladder.nextAt == null ? "100%" : `${Math.max(8, Math.min(100, Math.round(ladder.value / ladder.nextAt * 100)))}%` }
						})
					})
				]
			}, ladder.id))
		})]
	});
}
var SEASONS = [
	{
		id: "season-spark",
		name: "Spark",
		at: 1,
		tone: "cyan",
		glyph: "spark",
		detail: "One season on KOBA."
	},
	{
		id: "season-kindling",
		name: "Kindling",
		at: 2,
		tone: "cyan",
		glyph: "spark",
		detail: "Two seasons on KOBA."
	},
	{
		id: "season-flare",
		name: "Flare",
		at: 3,
		tone: "gold",
		glyph: "spark",
		detail: "Three seasons on KOBA."
	},
	{
		id: "season-beacon",
		name: "Beacon",
		at: 4,
		tone: "gold",
		glyph: "spark",
		detail: "Four seasons on KOBA."
	},
	{
		id: "season-signal",
		name: "Signal",
		at: 5,
		tone: "violet",
		glyph: "spark",
		detail: "Five seasons on KOBA."
	},
	{
		id: "season-monument",
		name: "Monument",
		at: 6,
		tone: "violet",
		glyph: "spark",
		detail: "Six or more seasons on KOBA."
	}
];
var GIFTS = [
	{
		id: "gift-tip",
		name: "Tip",
		at: 1,
		tone: "cyan",
		glyph: "gift",
		detail: "Sent 1 shop gift."
	},
	{
		id: "gift-backer",
		name: "Backer",
		at: 2,
		tone: "cyan",
		glyph: "gift",
		detail: "Sent 2 shop gifts."
	},
	{
		id: "gift-patron",
		name: "Patron",
		at: 3,
		tone: "gold",
		glyph: "gift",
		detail: "Sent 3 shop gifts."
	},
	{
		id: "gift-benefactor",
		name: "Benefactor",
		at: 6,
		tone: "gold",
		glyph: "gift",
		detail: "Sent 6 shop gifts."
	},
	{
		id: "gift-keeper",
		name: "Keeper",
		at: 10,
		tone: "violet",
		glyph: "gift",
		detail: "Sent 10 shop gifts."
	},
	{
		id: "gift-legend",
		name: "Legend",
		at: 20,
		tone: "magenta",
		glyph: "gift",
		detail: "Sent 20 shop gifts."
	}
];
var HOURS = [
	{
		id: "hours-scout",
		name: "Scout",
		at: 1,
		tone: "cyan",
		glyph: "clock",
		detail: "1 hour on record."
	},
	{
		id: "hours-regular",
		name: "Regular",
		at: 20,
		tone: "cyan",
		glyph: "clock",
		detail: "20 hours on record."
	},
	{
		id: "hours-devoted",
		name: "Devoted",
		at: 75,
		tone: "gold",
		glyph: "clock",
		detail: "75 hours on record."
	},
	{
		id: "hours-veteran",
		name: "Veteran",
		at: 300,
		tone: "gold",
		glyph: "clock",
		detail: "300 hours on record."
	},
	{
		id: "hours-iron",
		name: "Iron",
		at: 1e3,
		tone: "violet",
		glyph: "clock",
		detail: "1,000 hours on record."
	},
	{
		id: "hours-mythic",
		name: "Mythic",
		at: 2e3,
		tone: "magenta",
		glyph: "clock",
		detail: "2,000 hours on record."
	}
];
var LIBRARY = [
	{
		id: "lib-pair",
		name: "Pair",
		at: 2,
		tone: "cyan",
		glyph: "maps",
		detail: "Played 2 games on record."
	},
	{
		id: "lib-circuit",
		name: "Circuit",
		at: 5,
		tone: "cyan",
		glyph: "maps",
		detail: "Played 5 games on record."
	},
	{
		id: "lib-range",
		name: "Range",
		at: 10,
		tone: "gold",
		glyph: "maps",
		detail: "Played 10 games on record."
	},
	{
		id: "lib-atlas",
		name: "Atlas",
		at: 20,
		tone: "violet",
		glyph: "maps",
		detail: "Played 20 games on record."
	}
];
var RALLY = [
	{
		id: "rally-1",
		name: "Rally",
		at: 2,
		tone: "cyan",
		glyph: "chevron",
		detail: "Group has 2 players."
	},
	{
		id: "rally-2",
		name: "Banner",
		at: 4,
		tone: "gold",
		glyph: "chevron",
		detail: "Group has 4 players."
	},
	{
		id: "rally-3",
		name: "Keep",
		at: 8,
		tone: "violet",
		glyph: "chevron",
		detail: "Group has 8 players."
	}
];
var RECORD = {
	koba_mara: {
		seasons: 4,
		gifts: 6,
		hours: 320,
		games: 8
	},
	koba_harrow: {
		seasons: 6,
		gifts: 12,
		hours: 900,
		games: 14
	},
	koba_dex: {
		seasons: 1,
		gifts: 0,
		hours: 40,
		games: 3
	},
	koba_nora: {
		seasons: 3,
		gifts: 2,
		hours: 1400,
		games: 22
	},
	koba_ysolde: {
		seasons: 5,
		gifts: 1,
		hours: 180,
		games: 6
	}
};
function pin(step, group) {
	return {
		id: step.id,
		name: step.name,
		group,
		detail: step.detail,
		tone: step.tone,
		glyph: step.glyph
	};
}
function climb(steps, value, group, label, unit) {
	let current = null;
	for (const step of steps) if (value >= step.at) current = step;
	const next = steps.find((step) => step.at > value) ?? null;
	return {
		id: group,
		label,
		unit,
		value,
		current: current ? pin(current, group) : null,
		next: next ? pin(next, group) : null,
		nextAt: next?.at ?? null
	};
}
function resolveBadges(source) {
	const record = RECORD[source.id] ?? {
		seasons: 1,
		gifts: 0,
		hours: 1,
		games: 2
	};
	const earned = [];
	if (source.verified) earned.push({
		id: "verified",
		name: "Verified",
		group: "Standing",
		detail: "Verified account. The shop fee is 2.5%.",
		tone: "cyan",
		glyph: "seal"
	});
	if (source.subscribed) earned.push({
		id: "astro",
		name: "Astro",
		group: "Standing",
		detail: "Astro pass is active. Cosmetics can be applied.",
		tone: "ok",
		glyph: "comet"
	});
	if (source.business) earned.push({
		id: "business",
		name: "Business",
		group: "Standing",
		detail: "Business account. Can list on the Official shop.",
		tone: "gold",
		glyph: "diamond"
	});
	if (source.ownsGroup || source.engineBadges.includes("Clan lead")) earned.push({
		id: "founder",
		name: "Founder",
		group: "Standing",
		detail: "Owns a group, or leads a clan.",
		tone: "violet",
		glyph: "crown"
	});
	else if (source.officer) earned.push({
		id: "officer",
		name: "Officer",
		group: "Standing",
		detail: "Officer role in a group.",
		tone: "cyan",
		glyph: "chevron"
	});
	if (source.score >= 2e3 || source.engineBadges.includes("Ranked")) earned.push({
		id: "ranked",
		name: "Ranked",
		group: "Standing",
		detail: "Top of the current board.",
		tone: "gold",
		glyph: "laurel"
	});
	if (source.house === "wake") earned.push({
		id: "house-wake",
		name: "Wake",
		group: "House",
		detail: "House of IRONWAKE.",
		tone: "cyan",
		glyph: "wave"
	});
	if (source.house === "north") earned.push({
		id: "house-north",
		name: "North",
		group: "House",
		detail: "House of NORTHLINE.",
		tone: "violet",
		glyph: "peak"
	});
	const ladders = [
		climb(SEASONS, record.seasons, "Season", "Seasons", "seasons"),
		climb(GIFTS, record.gifts, "Gifts", "Gifts", "gifts"),
		climb(HOURS, record.hours, "Hours", "Hours", "hours"),
		climb(LIBRARY, record.games, "Library", "Library", "games"),
		climb(RALLY, source.groupMembers, "Group", "Group", "players")
	];
	for (const ladder of ladders) if (ladder.current && ladder.id !== "Group") earned.push(ladder.current);
	const rally = ladders.find((ladder) => ladder.id === "Group");
	if (rally?.current && source.groupMembers > 0) earned.push(rally.current);
	if (source.status === "clear" && source.strikes === 0 && source.warnings === 0) earned.push({
		id: "clear",
		name: "Clear",
		group: "Marks",
		detail: "No warnings and no strikes.",
		tone: "ok",
		glyph: "seal"
	});
	if (source.homes >= 2) earned.push({
		id: "camps",
		name: "Twin camp",
		group: "Marks",
		detail: "Two homes set.",
		tone: "cyan",
		glyph: "mark"
	});
	if (source.steam) earned.push({
		id: "linked",
		name: "Linked",
		group: "Marks",
		detail: "Steam is linked on this identity.",
		tone: "muted",
		glyph: "hex"
	});
	for (const mark of source.marks) earned.push({
		id: `mark-${mark.id}`,
		name: mark.name,
		group: "Marks",
		detail: mark.detail,
		tone: mark.rare ? "gold" : "ok",
		glyph: "mark"
	});
	const head = [
		"verified",
		"astro",
		"business",
		"house-wake",
		"house-north",
		"founder",
		"officer",
		"ranked"
	].flatMap((id) => {
		const found = earned.find((item) => item.id === id);
		return found ? [found] : [];
	});
	const season = ladders.find((ladder) => ladder.id === "Season")?.current;
	const gift = ladders.find((ladder) => ladder.id === "Gifts")?.current;
	return {
		featured: [
			...head.slice(0, 4),
			...season ? [season] : [],
			...gift ? [gift] : []
		].slice(0, 6),
		earned,
		ladders
	};
}
function sourceFor(identity, standing, flags, marks) {
	const house = flags.groupId === "grp-north" ? "north" : flags.groupId === "grp-iron" ? "wake" : identity.clanId === "northline" ? "north" : identity.clanId === "ironwake" ? "wake" : null;
	return {
		id: identity.id,
		score: identity.score,
		status: identity.status,
		strikes: identity.strikes,
		warnings: identity.warnings,
		homes: identity.homes.length,
		steam: identity.steamId,
		engineBadges: identity.badges,
		verified: standing.verified,
		business: standing.business,
		subscribed: flags.subscribed,
		ownsGroup: flags.ownsGroup,
		officer: flags.officer,
		house,
		groupMembers: flags.groupMembers,
		marks
	};
}
var initial = {
	page: "home",
	homeTab: "feed",
	query: "",
	game: "all",
	region: "all",
	style: "all",
	saved: ["srv-iron"],
	follows: ["koba_dex"],
	bounties: [],
	products: SEED_PRODUCTS,
	productSeq: 2,
	opened: {},
	pulse: 0,
	notice: null,
	palette: false,
	accountOpen: false,
	focusId: null,
	desk: "play"
};
var useSite = create((set) => ({
	...initial,
	setPage: (page) => set({
		page,
		desk: "play",
		accountOpen: false,
		palette: false
	}),
	setHomeTab: (homeTab) => set({
		homeTab,
		page: "home",
		desk: "play",
		accountOpen: false,
		palette: false
	}),
	setDesk: (desk) => set({
		desk,
		accountOpen: false,
		palette: false
	}),
	setQuery: (query) => set({ query }),
	setGame: (game) => set({ game }),
	setRegion: (region) => set({ region }),
	setStyle: (style) => set({ style }),
	toggleSaved: (id) => set((state) => ({ saved: state.saved.includes(id) ? state.saved.filter((item) => item !== id) : [...state.saved, id] })),
	toggleFollow: (id) => set((state) => ({ follows: state.follows.includes(id) ? state.follows.filter((item) => item !== id) : [...state.follows, id] })),
	toggleBounty: (id) => set((state) => ({ bounties: state.bounties.includes(id) ? state.bounties.filter((item) => item !== id) : [...state.bounties, id] })),
	openBusiness: (id, name) => set((state) => ({ opened: {
		...state.opened,
		[id]: name
	} })),
	addProduct: (draft) => set((state) => {
		const productSeq = state.productSeq + 1;
		return {
			productSeq,
			products: [{
				id: `prd-${productSeq}`,
				...draft
			}, ...state.products]
		};
	}),
	ping: (title, detail) => set((state) => ({
		pulse: state.pulse + 1,
		notice: {
			id: state.pulse + 1,
			title,
			detail
		}
	})),
	setPalette: (palette) => set({
		palette,
		accountOpen: false
	}),
	setAccountOpen: (accountOpen) => set({
		accountOpen,
		palette: false
	}),
	openProfile: (focusId) => set({
		focusId,
		page: "profile",
		desk: "play",
		palette: false,
		accountOpen: false
	}),
	reset: () => set({
		...initial,
		products: SEED_PRODUCTS.map((product) => ({ ...product }))
	})
}));
function useResolvedBadges(identities) {
	const opened = useSite((s) => s.opened);
	const astroPass = useCommunity((s) => s.astroPass);
	const groups = useCommunity((s) => s.groups);
	const members = useCommunity((s) => s.members);
	const roles = useCommunity((s) => s.roles);
	return (0, import_react.useMemo)(() => {
		const out = {};
		for (const identity of identities) {
			const membership = members.filter((member) => member.identityId === identity.id);
			const groupId = membership[0]?.groupId;
			const groupMembers = groupId ? members.filter((member) => member.groupId === groupId).length : 0;
			const ownsGroup = groups.some((group) => group.ownerId === identity.id);
			const officer = membership.some((member) => {
				const role = roles.find((item) => item.id === member.roleId);
				return Boolean(role && role.rank >= 2 && role.name !== "Owner");
			});
			const marks = metaFor(identity.id, identity.score).achievements;
			out[identity.id] = resolveBadges(sourceFor(identity, accountFor(identity.id, opened), {
				subscribed: astroPass.includes(identity.id),
				ownsGroup,
				officer,
				groupId,
				groupMembers
			}, marks));
		}
		return out;
	}, [
		astroPass,
		groups,
		identities,
		members,
		opened,
		roles
	]);
}
function HomePage({ viewer, identities, clans, rank, account, products, pending, pulse, feed, onOpen, onOpenPlayer }) {
	const series = (0, import_react.useMemo)(() => formSeries(viewer), [viewer]);
	const meta = metaFor(viewer.id, viewer.score);
	const up = viewer.scoreDelta >= 0;
	const rivals = viewer.rivals.map((id) => identities.find((identity) => identity.id === id)).filter((identity) => Boolean(identity)).slice(0, 3);
	const board = identities.slice().sort((a, b) => b.score - a.score).slice(0, 5);
	const fee = quote(100, account.verified).label;
	const rust = LISTINGS.filter((listing) => listing.gameId === "rust");
	const dayz = LISTINGS.filter((listing) => listing.gameId === "dayz");
	const latest = series[series.length - 1]?.form ?? 0;
	const badgeMap = useResolvedBadges(identities);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-w-0 gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketBoard, {
			identities,
			products,
			onOpen
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "dash-card relative min-w-0 p-4 xl:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute inset-0 overflow-hidden rounded-3xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/brand/koba-mark.gif",
								alt: "",
								width: 264,
								height: 264,
								className: "absolute -right-4 -bottom-6 h-36 w-28 object-contain opacity-30"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-faint uppercase",
							children: "You"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
								name: viewer.name,
								id: viewer.id,
								size: "lg"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-base font-medium",
										children: viewer.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-xs text-faint",
										children: ["@", viewer.handle]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeRow, {
											pins: badgeMap[viewer.id]?.featured ?? [],
											size: 18,
											enter: true
										})
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreReadout, {
							score: viewer.score,
							delta: viewer.scoreDelta,
							rank,
							up
						}, viewer.id),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoinPocket, {
							region: meta.region,
							coins: viewer.coins,
							identityId: viewer.id,
							feed,
							products,
							onShop: () => onOpen("shop")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopButton, {
							onClick: () => onOpen("shop"),
							children: account.business ? "Open shop" : "Official shop"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {
					title: "Form",
					fold: true,
					className: "max-xl:order-first xl:col-span-5",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full bg-cyan/15 px-3 py-1 font-mono text-xs text-cyan",
						children: [
							latest,
							" · ",
							viewer.form
						]
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
						series,
						label: "Form chart"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dash, {
					title: "Top rivals",
					className: "xl:col-span-4",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-faint",
						children: pending ? `${pending} open` : "Clear"
					}),
					children: [rivals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No rivals on this identity."
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-1",
						children: rivals.map((rival) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpenPlayer(rival.id),
							className: "flex min-h-14 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
									name: rival.name,
									id: rival.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate text-sm",
											children: rival.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeRow, {
											pins: (badgeMap[rival.id]?.featured ?? []).slice(0, 3),
											size: 16
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-faint",
										children: ["@", rival.handle]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-cyan",
									children: rival.score.toLocaleString("en-US")
								})
							]
						}) }, rival.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dash, {
					title: "Games",
					className: "xl:col-span-3",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
						onClick: () => onOpen("discover"),
						children: "See all"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameBlock, {
						label: "Rust Console",
						rows: rust.slice(0, 3),
						onOpen: () => onOpen("discover")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameBlock, {
						label: "DayZ",
						rows: dayz.slice(0, 2),
						onOpen: () => onOpen("discover")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {
					title: "Activity",
					className: "xl:col-span-5",
					action: pulse > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-ok/15 px-3 py-1 font-mono text-xs text-ok",
						children: "Live"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
						onClick: () => onOpen("feed"),
						children: "Feed"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: feed.slice(0, 5).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3 border-b border-border/70 py-3 last:border-b-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `mt-1.5 h-2 w-2 shrink-0 rounded-full ${row.tone === "danger" ? "bg-danger" : row.tone === "gold" ? "bg-gold" : row.tone === "ok" ? "bg-ok" : "bg-cyan"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: row.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: row.detail
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								tone: row.tone === "gold" ? "warn" : row.tone === "cyan" ? "cyan" : row.tone === "ok" ? "ok" : row.tone === "danger" ? "danger" : "neutral",
								children: row.tone === "gold" ? "coins" : row.tone === "ok" ? "form" : row.tone === "cyan" ? "live" : row.tone === "danger" ? "alert" : "note"
							})
						]
					}, row.id)) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dash, {
					title: "Astro",
					className: "xl:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifiedMark, { verified: account.verified }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-3xl font-medium tabular-nums text-ok",
							children: fee
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Seller fee on the Official shop. Astro also drops 150 coins each month and an animated banner for one group."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm",
							children: account.business ? account.businessName : "Not a business yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							className: "mt-4 w-full",
							onClick: () => onOpen("shop"),
							children: account.business ? "List a product" : "Open a business"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {
					title: "Communities",
					className: "xl:col-span-3",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
						onClick: () => onOpen("social"),
						children: "Social"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-1",
						children: clans.map((clan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpen("groups"),
							className: "flex min-h-14 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-11 w-11 shrink-0 place-items-center text-base font-medium",
									children: clan.name.slice(0, 1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm",
										children: clan.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-faint",
										children: [clan.memberIds.length, " players"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted",
									children: clanTier(clan.memberIds.length)
								})
							]
						}) }, clan.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dash, {
					title: "Leaderboard",
					className: "xl:col-span-5",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
						onClick: () => onOpen("rankings"),
						children: "Ranks"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[1.4rem_minmax(0,1fr)_auto] gap-x-3 px-1 font-mono text-xs text-faint",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "#" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Player" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Score" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1",
						children: board.map((identity, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpenPlayer(identity.id),
							className: "grid min-h-12 w-full grid-cols-[1.4rem_minmax(0,1fr)_auto] items-center gap-x-3 rounded-2xl px-1 text-left hover:bg-bg-subtle",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-faint",
									children: index + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex min-w-0 items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
										name: identity.name,
										id: identity.id,
										size: "sm"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `flex min-w-0 items-center gap-1 truncate text-sm ${identity.id === viewer.id ? "text-ok" : ""}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: identity.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeRow, {
											pins: (badgeMap[identity.id]?.featured ?? []).slice(0, 2),
											size: 14
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted",
									children: identity.score.toLocaleString("en-US")
								})
							]
						}) }, identity.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {
					title: "Official shop",
					className: "md:col-span-2 xl:col-span-4",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
						onClick: () => onOpen("shop"),
						children: "Shop"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: products.slice(0, 3).map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpen("shop"),
							className: "card-lift flex min-h-16 items-center gap-3 rounded-2xl bg-bg-subtle px-3 py-2 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-11 w-11 shrink-0 place-items-center text-sm font-medium",
									children: specFor(product.kind).name.slice(0, 1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm",
										children: product.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-mono text-xs text-faint",
										children: specFor(product.kind).name
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-ok",
									children: formatCoins(product.price)
								})
							]
						}, product.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {
					title: "Session",
					className: "md:col-span-2 xl:col-span-12",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-violet/20 px-3 py-1 font-mono text-xs text-fg",
						children: viewer.form
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
						series,
						label: "Session chart"
					})
				})
			]
		})]
	});
}
var RARITIES = [
	"common",
	"uncommon",
	"rare",
	"epic",
	"legendary",
	"relic"
];
var BOARD = [
	{
		title: "IRONWAKE Harbor",
		sellerId: "koba_mara",
		price: 180,
		rarity: "legendary",
		kind: "map",
		game: "Rust Console",
		auction: "5m",
		productId: null
	},
	{
		title: "Rig 19 cycle",
		sellerId: "koba_harrow",
		price: 90,
		rarity: "epic",
		kind: "plugin",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Northline ice chart",
		sellerId: "koba_ysolde",
		price: 70,
		rarity: "rare",
		kind: "map",
		game: "Rust Console",
		auction: "18m",
		productId: null
	},
	{
		title: "Saltflat plot",
		sellerId: "koba_nora",
		price: 12,
		rarity: "common",
		kind: "map",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Cherno night route",
		sellerId: "koba_nora",
		price: 140,
		rarity: "legendary",
		kind: "map",
		game: "DayZ",
		auction: "12m",
		productId: null
	},
	{
		title: "Black Coast stash",
		sellerId: "koba_ysolde",
		price: 220,
		rarity: "relic",
		kind: "asset",
		game: "DayZ",
		auction: "2m",
		productId: null
	},
	{
		title: "Clinic ledger",
		sellerId: "koba_dex",
		price: 16,
		rarity: "common",
		kind: "plugin",
		game: "DayZ",
		auction: null,
		productId: null
	},
	{
		title: "Harbor bag key",
		sellerId: "koba_mara",
		price: 28,
		rarity: "uncommon",
		kind: "asset",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Oil timer",
		sellerId: "koba_harrow",
		price: 48,
		rarity: "rare",
		kind: "plugin",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Ice war horn",
		sellerId: "koba_ysolde",
		price: 36,
		rarity: "rare",
		kind: "asset",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Monument wake",
		sellerId: "koba_mara",
		price: 260,
		rarity: "relic",
		kind: "map",
		game: "Rust Console",
		auction: "9m",
		productId: null
	},
	{
		title: "South road signs",
		sellerId: "koba_dex",
		price: 22,
		rarity: "uncommon",
		kind: "plugin",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Inland rifle roll",
		sellerId: "koba_nora",
		price: 85,
		rarity: "epic",
		kind: "asset",
		game: "DayZ",
		auction: null,
		productId: null
	},
	{
		title: "Low-pop builder kit",
		sellerId: "koba_harrow",
		price: 18,
		rarity: "common",
		kind: "plugin",
		game: "Rust Console",
		auction: null,
		productId: null
	},
	{
		title: "Wipe calendar",
		sellerId: "koba_mara",
		price: 24,
		rarity: "uncommon",
		kind: "plugin",
		game: "Network",
		auction: null,
		productId: null
	},
	{
		title: "First blood mark",
		sellerId: "koba_ysolde",
		price: 110,
		rarity: "epic",
		kind: "asset",
		game: "Clan war",
		auction: "26m",
		productId: null
	}
];
function rarityForPrice(price) {
	if (price >= 160) return "relic";
	if (price >= 120) return "legendary";
	if (price >= 70) return "epic";
	if (price >= 35) return "rare";
	if (price >= 20) return "uncommon";
	return "common";
}
function marketLots(products) {
	const listed = products.map((product) => ({
		id: product.id,
		title: product.title,
		sellerId: product.sellerId,
		price: product.price,
		rarity: rarityForPrice(product.price),
		kind: "asset",
		game: product.game,
		auction: null,
		productId: product.id
	}));
	const extras = BOARD.map((row, index) => ({
		...row,
		id: `board-${index}`
	}));
	return [...listed, ...extras];
}
function MarketBoard({ identities, products, onOpen }) {
	const lots = (0, import_react.useMemo)(() => marketLots(products), [products]);
	const [rarity, setRarity] = (0, import_react.useState)("all");
	const [shown, setShown] = (0, import_react.useState)(6);
	const [focus, setFocus] = (0, import_react.useState)(null);
	const [held, setHeld] = (0, import_react.useState)(null);
	const [bids, setBids] = (0, import_react.useState)({});
	const [watch, setWatch] = (0, import_react.useState)([]);
	const freshFrom = (0, import_react.useRef)(0);
	const sentinel = (0, import_react.useRef)(null);
	const filtered = rarity === "all" ? lots : lots.filter((lot) => lot.rarity === rarity);
	const visible = filtered.slice(0, shown);
	const featured = lots.filter((lot) => lot.rarity === "legendary" || lot.rarity === "relic" || lot.rarity === "epic").slice(0, 6);
	const ticks = lots.filter((lot) => lot.auction || lot.productId).slice(0, 8);
	const online = LISTINGS.reduce((sum, listing) => sum + listing.players, 0);
	const nameFor = (id) => identities.find((identity) => identity.id === id)?.name ?? "KOBA";
	(0, import_react.useEffect)(() => {
		if (!focus) return;
		document.getElementById(`lot-${focus}`)?.scrollIntoView({
			behavior: "smooth",
			block: "center"
		});
	}, [
		focus,
		shown,
		rarity
	]);
	(0, import_react.useEffect)(() => {
		const node = sentinel.current;
		if (!node) return;
		const observer = new IntersectionObserver((entries) => {
			if (!entries.some((entry) => entry.isIntersecting)) return;
			setShown((count) => {
				if (count >= filtered.length) return count;
				freshFrom.current = count;
				return Math.min(filtered.length, count + 6);
			});
		});
		observer.observe(node);
		return () => observer.disconnect();
	}, [filtered.length, rarity]);
	const pick = (next) => {
		freshFrom.current = 0;
		setRarity(next);
		setShown(6);
		setFocus(null);
	};
	const jump = (lot) => {
		freshFrom.current = 0;
		setRarity("all");
		setShown(lots.length);
		setFocus(lot.id);
	};
	const buy = (lot) => onOpen(lot.productId ? "shop" : "discover");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid min-w-0 gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dash-card flex min-w-0 items-center gap-3 px-3",
				"data-noswipe": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex shrink-0 items-center gap-2 font-mono text-xs tracking-widest text-ok uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-ok" }), "Live"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ticker min-w-0 flex-1 py-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ticker-track",
						children: [0, 1].map((copy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex",
							children: ticks.map((lot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => jump(lot),
								className: "min-h-11 shrink-0 px-4 text-left text-sm text-fg",
								children: lot.auction ? `Auction for ${lot.title} ending in ${lot.auction}` : `${nameFor(lot.sellerId)} listed ${lot.title}`
							}, `${copy}-${lot.id}`))
						}, copy))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 gap-2 overflow-x-auto pb-1",
				"data-noswipe": true,
				role: "toolbar",
				"aria-label": "Rarity",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityPill, {
					label: "All",
					on: rarity === "all",
					onClick: () => pick("all")
				}), RARITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityPill, {
					label: item,
					on: rarity === item,
					onClick: () => pick(item)
				}, item))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Featured"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-ok",
						children: "Trending up"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-w-0 snap-x snap-mandatory gap-3 overflow-x-auto pb-1",
					"data-noswipe": true,
					children: featured.map((lot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LotCard, {
						lot,
						seller: nameFor(lot.sellerId),
						verified: accountFor(lot.sellerId, {}).verified,
						held: held === lot.id,
						bid: bids[lot.id] ?? 0,
						watched: watch.includes(lot.id),
						featured: true,
						onHold: setHeld,
						onBuy: () => buy(lot),
						onBid: () => setBids((current) => ({
							...current,
							[lot.id]: (current[lot.id] ?? lot.price) + 5
						})),
						onWatch: () => setWatch((current) => current.includes(lot.id) ? current.filter((id) => id !== lot.id) : [...current, lot.id]),
						onOpen: () => jump(lot)
					}, lot.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dash-card grid grid-cols-3 gap-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-muted uppercase",
						children: "Servers"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-medium tabular-nums",
						children: LISTINGS.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-mono text-xs tracking-widest text-ok uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-ok" }), "Online"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-medium tabular-nums",
						children: online
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-muted uppercase",
						children: "Events"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-medium tabular-nums",
						children: BOUNTIES.length
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Board"
					}),
					filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Nothing listed in this tier."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
						children: visible.map((lot, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: index >= freshFrom.current ? "lot-in" : void 0,
							style: { animationDelay: `${index % 6 * 40}ms` },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LotCard, {
								lot,
								seller: nameFor(lot.sellerId),
								verified: accountFor(lot.sellerId, {}).verified,
								held: held === lot.id,
								focused: focus === lot.id,
								bid: bids[lot.id] ?? 0,
								watched: watch.includes(lot.id),
								onHold: setHeld,
								onBuy: () => buy(lot),
								onBid: () => setBids((current) => ({
									...current,
									[lot.id]: (current[lot.id] ?? lot.price) + 5
								})),
								onWatch: () => setWatch((current) => current.includes(lot.id) ? current.filter((id) => id !== lot.id) : [...current, lot.id]),
								onOpen: () => jump(lot)
							})
						}, lot.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: sentinel,
						className: "h-6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center font-mono text-xs text-faint",
						children: shown < filtered.length ? "More on the board" : "That's the board."
					})
				]
			})
		]
	});
}
function RarityPill({ label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `min-h-11 shrink-0 rounded-full px-4 text-sm capitalize ${on ? "bg-ok text-bg" : "bg-bg-subtle text-muted"}`,
		children: label
	});
}
function LotCard({ lot, seller, verified, held, focused = false, bid, watched, featured = false, onHold, onBuy, onBid, onWatch, onOpen }) {
	const premium = lot.rarity === "legendary" || lot.rarity === "relic";
	const high = bid || lot.price;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		id: featured ? void 0 : `lot-${lot.id}`,
		"data-rarity": lot.rarity,
		className: `lot-card dash-card p-3 ${featured ? "w-64 shrink-0 snap-start" : ""} ${held ? "is-held" : ""} ${premium ? "is-shimmer" : ""} ${focused ? "is-focus" : ""}`,
		onPointerDown: () => onHold(lot.id),
		onPointerUp: () => onHold(null),
		onPointerCancel: () => onHold(null),
		onPointerLeave: () => onHold(null),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onOpen,
				className: "lot-preview grid h-28 w-full place-items-center rounded-2xl text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-mono text-xs tracking-widest text-muted uppercase",
					children: lot.kind
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-lg font-medium",
					children: lot.title
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 truncate text-sm",
					children: seller
				}), verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifiedMark, { verified: true }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 font-mono text-xs text-muted",
					children: "Unverified"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 font-mono text-xs text-muted capitalize",
				children: [
					lot.rarity,
					" · ",
					lot.auction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuctionClock, {
						label: lot.auction,
						high
					}) : `${formatCoins(lot.price)} coins`
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				className: "mt-3 w-full",
				onClick: lot.auction ? onBid : onBuy,
				children: lot.auction ? `Bid ${formatCoins(high + 5)}` : "Buy now"
			}),
			lot.auction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onWatch,
				className: "mt-2 min-h-11 w-full text-sm text-muted",
				children: watched ? "Watching" : "Watch"
			}) : null
		]
	});
}
function AuctionClock({ label, high }) {
	const minutes = Number.parseInt(label, 10);
	const [left, setLeft] = (0, import_react.useState)(Number.isFinite(minutes) ? minutes * 60 : 0);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setLeft((value) => Math.max(0, value - 1)), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	const shown = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
		"high ",
		formatCoins(high),
		" · ",
		left === 0 ? "closed" : shown
	] });
}
function Dash({ title, action, children, className, fold = false }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	if (!fold) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("dash-card min-w-0 p-4", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-mono text-xs tracking-widest text-faint uppercase",
				children: title
			}), action]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 min-w-0",
			children
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("dash-card min-w-0 p-4", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-expanded": open,
			onClick: () => setOpen((value) => !value),
			className: "flex min-h-11 w-full items-center justify-between gap-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-mono text-xs tracking-widest text-faint uppercase",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [action, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					size: 16,
					"aria-hidden": true,
					className: `text-muted transition-transform ${open ? "rotate-180" : ""}`
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `fold ${open ? "is-open" : ""}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-w-0 pt-3",
				children
			}) })
		})]
	});
}
function ScoreReadout({ score, delta, rank, up }) {
	const [pop, setPop] = (0, import_react.useState)(false);
	const [floater, setFloater] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || delta === 0) return;
		setPop(true);
		setFloater(delta);
		const timer = window.setTimeout(() => {
			setPop(false);
			setFloater(null);
		}, 860);
		return () => window.clearTimeout(timer);
	}, [delta, score]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-3xl font-medium tabular-nums tracking-tight",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountUp, {
					value: score,
					from: score - delta
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: `mt-1 font-mono text-xs ${up ? "text-ok" : "text-danger"} ${pop ? "session-pop" : ""}`,
				children: [
					"#",
					rank,
					" · ",
					up ? "+" : "",
					delta,
					" this session"
				]
			}),
			floater != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `float-gain ${floater >= 0 ? "text-ok" : "text-danger"}`,
				children: [floater > 0 ? "+" : "", floater]
			}) : null
		]
	});
}
var EMPTY_OWNED = [];
function CoinPocket({ region, coins, identityId, feed, products, onShop }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const owned = useCommunity((state) => state.owned[identityId]) ?? EMPTY_OWNED;
	const credits = feed.filter((row) => row.tone === "gold" || /coin/i.test(`${row.title} ${row.detail}`)).slice(0, 3);
	const history = products.filter((product) => owned.includes(product.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-expanded": open,
			onClick: () => setOpen((value) => !value),
			className: "min-h-11 text-left text-xs text-muted",
			children: [
				region,
				" · ",
				formatCoins(coins),
				" coins"
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 rounded-2xl bg-bg-subtle p-3 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-widest text-faint uppercase",
					children: "Balance"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KOBA coins" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-ok",
						children: formatCoins(coins)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-mono text-xs tracking-widest text-faint uppercase",
					children: "Recent credits"
				}),
				credits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: "No coin credits yet."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 grid gap-1",
					children: credits.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-muted",
						children: row.title
					}, row.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-mono text-xs tracking-widest text-faint uppercase",
					children: "Purchases"
				}),
				history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: "Nothing bought on this identity."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 grid gap-1",
					children: history.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: product.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-muted",
							children: formatCoins(product.price)
						})]
					}, product.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onShop,
					className: "mt-2 min-h-11 text-sm text-cyan",
					children: "Purchase history"
				})
			]
		}) : null]
	});
}
function ShopButton({ children, onClick }) {
	const [rips, setRips] = (0, import_react.useState)([]);
	const seq = (0, import_react.useRef)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "primary",
		className: "shop-cta relative mt-3 w-full",
		onClick,
		onPointerDown: (event) => {
			if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
			const rect = event.currentTarget.getBoundingClientRect();
			const id = ++seq.current;
			setRips((list) => [...list, {
				id,
				x: event.clientX - rect.left,
				y: event.clientY - rect.top
			}]);
			window.setTimeout(() => setRips((list) => list.filter((rip) => rip.id !== id)), 520);
		},
		children: [children, rips.map((rip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "ripple",
			style: {
				left: rip.x,
				top: rip.y
			}
		}, rip.id))]
	});
}
function TextLink({ children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "min-h-11 rounded-full px-2 text-sm text-cyan",
		children
	});
}
function GameBlock({ label, rows, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 last:mb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 font-mono text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: rows.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onOpen,
			className: "flex min-h-11 w-full items-center gap-3 rounded-2xl px-1 text-left hover:bg-bg-subtle",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid w-6 shrink-0 place-items-center text-xs text-cyan",
					children: listing.name.slice(0, 1)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 flex-1 truncate text-sm",
					children: listing.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "shrink-0 font-mono text-xs text-ok",
					children: [
						listing.players,
						"/",
						listing.cap
					]
				})
			]
		}) }, listing.id)) })]
	});
}
function Sparkline({ series, label }) {
	const w = 320;
	const h = 144;
	const forms = series.map((point) => point.form);
	const min = Math.min(...forms);
	const max = Math.max(...forms);
	const span = Math.max(1, max - min);
	const pts = series.map((point, index) => {
		return {
			x: Math.round(18 + index / Math.max(1, series.length - 1) * 284),
			y: Math.round(16 + (1 - (point.form - min) / span) * 96),
			label: point.label
		};
	});
	const line = pts.map((point, index) => `${index === 0 ? "M" : "L"}${point.x} ${point.y}`).join(" ");
	const last = pts[pts.length - 1];
	const first = pts[0];
	const fill = last && first ? `${line} L${last.x} 120 L${first.x} 120 Z` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-36 w-full",
		role: "img",
		"aria-label": label,
		children: [
			fill ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: fill,
				fill: "var(--color-cyan)",
				opacity: "0.22"
			}) : null,
			line ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: line,
				fill: "none",
				stroke: "var(--color-cyan)",
				strokeWidth: "2.5",
				strokeLinejoin: "round",
				strokeLinecap: "round"
			}) : null,
			pts.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: point.x,
				y: 138,
				textAnchor: "middle",
				fill: "var(--color-faint)",
				fontSize: "11",
				fontFamily: "IBM Plex Mono, ui-monospace, monospace",
				children: point.label
			}, point.label))
		]
	});
}
function Bars({ series, label }) {
	const w = 320;
	const h = 128;
	const max = Math.max(...series.map((point) => point.form), 1);
	const gap = 8;
	const width = (w - gap * (series.length + 1)) / Math.max(1, series.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-32 w-full",
		role: "img",
		"aria-label": label,
		children: series.map((point, index) => {
			const bar = Math.round(point.form / max * 96);
			const x = Math.round(gap + index * (width + gap));
			const y = 106 - bar;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x,
				y,
				width: Math.round(width),
				height: bar,
				rx: "6",
				fill: "var(--color-violet)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: x + Math.round(width / 2),
				y: 122,
				textAnchor: "middle",
				fill: "var(--color-faint)",
				fontSize: "11",
				fontFamily: "IBM Plex Mono, ui-monospace, monospace",
				children: point.label
			})] }, point.label);
		})
	});
}
function StickerMark({ sticker }) {
	const tone = sticker.tone === "cyan" ? "border-cyan text-cyan" : sticker.tone === "gold" ? "border-warn text-warn" : "border-ok text-ok";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `grid h-16 w-16 place-items-center rounded-2xl border bg-bg ${tone}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] font-medium tracking-wide uppercase",
			children: sticker.name
		})
	});
}
function MessagesPage({ viewer, identities, onStory }) {
	const directs = useCommunity((s) => s.directs);
	const activeThread = useCommunity((s) => s.activeThread);
	const setActiveThread = useCommunity((s) => s.setActiveThread);
	const openThread = useCommunity((s) => s.openThread);
	const sendDirect = useCommunity((s) => s.sendDirect);
	const packs = useCommunity((s) => s.packs);
	const ownedPacks = useCommunity((s) => s.ownedPacks);
	const [text, setText] = (0, import_react.useState)("");
	const [picker, setPicker] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const mine = directs.filter((thread) => thread.a === viewer.id || thread.b === viewer.id);
	const thread = mine.find((item) => item.id === activeThread) ?? mine[0];
	const others = identities.filter((identity) => identity.id !== viewer.id);
	const nameFor = (id) => identities.find((identity) => identity.id === id)?.name ?? id;
	const otherId = thread ? thread.a === viewer.id ? thread.b : thread.a : "";
	const available = packs.filter((pack) => (ownedPacks[viewer.id] ?? []).includes(pack.id));
	const badgeMap = useResolvedBadges(identities);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 xl:grid-cols-[16rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "grid content-start gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Direct"
				}),
				mine.map((item) => {
					const other = item.a === viewer.id ? item.b : item.a;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveThread(item.id),
						className: `min-h-11 rounded-xl border px-3 text-left text-sm ${item.id === thread?.id ? "border-ok text-ok" : "border-border"}`,
						children: nameFor(other)
					}, item.id);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSelect, {
					className: "mt-2",
					label: "Start with",
					ariaLabel: "Start a direct message",
					placeholder: "Choose a player",
					value: "",
					options: others.map((identity) => ({
						value: identity.id,
						label: identity.name,
						hint: `@${identity.handle}`
					})),
					onChange: (id) => {
						if (id) openThread(viewer.id, id);
					}
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "grid min-h-[24rem] content-start gap-3 rounded-2xl border border-border bg-bg-elevated p-4",
			children: thread ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: nameFor(otherId)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: thread.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-border bg-bg p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-1 text-xs text-cyan",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: nameFor(message.authorId) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeRow, {
									pins: (badgeMap[message.authorId]?.featured ?? []).slice(0, 4),
									size: 14
								})]
							}),
							message.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm",
								children: message.text
							}) : null,
							message.sticker ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerMark, { sticker: {
									name: message.sticker,
									tone: "ok"
								} }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-[10px] text-faint",
									children: message.packTitle
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 min-h-11 text-xs text-cyan",
								onClick: () => {
									onStory(message.text, message.sticker);
									setNote("Added to your story.");
								},
								children: "Add to story"
							})
						]
					}, message.id))
				}),
				picker ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-4 gap-2",
					"data-noswipe": true,
					children: [available.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-4 text-sm text-muted",
						children: "Buy a sticker pack in the shop to send stickers."
					}) : null, available.flatMap((pack) => pack.stickers.map((sticker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid min-h-11 place-items-center",
						onClick: () => {
							sendDirect(thread.id, viewer.id, "", {
								name: sticker.name,
								packTitle: pack.title
							});
							setPicker(false);
						},
						"aria-label": `Send ${sticker.name}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerMark, { sticker })
					}, sticker.id)))]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-auto flex gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						sendDirect(thread.id, viewer.id, text);
						setText("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: text,
							onChange: (event) => setText(event.target.value),
							placeholder: "Message",
							className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "quiet",
							onClick: () => setPicker((open) => !open),
							children: "Stickers"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Send"
						})
					]
				}),
				note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-ok",
					children: note
				}) : null
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No thread yet. Start one from the list."
			})
		})]
	});
}
var STATUS = {
	clear: {
		label: "Clear",
		tone: "ok"
	},
	warned: {
		label: "Warned",
		tone: "warn"
	},
	struck: {
		label: "Struck",
		tone: "danger"
	},
	under_review: {
		label: "Under review",
		tone: "danger"
	},
	blacklisted: {
		label: "Blacklisted",
		tone: "danger"
	}
};
function ProfilePage({ viewer, account, rank, clanName, followed, onFollow, onShop, self, subscribed, equippedName }) {
	const [game, setGame] = (0, import_react.useState)("rust");
	const [playing, setPlaying] = (0, import_react.useState)(null);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const series = (0, import_react.useMemo)(() => formSeries(viewer), [viewer]);
	const meta = metaFor(viewer.id, viewer.score);
	const status = STATUS[viewer.status];
	const shown = scoreFor(viewer.id, viewer.score, game);
	const badges = useResolvedBadges([viewer])[viewer.id];
	const recent = LISTINGS.find((listing) => listing.region === meta.region) ?? LISTINGS[0];
	const hours = Math.max(12, Math.round(viewer.score / 40));
	const rating = Math.max(3.2, 4.9 - viewer.strikes * .4).toFixed(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-cyan",
						children: viewer.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-medium tracking-tight",
							children: viewer.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifiedMark, { verified: account.verified })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"@",
							viewer.handle,
							" · ",
							meta.region,
							" · ",
							clanName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeRow, {
							pins: badges?.featured ?? [],
							size: 22,
							enter: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							account.business && account.businessName ? `${account.businessName} · business` : "Player account",
							" · Astro fee ",
							quote(100, account.verified).label
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [subscribed ? `Astro active · ${ASTRO_PRICE} · 150 coins each renewal · animated group banner` : `No Astro pass · ${ASTRO_PRICE} · includes 150 coins a month and one animated group banner`, equippedName ? ` · ${equippedName}` : ""]
					})
				] }), self ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onShop,
					className: "min-h-11 rounded-lg border border-border px-3 text-sm",
					children: "Official shop"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onFollow,
					className: "min-h-11 rounded-lg border border-border px-3 text-sm",
					children: followed ? "Following" : "Follow"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-mono text-xs tracking-widest text-faint uppercase",
						children: "Trust"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Standing"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "mt-1",
								children: [
									account.verified ? "Verified" : "Unverified",
									" · ",
									status.label
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Strikes"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-mono text-xs",
								children: viewer.strikes
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Hours"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-mono text-xs",
								children: hours
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Group"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: clanName
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Recent server"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: recent?.name
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Seller rating"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-mono text-xs text-ok",
								children: rating
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipRow, {
							identityId: viewer.id,
							identities: [viewer],
							playing,
							onPlay: setPlaying
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-bg-elevated p-4 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-faint",
								children: ["Rank #", rank]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								tone: status.tone,
								children: status.label
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-4xl font-medium tabular-nums tracking-tight",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountUp, {
								value: shown,
								from: game === "rust" ? shown - viewer.scoreDelta : shown
							}, `${viewer.id}-${game}`)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: `mt-1 font-mono text-xs ${viewer.scoreDelta >= 0 ? "text-ok" : "text-danger"}`,
							children: [
								viewer.scoreDelta >= 0 ? "↑" : "↓",
								" ",
								Math.abs(viewer.scoreDelta),
								" this session · ",
								viewer.form
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex gap-2",
							children: [["rust", "Rust Console"], ["dayz", "DayZ"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": game === id,
								onClick: () => setGame(id),
								className: `min-h-11 rounded-lg border px-3 text-sm ${game === id ? "border-cyan text-cyan" : "border-border text-muted"}`,
								children: label
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: game === "rust" ? "Rust Console score is the identity’s main KOBA number." : "DayZ score is tracked separately. It does not replace the global rank."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-28",
							children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
									data: series,
									margin: {
										top: 8,
										right: 0,
										left: 0,
										bottom: 0
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "label",
											tick: {
												fill: "var(--color-faint)",
												fontSize: 11
											},
											axisLine: false,
											tickLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											hide: true,
											domain: ["dataMin - 8", "dataMax + 8"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
											background: "var(--color-bg-elevated)",
											border: "1px solid var(--color-border)",
											borderRadius: 8,
											color: "var(--color-fg)",
											fontSize: 12
										} }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "form",
											name: "Form",
											stroke: "var(--color-ok)",
											fill: "var(--color-ok)",
											fillOpacity: .16,
											strokeWidth: 2,
											isAnimationActive: false
										})
									]
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-lg bg-bg-subtle" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-bg-elevated p-4 lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Badges"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Flair sits on the name. Achievements climb as the record grows. Tap a pin to read it."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: badges ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeBoard, { result: badges }) : null
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-bg-elevated p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Linked"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Steam",
								value: viewer.steamId ?? "Not linked"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Discord",
								value: viewer.discordId ?? "Not linked"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Coins",
								value: formatCoins(viewer.coins)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Strikes",
								value: `${viewer.strikes}/3`
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-bg-elevated p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Homes"
						}),
						viewer.homes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "No homes set. The cap is 3."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 grid gap-3",
							children: viewer.homes.map((home) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: home.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-muted",
								children: [
									home.x.toFixed(1),
									", ",
									home.y.toFixed(1),
									", ",
									home.z.toFixed(1)
								]
							})] }, home.name))
						})
					]
				})]
			})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-xs",
			children: value
		})]
	});
}
function RankingsPage({ identities, viewerId, game, region, follows, clanIds, onGame, onRegion, onOpen }) {
	const rows = identities.filter((identity) => region === "all" || metaFor(identity.id, identity.score).region === region).map((identity) => ({
		identity,
		score: scoreFor(identity.id, identity.score, game)
	})).sort((a, b) => b.score - a.score);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "Rankings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "KOBA Score, not a single game’s raw kills. Switch the board when you care about DayZ instead of Rust."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [[
					["all", "All games"],
					["rust", "Rust Console"],
					["dayz", "DayZ"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": game === id,
					onClick: () => onGame(id),
					className: `min-h-11 rounded-lg border px-3 text-sm ${game === id ? "border-fg bg-fg text-bg" : "border-border text-muted"}`,
					children: label
				}, id)), [
					"all",
					"NA",
					"EU",
					"OCE"
				].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": region === id,
					onClick: () => onRegion(id),
					className: `min-h-11 rounded-lg border px-3 text-sm ${region === id ? "border-cyan text-cyan" : "border-border text-muted"}`,
					children: id === "all" ? "All regions" : id
				}, id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "rounded-3xl border border-border bg-bg-elevated",
				children: [rows.map((row, index) => {
					const friend = follows.includes(row.identity.id);
					const clan = clanIds.includes(row.identity.id);
					const you = row.identity.id === viewerId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-border last:border-b-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onOpen(row.identity.id),
							className: "flex min-h-14 w-full items-center justify-between gap-3 px-4 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-faint",
										children: String(index + 1).padStart(2, "0")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-3 text-sm",
										children: row.identity.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-0.5 block text-sm text-muted sm:mt-0 sm:ml-8 sm:inline",
										children: [
											metaFor(row.identity.id, row.identity.score).region,
											you ? " · you" : "",
											friend ? " · followed" : "",
											clan ? " · clan" : ""
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-mono text-sm tabular-nums",
									children: row.score.toLocaleString("en-US")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `font-mono text-xs ${row.identity.scoreDelta >= 0 ? "text-ok" : "text-danger"}`,
									children: [
										row.identity.scoreDelta >= 0 ? "↑" : "↓",
										" ",
										Math.abs(row.identity.scoreDelta)
									]
								})]
							})]
						})
					}, row.identity.id);
				}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-4 py-6 text-sm text-muted",
					children: "Nobody on this board."
				}) : null]
			})
		]
	});
}
function SocialPage({ viewer, identities, clans, follows, onFollow, onOpen }) {
	const mine = clans.find((clan) => clan.id === viewer.clanId);
	const followed = identities.filter((identity) => follows.includes(identity.id));
	const suggestions = identities.filter((identity) => identity.id !== viewer.id && !follows.includes(identity.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium tracking-tight",
			children: "Social"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-xl text-sm text-muted",
			children: "People you follow, and the clan roster on this identity."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Following"
					}),
					followed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "You are not following anyone yet."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid",
						children: followed.map((identity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 border-b border-border py-2 last:border-b-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onOpen(identity.id),
								className: "min-h-11 text-left text-sm",
								children: identity.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => onFollow(identity.id),
								children: "Unfollow"
							})]
						}, identity.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-5 text-sm font-medium",
						children: "Suggested"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid",
						children: suggestions.map((identity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 border-b border-border py-2 last:border-b-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpen(identity.id),
								className: "min-h-11 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm",
									children: identity.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-faint",
									children: identity.handle
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "primary",
								onClick: () => onFollow(identity.id),
								children: "Follow"
							})]
						}, identity.id))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: mine ? mine.name : "No clan"
						}), mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							tone: "cyan",
							children: clanTier(mine.memberIds.length)
						}) : null]
					}),
					!mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Join a roster from a clan page once recruitment is open. This identity is unaffiliated."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid",
						children: mine?.memberIds.map((id) => {
							const member = identities.find((identity) => identity.id === id);
							if (!member) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpen(id),
								className: "flex min-h-11 w-full items-baseline justify-between text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: member.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs tabular-nums text-muted",
									children: member.score
								})]
							}) }, id);
						})
					})
				]
			})]
		})]
	});
}
function StoriesPage({ viewer, identities }) {
	const stories = useCommunity((s) => s.stories);
	const addStory = useCommunity((s) => s.addStory);
	const [open, setOpen] = (0, import_react.useState)(stories[0]?.id ?? null);
	const [text, setText] = (0, import_react.useState)("");
	const nameFor = (id) => identities.find((identity) => identity.id === id)?.name ?? id;
	const authors = [...new Set(stories.map((story) => story.authorId))];
	const current = stories.find((story) => story.id === open) ?? stories[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-3 overflow-x-auto pb-1",
				"data-noswipe": true,
				children: authors.map((authorId) => {
					const latest = stories.find((story) => story.authorId === authorId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => latest && setOpen(latest.id),
						className: "grid w-16 shrink-0 justify-items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-14 w-14 place-items-center rounded-full text-xs ${authorId === viewer.id ? "text-ok" : "text-cyan"}`,
							children: nameFor(authorId).slice(0, 1)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-16 truncate text-[10px] text-muted",
							children: nameFor(authorId)
						})]
					}, authorId);
				})
			}),
			current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-3xl border border-border bg-bg-elevated p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-cyan",
						children: nameFor(current.authorId)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xl font-medium",
						children: current.text
					}),
					current.sticker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 inline-flex rounded-2xl border border-ok px-4 py-3 text-sm text-ok",
						children: current.sticker
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No stories yet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-wrap gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					addStory(viewer.id, text);
					setText("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					onChange: (event) => setText(event.target.value),
					placeholder: "Add to your story",
					className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Add to story"
				})]
			})
		]
	});
}
function pickedServer(state) {
	return state.servers.find((server) => server.id === state.activeServerId) ?? state.servers[0];
}
async function signed(data, body, hostKey, pluginKey, forge = false) {
	const plugin_signature = forge ? "00".repeat(32) : await signPacket(pluginKey, body);
	return {
		...body,
		hostKey,
		plugin_signature
	};
}
var usePlatform = create((set, get) => ({
	...seedPlatform(),
	role: "player",
	hq: false,
	game: "RUST_CONSOLE",
	fps: 72,
	capacity: "nominal",
	lastIngest: null,
	lastEmbed: null,
	activeServerId: "srv-iron",
	setViewer: (viewerId) => set({ viewerId }),
	setRole: (role) => set({ role }),
	setHq: (hq) => set({ hq }),
	setGame: (game) => set({ game }),
	setServer: (activeServerId) => set({ activeServerId }),
	setFps: (fps) => set((state) => ({
		fps,
		capacity: nextCapacity(fps, state.capacity)
	})),
	run: (line) => {
		const state = get();
		const result = routeCommand(state, line, state.role, state.hq, state.game, Date.now());
		set({
			...result.data,
			role: state.role,
			hq: state.hq,
			game: state.game,
			fps: state.fps,
			capacity: state.capacity,
			lastIngest: state.lastIngest,
			lastEmbed: result.embed
		});
		return result.embed;
	},
	emitCombat: async (steamId) => {
		const state = get();
		const server = pickedServer(state);
		const attacker = steamId ?? state.identities.find((identity) => identity.id === state.viewerId)?.steamId ?? "76561198999900001";
		const attackerName = state.identities.find((identity) => identity.steamId === attacker)?.name ?? "Unlinked rifle";
		const packet = await signed(state, {
			serverId: server.id,
			kind: "combat",
			at: Date.now(),
			attackerSteam: attacker,
			attackerName,
			victimSteam: "76561198000002144",
			victimName: "Nora Keel",
			weapon: "rifle.ak",
			distance: 42,
			hitZone: "head",
			pve: false
		}, server.hostKey, server.pluginKey);
		const ingested = await ingest(get(), packet, Date.now());
		set({
			...ingested.data,
			lastIngest: ingested.result
		});
	},
	emitRaid: async () => {
		const state = get();
		const server = pickedServer(state);
		const packet = await signed(state, {
			serverId: server.id,
			kind: "raid",
			at: Date.now(),
			attackerSteam: state.identities.find((identity) => identity.id === "koba_ysolde").steamId,
			attackerName: "Ysolde Voss",
			entity: "cupboard.tool",
			damage: 86,
			ownerSteam: "76561198000001840",
			weapon: "explosive.timed"
		}, server.hostKey, server.pluginKey);
		const ingested = await ingest(get(), packet, Date.now());
		set({
			...ingested.data,
			lastIngest: ingested.result
		});
	},
	emitForged: async () => {
		const state = get();
		const server = pickedServer(state);
		const packet = await signed(state, {
			serverId: server.id,
			kind: "combat",
			at: Date.now(),
			attackerSteam: "76561198000001840",
			attackerName: "Mara Vale",
			victimSteam: "76561198000002144",
			victimName: "Nora Keel",
			weapon: "rifle.ak",
			distance: 10,
			hitZone: "chest",
			pve: false
		}, server.hostKey, server.pluginKey, true);
		const ingested = await ingest(get(), packet, Date.now());
		set({
			...ingested.data,
			lastIngest: ingested.result
		});
	},
	emitBurst: async () => {
		const server = pickedServer(get());
		let data = get();
		let last = null;
		const start = Date.now();
		for (let i = 0; i < 9; i++) {
			const body = {
				serverId: server.id,
				kind: "combat",
				at: start,
				attackerSteam: "76561198000001840",
				attackerName: "Mara Vale",
				victimSteam: "76561198000002144",
				victimName: "Nora Keel",
				weapon: "rifle.ak",
				distance: 18 + i,
				hitZone: "chest",
				pve: false
			};
			const packet = await signed(data, body, server.hostKey, server.pluginKey);
			const ingested = await ingest(data, packet, start);
			data = ingested.data;
			last = ingested.result;
		}
		set({
			identities: data.identities,
			clans: data.clans,
			servers: data.servers,
			events: data.events,
			provisional: data.provisional,
			attempts: data.attempts,
			feed: data.feed,
			audit: data.audit,
			viewerId: data.viewerId,
			seq: data.seq,
			lastIngest: last
		});
	},
	reset: () => set({
		...seedPlatform(),
		role: "player",
		hq: false,
		game: "RUST_CONSOLE",
		fps: 72,
		capacity: "nominal",
		lastIngest: null,
		lastEmbed: null,
		activeServerId: "srv-iron"
	}),
	applySale: (sale) => {
		const state = get();
		const buyer = state.identities.find((identity) => identity.id === sale.buyerId);
		const seller = state.identities.find((identity) => identity.id === sale.sellerId);
		if (!buyer || !seller) return {
			ok: false,
			reason: "That identity is not on the network."
		};
		if (buyer.id === seller.id) return {
			ok: false,
			reason: "You cannot buy your own listing."
		};
		if (buyer.coins < sale.price) return {
			ok: false,
			reason: "Not enough coins."
		};
		const identities = state.identities.map((identity) => {
			if (identity.id === buyer.id) return {
				...identity,
				coins: money(identity.coins - sale.price)
			};
			if (identity.id === seller.id) return {
				...identity,
				coins: money(identity.coins + sale.payout)
			};
			return identity;
		});
		const seq = state.seq + 1;
		set({
			identities,
			seq,
			feed: [{
				id: `feed-${seq}`,
				at: seq,
				tone: "gold",
				title: sale.title,
				detail: sale.detail
			}, ...state.feed].slice(0, 40)
		});
		return { ok: true };
	}
}));
var KEY = "koba-account";
var USERS = "koba-users";
var OAUTH = [
	{
		id: "steam",
		label: "Steam",
		viewerId: "koba_mara",
		name: "Mara Vale",
		scopes: ["openid", "profile"],
		fill: "#171a21"
	},
	{
		id: "xbox",
		label: "Xbox",
		viewerId: "koba_nora",
		name: "Nora Voss",
		scopes: ["XboxLive.signin", "Gamertag"],
		fill: "#107C10"
	},
	{
		id: "discord",
		label: "Discord",
		viewerId: "koba_harrow",
		name: "Harrow Quinn",
		scopes: ["identify"],
		fill: "#5865F2"
	}
];
function readAccount() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(KEY);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function saveAccount(account) {
	if (typeof window === "undefined") return;
	if (!account) window.localStorage.removeItem(KEY);
	else window.localStorage.setItem(KEY, JSON.stringify(account));
}
function users() {
	try {
		const raw = window.localStorage.getItem(USERS);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
async function digest(salt, password) {
	const data = new TextEncoder().encode(`${salt}:${password}`);
	const buf = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(buf)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function AuthScreen({ onEnter }) {
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [oauth, setOauth] = (0, import_react.useState)(null);
	const submit = async () => {
		setError("");
		const mail = email.trim().toLowerCase();
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) {
			setError("Use a real email address.");
			return;
		}
		if (password.length < 8) {
			setError("Password needs at least 8 characters.");
			return;
		}
		setBusy(true);
		try {
			const list = users();
			if (mode === "up") {
				const display = name.trim();
				if (display.length < 2) {
					setError("Name needs at least 2 characters.");
					return;
				}
				if (list.some((user) => user.email === mail)) {
					setError("That email is already registered. Sign in instead.");
					return;
				}
				const salt = crypto.randomUUID();
				const hash = await digest(salt, password);
				const next = [...list, {
					email: mail,
					name: display,
					salt,
					hash
				}];
				window.localStorage.setItem(USERS, JSON.stringify(next));
				onEnter({
					provider: "email",
					name: display,
					email: mail,
					viewerId: "koba_mara"
				});
				return;
			}
			const found = list.find((user) => user.email === mail);
			if (!found) {
				setError("No account for that email. Register first.");
				return;
			}
			if (await digest(found.salt, password) !== found.hash) {
				setError("That password does not match.");
				return;
			}
			onEnter({
				provider: "email",
				name: found.name,
				email: mail,
				viewerId: "koba_mara"
			});
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg pb-28 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid flex-1 place-items-center px-4 py-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/brand/koba-wordmark.gif",
						alt: "KOBA",
						width: 435,
						height: 226,
						className: "mx-auto h-20 w-auto max-w-full object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-sm text-muted",
						children: "Sign in to the network. Email stays on KOBA. Steam, Xbox, and Discord use OAuth."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 rounded-3xl border border-border bg-bg-elevated p-4",
						children: oauth ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProviderMark, { id: oauth.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-medium",
										children: ["Authorize ", oauth.label]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "KOBA is requesting these scopes. No password is stored."
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "grid gap-1",
									children: oauth.scopes.map((scope) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "font-mono text-xs text-muted",
										children: scope
									}, scope))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: ["Continue as ", oauth.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										onClick: () => setOauth(null),
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "primary",
										disabled: busy,
										onClick: () => {
											setBusy(true);
											window.setTimeout(() => {
												onEnter({
													provider: oauth.id,
													name: oauth.name,
													viewerId: oauth.viewerId
												});
											}, 420);
										},
										children: busy ? "Authorizing…" : "Authorize"
									})]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "grid gap-3",
							onSubmit: (event) => {
								event.preventDefault();
								submit();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": mode === "in",
										onClick: () => setMode("in"),
										className: `min-h-11 rounded-2xl text-sm ${mode === "in" ? "fire-btn" : "bg-bg-subtle text-muted"}`,
										children: "Sign in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": mode === "up",
										onClick: () => setMode("up"),
										className: `min-h-11 rounded-2xl text-sm ${mode === "up" ? "fire-btn" : "bg-bg-subtle text-muted"}`,
										children: "Register"
									})]
								}),
								mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm",
									children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										suppressHydrationWarning: true,
										value: name,
										onChange: (event) => setName(event.target.value),
										autoComplete: "name",
										className: "h-11 rounded-xl border border-border bg-bg px-3"
									})]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm",
									children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										suppressHydrationWarning: true,
										value: email,
										onChange: (event) => setEmail(event.target.value),
										type: "email",
										autoComplete: "email",
										className: "h-11 rounded-xl border border-border bg-bg px-3"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm",
									children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										suppressHydrationWarning: true,
										value: password,
										onChange: (event) => setPassword(event.target.value),
										type: "password",
										autoComplete: mode === "up" ? "new-password" : "current-password",
										className: "h-11 rounded-xl border border-border bg-bg px-3"
									})]
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-danger",
									role: "alert",
									children: error
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "primary",
									type: "submit",
									disabled: busy,
									children: busy ? "Checking…" : mode === "up" ? "Create account" : "Sign in"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-center font-mono text-xs tracking-widest text-faint uppercase",
									children: "Or"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid gap-2",
									children: OAUTH.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setOauth(provider),
										className: "flex min-h-11 items-center gap-3 rounded-2xl border border-border bg-bg px-3 text-left text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProviderMark, { id: provider.id }),
											"Continue with ",
											provider.label
										]
									}, provider.id))
								})
							]
						})
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})]
	});
}
function ProviderMark({ id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: `/brand/logo-${id}.svg`,
		alt: "",
		width: 22,
		height: 22,
		className: "h-[22px] w-[22px] shrink-0"
	});
}
var NAV = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "groups",
		label: "Groups",
		icon: Users
	},
	{
		id: "messages",
		label: "DMs",
		icon: MessageSquare
	},
	{
		id: "shop",
		label: "Shop",
		icon: Store
	},
	{
		id: "profile",
		label: "Profile",
		icon: UserRound
	}
];
var TABS = [
	{
		id: "feed",
		label: "Feed"
	},
	{
		id: "discover",
		label: "Discover"
	},
	{
		id: "compete",
		label: "Compete"
	},
	{
		id: "rankings",
		label: "Rankings"
	},
	{
		id: "social",
		label: "Social"
	},
	{
		id: "stories",
		label: "Stories"
	}
];
var DESKS = [
	{
		id: "play",
		label: "Play"
	},
	{
		id: "business",
		label: "Business"
	},
	{
		id: "mod",
		label: "Mod"
	},
	{
		id: "admin",
		label: "Admin"
	},
	{
		id: "super",
		label: "Super"
	}
];
function PlatformApp() {
	const identities = usePlatform((s) => s.identities);
	const clans = usePlatform((s) => s.clans);
	const feed = usePlatform((s) => s.feed);
	const audit = usePlatform((s) => s.audit);
	const servers = usePlatform((s) => s.servers);
	const viewerId = usePlatform((s) => s.viewerId);
	const setViewer = usePlatform((s) => s.setViewer);
	const setRole = usePlatform((s) => s.setRole);
	const setHq = usePlatform((s) => s.setHq);
	const run = usePlatform((s) => s.run);
	const resetPlatform = usePlatform((s) => s.reset);
	const applySale = usePlatform((s) => s.applySale);
	const page = useSite((s) => s.page);
	const query = useSite((s) => s.query);
	const game = useSite((s) => s.game);
	const region = useSite((s) => s.region);
	const style = useSite((s) => s.style);
	const saved = useSite((s) => s.saved);
	const follows = useSite((s) => s.follows);
	const bounties = useSite((s) => s.bounties);
	const products = useSite((s) => s.products);
	const opened = useSite((s) => s.opened);
	const pulse = useSite((s) => s.pulse);
	const notice = useSite((s) => s.notice);
	const palette = useSite((s) => s.palette);
	const accountOpen = useSite((s) => s.accountOpen);
	const focusId = useSite((s) => s.focusId);
	const setPage = useSite((s) => s.setPage);
	const setQuery = useSite((s) => s.setQuery);
	const setGame = useSite((s) => s.setGame);
	const setRegion = useSite((s) => s.setRegion);
	const setStyle = useSite((s) => s.setStyle);
	const toggleSaved = useSite((s) => s.toggleSaved);
	const toggleFollow = useSite((s) => s.toggleFollow);
	const toggleBounty = useSite((s) => s.toggleBounty);
	const openBusiness = useSite((s) => s.openBusiness);
	const addProduct = useSite((s) => s.addProduct);
	const ping = useSite((s) => s.ping);
	const setPalette = useSite((s) => s.setPalette);
	const setAccountOpen = useSite((s) => s.setAccountOpen);
	const openProfile = useSite((s) => s.openProfile);
	const resetSite = useSite((s) => s.reset);
	const homeTab = useSite((s) => s.homeTab);
	const setHomeTab = useSite((s) => s.setHomeTab);
	const desk = useSite((s) => s.desk);
	const setDesk = useSite((s) => s.setDesk);
	const groups = useCommunity((s) => s.groups);
	const astroPass = useCommunity((s) => s.astroPass);
	const owned = useCommunity((s) => s.owned);
	const equipped = useCommunity((s) => s.equipped);
	const subscribe = useCommunity((s) => s.subscribe);
	const endPass = useCommunity((s) => s.endPass);
	const grantProduct = useCommunity((s) => s.grantProduct);
	const equip = useCommunity((s) => s.equip);
	const addStory = useCommunity((s) => s.addStory);
	const resetCommunity = useCommunity((s) => s.reset);
	const [session, setSession] = (0, import_react.useState)(null);
	const viewer = identities.find((identity) => identity.id === viewerId) ?? identities[0];
	const viewerAccount = viewer ? accountFor(viewer.id, opened) : null;
	const ranked = identities.slice().sort((a, b) => b.score - a.score);
	const rank = viewer ? ranked.findIndex((identity) => identity.id === viewer.id) + 1 : 1;
	const profile = identities.find((identity) => identity.id === (focusId ?? viewerId)) ?? viewer;
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
				event.preventDefault();
				setPalette(true);
			} else if (event.key === "Escape") {
				setPalette(false);
				setAccountOpen(false);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [setAccountOpen, setPalette]);
	(0, import_react.useEffect)(() => installTouchBridge(), []);
	(0, import_react.useEffect)(() => {
		setSession(readAccount());
	}, []);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthScreen, { onEnter: (next) => {
		saveAccount(next);
		setSession(next);
		setViewer(next.viewerId);
	} });
	if (!viewer || !profile || !viewerAccount) return null;
	const clanName = (id) => clans.find((clan) => clan.id === id)?.name ?? "Unaffiliated";
	const applySeat = (next) => {
		if (next === "super") {
			setRole("developer");
			setHq(true);
		} else if (next === "mod" || next === "admin") {
			setRole("admin");
			setHq(false);
		} else {
			setRole("player");
			setHq(false);
		}
	};
	const enter = (next) => {
		setDesk(next);
		applySeat(next);
	};
	const go = (next) => {
		applySeat("play");
		if (next === "profile") openProfile(viewer.id);
		else setPage(next);
	};
	const openTarget = (target) => {
		if (target === "discover" || target === "compete" || target === "rankings" || target === "social" || target === "stories" || target === "feed") {
			applySeat("play");
			setHomeTab(target);
			return;
		}
		go(target);
	};
	const challenge = (handle) => {
		const embed = run(`/challenge ${handle}`);
		ping(embed.title, embed.description);
	};
	const declareWar = (name) => {
		const embed = run(`/war declare ${name}`);
		ping(embed.title, embed.description);
	};
	const standDown = () => {
		const embed = run("/war end");
		ping(embed.title, embed.description);
	};
	const reset = () => {
		resetPlatform();
		resetSite();
		resetCommunity();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg xl:grid xl:grid-cols-[15rem_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden border-r border-border bg-bg-elevated/50 xl:flex xl:min-h-dvh xl:flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go("home"),
						"aria-label": "KOBA home",
						className: "px-4 pt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/brand/koba-wordmark.gif",
							alt: "",
							width: 435,
							height: 226,
							className: "h-16 w-full object-contain object-left"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-5 pt-2 text-sm text-muted",
						children: "Your gaming network"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-6 grid gap-1 px-3",
						"aria-label": "Primary",
						children: NAV.map((item) => {
							const on = desk === "play" && page === item.id;
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => go(item.id),
								"aria-current": on ? "page" : void 0,
								className: `flex min-h-12 items-center gap-3 rounded-2xl px-3 text-left text-sm ${on ? "nav-on" : "text-muted hover:bg-bg-subtle"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavGlyph, {
									icon: Icon,
									on
								}), item.label]
							}, item.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "sticky top-0 z-20 border-b border-border/80 bg-bg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto flex w-full max-w-7xl items-center gap-2 px-3 py-3 sm:gap-3 sm:px-4 lg:px-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => go("home"),
										"aria-label": "KOBA home",
										className: "grid h-11 w-11 shrink-0 place-items-center xl:hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: "/brand/koba-mark.gif",
											alt: "",
											width: 264,
											height: 264,
											className: "h-9 w-9 object-contain"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setPalette(true),
										className: "flex h-11 w-11 shrink-0 items-center justify-center text-muted sm:w-auto sm:flex-1 sm:justify-start sm:gap-2 sm:rounded-full sm:bg-bg-subtle sm:px-4",
										"aria-label": "Search",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
												size: 16,
												"aria-hidden": true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden truncate sm:inline",
												children: "Search players, servers, pages"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-auto hidden font-mono text-xs text-faint lg:inline",
												children: "Ctrl K"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => go("home"),
										className: "relative grid h-11 w-11 shrink-0 place-items-center text-muted",
										"aria-label": "Activity",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
											size: 16,
											"aria-hidden": true
										}), notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 h-2 w-2 rounded-full bg-ok" }) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, {
										viewer,
										identities,
										opened,
										open: accountOpen,
										onToggle: setAccountOpen,
										onPick: (id) => {
											setViewer(id);
											if (page === "profile") openProfile(id);
											setAccountOpen(false);
										},
										onShop: () => {
											go("shop");
											setAccountOpen(false);
										},
										onReset: () => {
											reset();
											setAccountOpen(false);
										},
										session,
										onSignOut: () => {
											saveAccount(null);
											setSession(null);
											setAccountOpen(false);
										}
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto w-full max-w-7xl px-3 pb-3 sm:px-4 lg:px-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "pb-1.5 font-mono text-xs tracking-widest text-faint uppercase",
									children: "Preview desks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-5 gap-1.5",
									role: "tablist",
									"aria-label": "Preview desks",
									children: DESKS.map((item) => {
										const on = desk === item.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											role: "tab",
											"aria-selected": on,
											onClick: () => enter(item.id),
											className: `min-h-11 min-w-0 rounded-2xl px-1 text-xs ${on ? "bg-violet text-fg" : "bg-bg-subtle text-muted"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-center leading-tight",
												children: item.label
											})
										}, item.id);
									})
								})]
							}),
							notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mx-auto w-full max-w-7xl px-4 pb-3 text-sm text-muted lg:px-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-fg",
										children: [notice.title, "."]
									}),
									" ",
									notice.detail
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "relative mx-auto w-full min-w-0 max-w-7xl px-3 py-4 pb-44 sm:px-4 lg:px-6 xl:pb-16",
						children: [
							desk !== "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskPage, {
								desk,
								viewer,
								identities,
								groups,
								servers,
								feed,
								audit,
								products,
								opened,
								account: viewerAccount,
								onAct: (line) => {
									const embed = run(line);
									ping(embed.title, embed.description);
									return embed;
								},
								onOpenBusiness: (name) => {
									openBusiness(viewer.id, name);
									ping("Business opened", `${name} can list on the Official shop. Verification did not change.`);
								},
								onOpenPlayer: (id) => {
									applySeat("play");
									openProfile(id);
								},
								onShop: () => go("shop"),
								onReset: () => {
									reset();
								}
							}) : null,
							desk === "play" && page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HomeTabs, {
								tab: homeTab,
								onTab: setHomeTab,
								children: [
									homeTab === "feed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {
										viewer,
										identities,
										clans,
										rank,
										account: viewerAccount,
										products,
										pending: bounties.length,
										pulse,
										feed,
										onOpen: openTarget,
										onOpenPlayer: openProfile
									}) : null,
									homeTab === "discover" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoverPage, {
										identities,
										query,
										game,
										region,
										style,
										saved,
										onQuery: setQuery,
										onGame: setGame,
										onRegion: setRegion,
										onStyle: setStyle,
										onSave: toggleSaved,
										onOpenPlayer: openProfile
									}) : null,
									homeTab === "compete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompetePage, {
										viewer,
										identities,
										clans,
										bounties,
										onChallenge: challenge,
										onWar: declareWar,
										onStandDown: standDown,
										onBounty: (id) => {
											const bounty = bounties.includes(id);
											toggleBounty(id);
											ping(bounty ? "Left bounty" : "Bounty entered", bounty ? "You stepped out." : "The entry is on this identity.");
										}
									}) : null,
									homeTab === "rankings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankingsPage, {
										identities,
										viewerId: viewer.id,
										game,
										region,
										follows,
										clanIds: clans.find((clan) => clan.id === viewer.clanId)?.memberIds ?? [],
										onGame: setGame,
										onRegion: setRegion,
										onOpen: openProfile
									}) : null,
									homeTab === "social" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialPage, {
										viewer,
										identities,
										clans,
										follows,
										onFollow: toggleFollow,
										onOpen: openProfile
									}) : null,
									homeTab === "stories" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoriesPage, {
										viewer,
										identities
									}) : null
								]
							}) : null,
							desk === "play" && page === "groups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupsPage, {
								viewer,
								identities
							}) : null,
							desk === "play" && page === "messages" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesPage, {
								viewer,
								identities,
								onStory: (text, sticker) => {
									addStory(viewer.id, text, sticker);
									ping("Added to story", sticker ? `${sticker} is on your story.` : "The message is on your story.");
									setHomeTab("stories");
								}
							}) : null,
							desk === "play" && page === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopPage, {
								viewer,
								identities,
								products,
								opened,
								subscribed: astroPass.includes(viewer.id),
								owned: owned[viewer.id] ?? [],
								equipped: equipped[viewer.id] ?? null,
								onSubscribe: () => {
									subscribe(viewer.id);
									ping("Astro started", "150 coins land on the next renewal. One group can wear the animated banner. Preview only — no card was charged.");
								},
								onEndPass: () => {
									endPass(viewer.id);
									ping("Astro ended", "Applied cosmetics were cleared.");
								},
								onEquip: (productId) => equip(viewer.id, productId),
								onOpenBusiness: (name) => {
									openBusiness(viewer.id, name);
									ping("Business opened", `${name} can list on the Official shop. Verification did not change.`);
								},
								onCreate: (draft) => {
									addProduct({
										...draft,
										sellerId: viewer.id,
										game: "Network"
									});
									const sale = quote(draft.price, viewerAccount.verified);
									ping("Product listed", `${draft.title} is on the Official shop at ${sale.label}.`);
								},
								onBuy: (product, seller) => {
									const sale = quote(product.price, seller.verified);
									const sellerName = identities.find((identity) => identity.id === product.sellerId)?.name ?? "Seller";
									const done = applySale({
										buyerId: viewer.id,
										sellerId: product.sellerId,
										price: product.price,
										payout: sale.payout,
										title: `${viewer.name} bought ${product.title}`,
										detail: `${sellerName} received ${formatCoins(sale.payout)} after a ${sale.label} Astro fee.`
									});
									if (!done.ok) {
										ping("Purchase blocked", done.reason);
										return done.reason;
									}
									grantProduct(viewer.id, product.id, product.kind, product.title, product.files?.map((file) => file.name));
									ping("Purchase complete", `You paid ${formatCoins(product.price)}. ${sellerName} received ${formatCoins(sale.payout)} after ${sale.label}.`);
									return null;
								},
								onOpenPlayer: openProfile
							}, viewer.id) : null,
							desk === "play" && page === "profile" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfilePage, {
								viewer: profile,
								account: accountFor(profile.id, opened),
								rank: ranked.findIndex((identity) => identity.id === profile.id) + 1,
								clanName: clanName(profile.clanId),
								followed: follows.includes(profile.id),
								self: profile.id === viewer.id,
								subscribed: astroPass.includes(profile.id),
								equippedName: (() => {
									const id = equipped[profile.id];
									const product = products.find((item) => item.id === id);
									return product ? specFor(product.kind).name : null;
								})(),
								onFollow: () => toggleFollow(profile.id),
								onShop: () => go("shop")
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, { dock: true })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock fixed inset-x-3 bottom-3 z-30 grid grid-cols-5 rounded-3xl border border-border bg-bg-elevated p-1 xl:hidden",
				"aria-label": "Primary",
				children: NAV.map((item) => {
					const on = desk === "play" && page === item.id;
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => go(item.id),
						"aria-current": on ? "page" : void 0,
						className: `flex min-h-14 min-w-0 flex-col items-center justify-center gap-1 rounded-2xl px-1 text-xs ${on ? "text-fg" : "text-muted"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavGlyph, {
							icon: Icon,
							on
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-full truncate",
							children: item.label
						})]
					}, item.id);
				})
			}),
			palette ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, {
				identities: identities.map((identity) => ({
					id: identity.id,
					name: identity.name,
					handle: identity.handle
				})),
				onClose: () => setPalette(false),
				onPage: openTarget,
				onPlayer: openProfile
			}) : null
		]
	});
}
function AccountMenu({ viewer, identities, opened, open, onToggle, onPick, onShop, onReset, session, onSignOut }) {
	const root = (0, import_react.useRef)(null);
	const badgeMap = useResolvedBadges(identities);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onPointer = (event) => {
			if (!root.current?.contains(event.target)) onToggle(false);
		};
		document.addEventListener("pointerdown", onPointer);
		return () => document.removeEventListener("pointerdown", onPointer);
	}, [open, onToggle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		ref: root,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-expanded": open,
			"aria-haspopup": "menu",
			"aria-label": "Account menu",
			onClick: () => onToggle(!open),
			className: "flex h-11 items-center gap-2 rounded-full py-1 pr-2 pl-1 sm:pr-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
					name: viewer.name,
					id: viewer.id,
					size: "sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden max-w-28 truncate text-sm sm:inline",
					children: viewer.name.split(" ")[0]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					size: 14,
					"aria-hidden": true,
					className: `text-muted transition-transform ${open ? "rotate-180" : ""}`
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "menu",
			className: "menu-pop absolute right-0 z-40 mt-2 w-72 max-w-[calc(100vw-1.5rem)] overflow-hidden rounded-3xl border border-border bg-bg-elevated",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 pt-3 font-mono text-xs tracking-widest text-faint uppercase",
					children: "Play as"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-4 pb-1 text-xs text-muted",
					children: [
						session.name,
						" · ",
						session.provider,
						session.email ? ` · ${session.email}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid max-h-80 overflow-y-auto p-2",
					children: identities.map((identity) => {
						const standing = accountFor(identity.id, opened);
						const on = identity.id === viewer.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "menuitemradio",
							"aria-checked": on,
							onClick: () => onPick(identity.id),
							className: `flex min-h-14 w-full items-center gap-3 rounded-2xl px-2 text-left ${on ? "bg-violet/25" : "hover:bg-bg-subtle"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerFace, {
									name: identity.name,
									id: identity.id,
									size: "sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate text-sm",
											children: identity.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeRow, {
											pins: (badgeMap[identity.id]?.featured ?? []).slice(0, 4),
											size: 14
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-xs text-muted",
										children: [
											standing.verified ? "Verified" : "Unverified",
											" · ",
											quote(100, standing.verified).label,
											standing.businessName ? ` · ${standing.businessName}` : ""
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-cyan",
									children: identity.score.toLocaleString("en-US")
								})
							]
						}) }, identity.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid border-t border-border p-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "menuitem",
							onClick: onShop,
							className: "min-h-11 rounded-2xl px-3 text-left text-sm text-cyan hover:bg-bg-subtle",
							children: "Official shop"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "menuitem",
							onClick: onReset,
							className: "min-h-11 rounded-2xl px-3 text-left text-sm text-muted hover:bg-bg-subtle",
							children: "Reset network"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "menuitem",
							onClick: onSignOut,
							className: "min-h-11 rounded-2xl px-3 text-left text-sm text-muted hover:bg-bg-subtle",
							children: "Sign out"
						})
					]
				})
			]
		}) : null]
	});
}
function NavGlyph({ icon: Icon, on }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "nav-morph",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			size: 18,
			className: on ? "nav-glyph is-on" : "nav-glyph"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			size: 18,
			fill: "currentColor",
			className: on ? "nav-glyph nav-glyph-fill is-on" : "nav-glyph nav-glyph-fill"
		})]
	});
}
function HomeTabs({ tab, onTab, children }) {
	const ref = (0, import_react.useRef)(null);
	const listRef = (0, import_react.useRef)(null);
	const start = (0, import_react.useRef)(null);
	const [mark, setMark] = (0, import_react.useState)({
		left: 0,
		top: 0,
		width: 0
	});
	(0, import_react.useEffect)(() => {
		const list = listRef.current;
		if (!list) return;
		const place = () => {
			const active = list.querySelector("[aria-selected=\"true\"]");
			if (!active) return;
			setMark({
				left: active.offsetLeft,
				top: active.offsetTop + active.offsetHeight - 2,
				width: active.offsetWidth
			});
		};
		place();
		const observer = new ResizeObserver(place);
		observer.observe(list);
		return () => observer.disconnect();
	}, [tab]);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const onPointerDown = (event) => {
			if (event.target?.closest("[data-noswipe], input, textarea, select, a, button")) {
				start.current = null;
				return;
			}
			start.current = {
				x: event.clientX,
				y: event.clientY
			};
		};
		const onPointerUp = (event) => {
			if (!start.current) return;
			const dx = event.clientX - start.current.x;
			const dy = event.clientY - start.current.y;
			start.current = null;
			if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
			const next = TABS[TABS.findIndex((item) => item.id === tab) + (dx < 0 ? 1 : -1)];
			if (next) onTab(next.id);
		};
		el.addEventListener("pointerdown", onPointerDown);
		el.addEventListener("pointerup", onPointerUp);
		return () => {
			el.removeEventListener("pointerdown", onPointerDown);
			el.removeEventListener("pointerup", onPointerUp);
		};
	}, [onTab, tab]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "touch-pan-y",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: listRef,
			className: "relative mb-3 grid grid-cols-3 gap-2 sm:flex sm:flex-wrap",
			"data-noswipe": true,
			role: "tablist",
			"aria-label": "Home",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tab-mark",
				style: {
					left: mark.left,
					top: mark.top,
					width: mark.width,
					opacity: mark.width ? 1 : 0
				}
			}), TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "tab",
				"aria-selected": tab === item.id,
				onClick: () => onTab(item.id),
				className: `relative min-h-11 min-w-0 px-3 text-sm ${tab === item.id ? "text-fg" : "text-muted"}`,
				children: item.label
			}, item.id))]
		}), children]
	});
}
function installTouchBridge() {
	let origin = null;
	let startX = 0;
	let startY = 0;
	let armed = false;
	const controlOf = (target) => {
		if (!(target instanceof Element)) return null;
		if (target.closest("[data-badge]")) return null;
		const node = target.closest("button, a");
		if (!(node instanceof HTMLElement)) return null;
		if (node instanceof HTMLButtonElement && node.disabled) return null;
		return node;
	};
	const onDown = (event) => {
		if (event.pointerType !== "touch" && event.pointerType !== "pen") {
			origin = null;
			return;
		}
		origin = event.target;
		startX = event.clientX;
		startY = event.clientY;
	};
	const onUp = (event) => {
		if (event.pointerType !== "touch" && event.pointerType !== "pen" || !origin) return;
		const from = controlOf(origin);
		origin = null;
		if (!from) return;
		if (Math.abs(event.clientX - startX) > 12 || Math.abs(event.clientY - startY) > 12) return;
		if (controlOf(event.target) !== from) return;
		armed = true;
		window.setTimeout(() => {
			armed = false;
		}, 500);
		from.click();
	};
	const onClick = (event) => {
		if (!armed || !event.isTrusted) return;
		event.preventDefault();
		event.stopPropagation();
	};
	document.addEventListener("pointerdown", onDown, true);
	document.addEventListener("pointerup", onUp, true);
	document.addEventListener("click", onClick, true);
	return () => {
		document.removeEventListener("pointerdown", onDown, true);
		document.removeEventListener("pointerup", onUp, true);
		document.removeEventListener("click", onClick, true);
	};
}
function Palette({ identities, onClose, onPage, onPlayer }) {
	const [q, setQ] = (0, import_react.useState)("");
	const needle = q.trim().toLowerCase();
	const pages = [...NAV, ...TABS.filter((item) => item.id !== "feed")].filter((item) => !needle || item.label.toLowerCase().includes(needle));
	const players = identities.filter((identity) => !needle || `${identity.name} ${identity.handle}`.toLowerCase().includes(needle));
	const servers = LISTINGS.filter((listing) => !needle || listing.name.toLowerCase().includes(needle)).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 grid content-start justify-center bg-bg/80 px-4 pt-16",
		role: "dialog",
		"aria-label": "Search KOBA",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0",
			"aria-label": "Close search",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 max-h-[70dvh] w-full max-w-lg overflow-y-auto rounded-3xl border border-border bg-bg-elevated p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					value: q,
					onChange: (event) => setQ(event.target.value),
					placeholder: "Players, servers, pages",
					"aria-label": "Search KOBA",
					className: "h-11 w-full rounded-lg border border-border bg-bg px-3 text-sm placeholder:text-faint"
				}),
				pages.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 pt-3 pb-1 font-mono text-xs text-faint",
					children: "Pages"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid",
					children: pages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							onPage(item.id);
							onClose();
						},
						className: "flex min-h-11 w-full items-center rounded-lg px-2 text-left text-sm hover:bg-bg-subtle",
						children: item.label
					}) }, item.id))
				}),
				players.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 pt-3 pb-1 font-mono text-xs text-faint",
					children: "Players"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid",
					children: players.map((identity) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onPlayer(identity.id),
						className: "flex min-h-11 w-full items-center justify-between rounded-lg px-2 text-left text-sm hover:bg-bg-subtle",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: identity.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: identity.handle
						})]
					}) }, identity.id))
				}),
				servers.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 pt-3 pb-1 font-mono text-xs text-faint",
					children: "Servers"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid",
					children: servers.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							onPage("discover");
							onClose();
						},
						className: "flex min-h-11 w-full items-center rounded-lg px-2 text-left text-sm hover:bg-bg-subtle",
						children: listing.name
					}) }, listing.id))
				}),
				pages.length + players.length + servers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 py-4 text-sm text-muted",
					children: "Nothing matches."
				}) : null
			]
		})]
	});
}
var SplitComponent = PlatformApp;
//#endregion
export { SplitComponent as component };
