import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as LegalPage } from "./legal-page-BRjvhB7A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rules-B8NemxAr.js
var import_jsx_runtime = require_jsx_runtime();
function RulesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Community rules",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Play the person in front of you, not a pile of alts. One identity, honest hours, and a trust card other players can read." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No harassment, hate, sexual content involving minors, or threats. Clips and stories stay about the game. Do not post someone else's private information." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Shops sell KOBA cosmetics, not stolen accounts or real-money game items. Uploads must fit the size window for that product. Do not list art you do not own." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Servers you claim must post an honest wipe clock. Squad posts and wipe-night events have a cap. Do not fill them with empty seats." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Mods can warn, strike, or blacklist. Super can clear a record. Repeated strikes close the shop and the events." })
		]
	});
}
//#endregion
export { RulesPage as component };
